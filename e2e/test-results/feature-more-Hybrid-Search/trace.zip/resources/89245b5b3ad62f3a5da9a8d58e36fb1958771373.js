(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
  typeof define === 'function' && define.amd ? define(factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, global.MisoClient = factory());
})(this, (function () { 'use strict';

  var sdk_version = 'dev'; // this will be replaced by bin/version.js in CD workflow

  function never() {
    return new AbortController().signal;
  }

  function any(...signals) {
    const length = signals.length;
    if (length === 0) {
      return never();
    }
    if (length === 1) {
      return signals[0];
    }
    const ac = new AbortController();
    for (const signal of signals) {
      if (!signal || !signal.addEventListener) {
        continue;
      }
      if (signal.aborted) {
        return AbortSignal.abort(signal.reason);
      }
      signal.addEventListener('abort', () => ac.abort(signal.reason));
    }
    return ac.signal;
  }

  const GROUP$5 = Object.freeze({
    ASK: 'ask',
    SEARCH: 'search',
    RECOMMENDATION: 'recommendation',
    INTERACTIONS: 'interactions',
  });

  const NAME$6 = Object.freeze({
    QUESTIONS: 'questions',
    RELATED_QUESTIONS: 'related_questions',
    SEARCH: 'search',
    AUTOCOMPLETE: 'autocomplete',
    SEARCH_AUTOCOMPLETE: 'search_autocomplete',
    MGET: 'mget',
    USER_TO_PRODUCTS: 'user_to_products',
    USER_TO_CATEGORIES: 'user_to_categories',
    USER_TO_ATTRIBUTES: 'user_to_attributes',
    USER_TO_TRENDING: 'user_to_trending',
    USER_TO_HISTORY: 'user_to_history',
    PRODUCT_TO_PRODUCTS: 'product_to_products',
    UPLOAD: 'upload',
  });

  var API$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    GROUP: GROUP$5,
    NAME: NAME$6
  });

  /**
   * Remove the specified item from array.
   */
  function removeItem(array, item) {
    if (!array) {
      return;
    }
    const i = array.indexOf(item);
    if (i > -1) {
      array.splice(i, 1);
    }
  }

  function findAndRemoveItem(array, test) {
    if (!array) {
      return;
    }
    const i = array.findIndex(test);
    if (i > -1) {
      array.splice(i, 1);
    }
  }

  /**
   * Wrap a value into an array:
   * 1. If it's already an array, return itself
   * 2. If it's undefined, return an empty array
   * 3. Otherwise, return a single-item array
   */
  function asArray(value) {
    return Array.isArray(value) ? value : (value === undefined) ? [] : [value];
  }

  /**
   * Convert value to string, except for undefined and null.
   */
  function asString(value) {
    return value !== undefined && value !== null ? `${value}` : value;
  }

  /**
   * Remove object properties with undefined values and return the object itself.
   */
  function trimObj(obj) {
    if (typeof obj !== 'object') {
      return obj;
    }
    const trimmed = {};
    for (const k in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, k) && obj[k] !== undefined) {
        trimmed[k] = obj[k];
      }
    }
    return trimmed;
  }

  /**
   * Return true if value is undefined or null.
   */
  function isNullLike(value) {
    return value === undefined || value === null;
  }

  /**
   * Get value from a Map if available, compute and set it otherwise.
   */
   function computeIfAbsent(map, key, fn) {
    if (map.has(key)) {
      return map.get(key);
    }
    const value = fn(key);
    map.set(key, value);
    return value;
  }

  /**
   * Delegate getters and methods from source object to target object.
   */
  function delegateGetters(target, source, propNames) {
    propNames = typeof propNames === 'string' ? [propNames] : propNames;
    Object.defineProperties(target, propNames.reduce((acc, propName) => {
      acc[propName] = {
        get: () => {
          const value = source[propName];
          return typeof value === 'function' ? value.bind(source) : value;
        },
      };
      return acc;
    }, {}));
  }

  /**
   * Delegate setters from source object to target object.
   */
  function delegateProperties(target, source, propNames) {
    propNames = typeof propNames === 'string' ? [propNames] : propNames;
    Object.defineProperties(target, propNames.reduce((acc, propName) => {
      acc[propName] = {
        get: () => source[propName],
        set: (value) => { source[propName] = value; },
      };
      return acc;
    }, {}));
  }

  /**
   * Assign values on target object with Object.defineProperties() from source object.
   */
  function defineValues(target, source) {
    for (const name in source) {
      if (source.hasOwnProperty(name)) {
        Object.defineProperty(target, name, { value: source[name] });
      }
    }
  }

  /**
   * Offer the constructor a isTypeOf() static method to determine whether an object is a instance of the type that works *across* different script sources.
   */
  function defineTypeByKey(constructor, key) {
    const sym = Symbol.for(key);
    Object.defineProperty(constructor, sym, { value: true });
    Object.defineProperty(constructor, 'isTypeOf', {
      value: (obj) => obj && (obj instanceof constructor) || (typeof obj.constructor === 'function' && obj.constructor[sym] === true)
    });
  }

  function kebabToLowerCamel(str) {
    return str.replace(/-([a-z])/g, (g) => g[1].toUpperCase());
  }

  function kebabOrSnakeToLowerCamel(str) {
    return str.replace(/[-_][a-z]/g, (g) => g[1].toUpperCase());
  }

  function lowerCamelToKebab(str) {
    return str.replace(/([A-Z])/g, '-$1').toLowerCase();
  }

  function lowerCamelToSnake(str) {
    return str.replace(/[A-Z]/g, ch => `_${ch.toLowerCase()}`);
  }

  function kebabToSnake(str) {
    return str.replaceAll('-', '_');
  }

  function kebabOrSnakeToHuman(str) {
    return str.replace(/[-_][a-zA-Z]/g, ' $1');
  }

  class ContinuityObserver {

    constructor(callback, {
      duration = 0,
      onDuration,
      offDuration,
      state,
    } = {}) {
      if (typeof callback !== 'function') {
        throw new Error(`Callback must be a function: ${callback}`);
      }
      validateDuration(onDuration);
      validateDuration(offDuration);
      validateDuration(duration);

      this._callback = callback;
      Object.defineProperty(this, 'durations', {
        value: Object.freeze({
          on: onDuration !== undefined ? onDuration : duration,
          off: offDuration !== undefined ? offDuration : duration,
        }),
      });
        this._value = this._state = !!state;
      this._active = true;
    }

    get active() {
      return this._active;
    }

    get state() {
      return this._state;
    }

    get value() {
      return this._value;
    }

    set value(value) {
      value = !!value;
      if (this._value === value) {
        return;
      }

      // clear timeout for the opposite direction
      _clearTimeout(this);

      const duration = this.durations[value ? 'on' : 'off'];
      if (duration) {
        // countdown to switch state if positive duration
        this._timeout = setTimeout(() => _setState(this, value), duration);
      } else {
        // otherwise, switch state immediately
        _setState(this, value);
      }
      this._value = value;
    }

    disconnect() {
      this._active = false;
    }

  }

  function _clearTimeout(observer) {
    if (!observer._timeout) {
      return;
    }
    clearTimeout(observer._timeout);
    observer._timeout = undefined;
  }

  function _setState(observer, state) {
    if (observer._state === state) {
      return; // just in case
    }
    observer._state = state;
    if (observer._active) {
      observer._callback(state);
    }
  }

  function validateDuration(propName, value) {
    if (value !== undefined && (isNaN(value) || value < 0)) {
      throw new Error(`${propName} must be a non-negative number: ${value}`);
    }
  }

  /**
   * Convert value to element by querying selector, if value is a string. Return value otherwise.
   */
   function asElement(value) {
    if (typeof value === 'string') {
      return document.querySelector(value);
    }
    return value;
  }

  /**
   * Compute a function along the ancestors of an element until it returns a non-undefined value;
   */
  function findInAncestors(element, fn, { root = element.ownerDocument } = {}) {
    for (; element && element !== root; element = element.parentElement) {
      const value = fn(element);
      if (value !== undefined) {
        return value;
      }
    }
    return undefined;
  }

  /**
   * Define a custom element class and update all currently present ones in DOM.
   */
  function defineAndUpgrade(elementClass) {
    const { tagName } = elementClass;
    customElements.define(tagName, elementClass);
    for (const element of document.querySelectorAll(tagName)) {
      customElements.upgrade(element);
    }
  }

  /**
   * Same as window.requestAnimationFrame(), but as an async function.
   */
  async function requestAnimationFrame(callback) {
    return new Promise((resolve, reject) => {
      window.requestAnimationFrame(async (timestamp) => {
        try {
          await callback(timestamp);
          resolve();
        } catch(err) {
          reject(err);
        }
      });
    });
  }

  /**
   * Return a promise resolved when the given element reaches viewable condition.
   */
  async function viewable(element, {
    area = 0.5,
    duration = 1000,
    signal,
  } = {}) {
    element = asElement(element);
    // TODO: check element
    return new Promise((resolve, reject) => {
      const continuity = new ContinuityObserver((value) => {
        if (value) {
          continuity.disconnect();
          intersection.disconnect();
          resolve();
        }
      }, {
        onDuration: duration,
      });
      const intersection = new IntersectionObserver((entries) => {
        continuity.value = entries[0].isIntersecting;
      }, {
        threshold: area,
      });
      intersection.observe(element);

      if (signal && signal.addEventListener) {
        signal.addEventListener('abort', () => {
          continuity.disconnect();
          intersection.disconnect();
          reject(new DOMException('Aborted', 'AbortError'));
        });
      }
    });
  }

  async function waitForDomContentLoaded() {
    if (document.readyState !== 'loading') {
      return;
    }
    await new Promise(resolve => {
      document.addEventListener('DOMContentLoaded', resolve, { once: true });
    });
  }

  function escapeHtml(text) {
    text = `${text}`;
    return text && text
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  // TODO: there is no way to make this nodeJS compatible, we want to think about how to manage the package

  function uuidv4() {
    return uuidv4ByCyrptoRandomUUID() || uuidv4ByBlobUrl() || uuidv4ByMathRandom();
  }

  function uuidv4ByCyrptoRandomUUID() {
    return crypto && crypto.randomUUID ? crypto.randomUUID() : undefined;
  }

  function uuidv4ByBlobUrl() {
    if (!URL || !URL.createObjectURL || URL.revokeObjectURL || !Blob) {
      return undefined;
    }
    const url = URL.createObjectURL(new Blob());
    const uuid = url.toString();
    URL.revokeObjectURL(url);
    // remove prefix (e.g. blob:null/, blob:www.test.com/, ...)
    return uuid.substring(uuid.lastIndexOf('/') + 1);
  }

  // TODO: this is a badly performant fallback
  function uuidv4ByMathRandom() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
  }

  function getOrComputeFromStorage(name, compute) {
    const localStorageValue = catchSecurityError(() => window.localStorage.getItem(name));
    const cookieValue = catchSecurityError(() => getCookie(name));
    const value = localStorageValue || cookieValue || `${compute()}`;
    if (value && !localStorageValue) {
      catchSecurityError(() => window.localStorage.setItem(name, value));
    }
    if (value && !cookieValue) {
      catchSecurityError(() => setCookie(name, value));
    }
    return value;
  }

  function getCookie(name) {
    const c = `; ${document.cookie}`;
    const ref = `; ${encodeURIComponent(name)}=`;
    const i = c.indexOf(ref);
    if (i < 0) {
      return undefined;
    }
    const j = i + ref.length;
    const k = c.indexOf(';', j);
    return decodeURIComponent(k < 0 ? c.substring(j) : c.substring(j, k));
  }

  function setCookie(name, value) {
    document.cookie = `${encodeURIComponent(name)}=${encodeURIComponent(value)}; max-age=31536000; path=/`;
  }

  function catchSecurityError(fn) {
    try {
      return fn();
    } catch (e) {
      if (!isSecurityError(e)) {
        throw e;
      }
    }
    return undefined;
  }

  function isSecurityError(e) {
    return e.name === 'SecurityError';
  }

  function addUrlParameter(url, key, value) {
    if (typeof key !== 'string') {
      throw new Error(`Expect URL parameter to be a string: ${key}`);
    }
    if (value === undefined) {
      value = '1';
    }
    return url + (url.indexOf('?') < 0 ? '?' : '&') + encodeURIComponent(key) + '=' + encodeURIComponent(`${value}`);
  }

  function capture(value) {
    return new Capture(value);
  }

  class Capture {

    constructor(value) {
      this._value = value;
      const set = v => { this._value = v; };
      defineValues(this, {
        set,
        args: (...args) => set(args),
        t: () => set(true),
        f: () => set(false),
        merge: v => set({ ...this._value, ...v }),
      });
    }

    get value() {
      return this._value;
    }

  }

  class Resolution {

    constructor() {
      const self = this;
      self.promise = new Promise((resolve, reject) => {
        self.resolve = resolve;
        self.reject = reject;
      });
      Object.freeze(this);
    }

  }

  class ValueBuffer {

    constructor() {
      this._index = -1;
      this._done = false;
      this._aborted = false;
      this._abortReason = undefined;
      this._error = undefined;
    }

    get aborted() {
      return this._aborted;
    }

    get abortReason() {
      return this._abortReason;
    }

    get done() {
      return this._done;
    }

    update(value, done = false) {
      if (this._done) {
        return;
      }
      this._value = value;
      this._done = done;
      this._index++;

      if (this._resolution) {
        this._resolution.resolve();
        this._resolution = undefined;
      }
    }

    error(error) {
      this._error = error;

      if (this._resolution) {
        this._resolution.reject(error);
        this._resolution = undefined;
      }
    }

    abort(reason) {
      this._aborted = true;
      this._abortReason = reason;

      if (this._resolution) {
        if (reason instanceof Error) {
          this._resolution.reject(reason);
        } else {
          this._resolution.resolve();
        }
        this._resolution = undefined;
      }
    }

    async *[Symbol.asyncIterator]() {
      let cursor = 0;
      while (true) {
        // check error
        if (this._error) {
          throw this._error;
        }
        // check aborted
        if (this._aborted) {
          break;
        }
        // wait for next update
        if (cursor > this._index) {
          if (!this._resolution) {
            this._resolution = new Resolution();
          }
          await this._resolution.promise;
        }
        // check aborted behind promise
        if (this._aborted) {
          break;
        }
        const done = this._done;
        const newCursor = this._index + 1;

        yield this._value; // expect this to be async

        // check aborted or done
        if (this._aborted || done) {
          break;
        }
        cursor = newCursor;
      }
    }

  }

  function polling(fetch, { interval = 1000, errorLimit = 10, onError, onResponse, signal } = {}) {
    if (signal && signal.aborted) {
      return [];
    }
    let consecutiveErrorCount = 0, intervalId, done = false, currResRevision;
    function clear() {
      intervalId && clearInterval(intervalId);
      done = true;
    }
    const buffer = new ValueBuffer();
    intervalId = setInterval(async () => {
      let response, finished, revision;
      try {
        [response, finished, revision] = await fetch(signal ? { signal } : {});
        if (done || (!isNullLike(currResRevision) && revision <= currResRevision)) {
          return; // discard outdated response
        }
        if (!isNullLike(revision)) {
          currResRevision = revision;
        }
        onResponse && onResponse(response, finished, revision);
        consecutiveErrorCount = 0;
      } catch(error) {
        onError && onError(error);
        consecutiveErrorCount++;
        if (consecutiveErrorCount > errorLimit) {
          clear();
          buffer.error(error);
        }
        return;
      }
      buffer.update(response, finished);
      if (finished) {
        clear();
      }
    }, interval);

    if (signal && signal.addEventListener) {
      signal.addEventListener('abort', () => {
        clear();
        buffer.abort(signal.reason);
      });
    }

    return buffer;
  }

  function execute(onError, fn) {
    try {
      fn();
    } catch (e) {
      onError(e);
    }
  }

  function cmd$1(key, onError = e => console.error(e)) {
    const cmds = window[key] || (window[key] = []);
    if (cmds._processed) {
      return;
    }
    cmds._processed = true;

    const exec = fn => execute(onError, fn);
    
    // overrides push function so future commands are executed immediately
    Object.defineProperty(cmds, 'push', { value: exec });
    
    // process existing miso commands
    for (const fn of cmds) {
      exec(fn);
    }
  }

  let currentScript$2;
  try {
    currentScript$2 = document.currentScript;
  } catch(e) {}

  async function loadStyles$1(url) {
    try {
      let link = getExistedLinkElement(url);
      if (!link) {
        link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = url;
        document.head.appendChild(link);
      }
      return waitForStylesApplied(link);
    } catch(e) {
      console.error(e);
    }
  }

  function resolveCssUrl(name) {
    // TODO: refactor with getPluginScriptUrl() in core
    {
      if (!currentScript$2) {
        throw new Error(`Cannot resolve css url for ${name} in dev mode`);
      }
      const src = currentScript$2.src;
      const searchIndex = src.indexOf('?');
      const k = searchIndex < 0 ? src.length : searchIndex;
      const i = src.lastIndexOf('/', k); // .../dist/umd/*.min.js
      return `${src.slice(0, i - 4)}/css/${name}.css`;
    }
  }



  // helpers //
  function getExistedLinkElement(url) {
    return document.head.querySelector(`link[href="${url}"]`);
  }

  async function waitForStylesApplied(element) {
    await waitForSheetAvailable(element);
    await waitForSheetIncluded(element);
  }

  async function waitForSheetAvailable(element) {
    if (element.sheet) {
      return;
    }
    return new Promise((resolve, reject) => {
      let intervalId;
      element.onerror = () => {
        intervalId && clearInterval(intervalId);
        reject();
      };
      intervalId = setInterval(() => {
        if (!element.sheet) {
          return;
        }
        intervalId && clearInterval(intervalId);
        resolve();
    }, 100);
    });
  }

  async function waitForSheetIncluded(element) {
    if (isSheetIncluded(element)) {
      return;
    }
    return new Promise((resolve) => {
      let intervalId;
      intervalId = setInterval(() => {
        if (!isSheetIncluded(element)) {
          return;
        }
        intervalId && clearInterval(intervalId);
        resolve();
    }, 100);
    });
  }

  function isSheetIncluded(element) {
    for (const sheet of document.styleSheets) {
      if (sheet.ownerNode === element) {
        return true;
      }
    }
    return false;
  }

  function debounce(delay) {
    let timeoutId;
    return (callback) => {
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      timeoutId = setTimeout(() => {
        timeoutId = undefined;
        callback();
      }, delay);
    };
  }

  function dumpValue(value, { depth = 5, ...options } = {}) {
    return _dumpValue(value, depth);
  }

  function _dumpValue(value, depth, options) {
    if (depth <= 0) {
      return '(...)';
    }
    switch (typeof value) {
      case 'object':
        if (value) { // not null
          if (value.length !== undefined) {
            // array-like
            return Array.prototype.map.call(value, v => _dumpValue(v, depth - 1));
          } else if (value instanceof Node) {
            return dumpNode(value);
          } else {
            return dumpObj(value, depth);
          }
        }
      default:
        return value;
    }
  }

  function dumpObj(obj, depth, options) {
    const result = {};
    if (depth <= 0) {
      return result;
    }
    for (const key in obj) {
      const value = obj[key];
      if (typeof value === 'function') {
        continue;
      }
      // this implies the property is an internal module
      if (key.startsWith('_') && typeof value === 'object' && value.constructor.name !== 'Object') {
        continue;
      }
      result[key] = _dumpValue(value, depth - 1);
    }
    return result;
  }

  function dumpNode(node) {
    if (node instanceof Element) {
      return `<${node.tagName.toLowerCase()}${node.id ? ` id="${node.id}"` : ''}${node.className ? ` class="${node.className}"` : ''}>`;
    }
    return `[TextNode](${node.length})`;
  }

  /**
   * Mixin source properties into target.
   */
  function mixin(target, source) {
    const sourceDescriptors = Object.getOwnPropertyDescriptors(source);
    const targetDescriptors = Object.getOwnPropertyDescriptors(target);
    for (const [key, descriptor] of Object.entries(sourceDescriptors)) {
      if (key === 'constructor') {
        continue;
      }
      if (targetDescriptors[key] === undefined) {
        Object.defineProperty(target, key, descriptor);
      }
    }
  }

  /**
   * Turn an object into another object whose property functions are bound to the original object.
   */
  function externalize(object) {
    const externalized = {};
    const props = new Set();
    for (let o = object; o !== Object.prototype; o = Object.getPrototypeOf(o)) {
      const descriptors = Object.getOwnPropertyDescriptors(o);
      for (const key in descriptors) {
        if (key === 'constructor' || key.startsWith('_') || props.has(key)) {
          continue;
        }
        props.add(key);
        // TODO: getter, setter
        const { value } = descriptors[key];
        if (value) {
          externalized[key] = typeof value === 'function' ? value.bind(object) : value;
        }
      }
    }
    return Object.freeze(externalized);
  }

  const DEFAULT_SPEED = 100; // characters per second
  const DEFAULT_ACCELERATION = 4; // characters per second

  function pacer(options) {
    const speedFn = normalizeSpeedFunction(options);
    return (previousCursor, doneAt, previousTimestamp, newTimestamp) => {
      const cps = speedFn(previousTimestamp, doneAt);
      return previousCursor + (Math.max(newTimestamp - previousTimestamp, 0) * cps / 1000);
    };
  }

  function normalizeSpeedFunction({ speed = DEFAULT_SPEED, acceleration = DEFAULT_ACCELERATION } = {}) {
    if (typeof speed === 'function') {
      return speed;
    }
    if (typeof speed !== 'number') {
      throw new Error(`Invalid speed: ${speed}`);
    }
    if (typeof acceleration !== 'number') {
      throw new Error(`Invalid acceleration: ${acceleration}`);
    }
    return (timestamp, doneAt) => {
      let value = speed * (Math.random() + 0.5);
      if (acceleration > 0 && doneAt !== undefined && timestamp > doneAt) {
        // speed up gradually when input is done
        value *= 1 + ((timestamp - doneAt) * acceleration / 1000);
      }
      return value;
    };
  }

  const symbol = Symbol.for('miso:resources');

  class Resources {

    constructor() {
      this._resources = new Map();
      const pushed = window[symbol] || [];
      for (const args of pushed) {
        try {
          const [name, resource] = args;
          this.push([name, resource]);
        } catch (_) {
          // TODO
        }
      }
    }

    push([name, resource]) {
      getOrCreate(this._resources, name).resolve(resource);
    }

    async get(name) {
      return getOrCreate(this._resources, name).promise;
    }

    /*
    *[Symbol.iterator]() {
      for (const [name, resource] of this._resources) {
        yield [name, resource.promise];
      }
    }
    */

  }

  function getOrCreate(map, key) {
    if (map.has(key)) {
      return map.get(key);
    }
    const value = new Resolution();
    map.set(key, value);
    return value;
  }

  function get() {
    return window[symbol] || (window[symbol] = new Resources());
  }

  class Bulk {

    constructor(runner, onError) {
      this._dispatchRequested = false;
      this._requests = [];
      this._run = runner;
      this._error = onError || (e => console.error(e));
      this._bulkId = 0;
      this._dispatch = this._dispatch.bind(this);
    }

    get info() {
      return {
        bulkId: this._bulkId,
        index: this._requests.length,
      };
    }

    async run(action) {
      const resolution = new Resolution();
      this._requests.push({ action, resolution });
      this._requestDispatch();
      return resolution.promise;
    }

    _requestDispatch() {
      if (this._dispatchRequested) {
        return;
      }
      this._dispatchRequested = true;
      setTimeout(this._dispatch);
    }

    _dispatch() {
      if (!this._dispatchRequested) {
        return;
      }
      this._dispatchRequested = false;
      const requests = this._requests;
      const bulkId = this._bulkId++;
      this._requests = [];
      try {
        this._run(requests, { bulkId });
      } catch(e) {
        this._error(e);
      }
    }

  }

  class EventEmitter {

    constructor({ target, error, replays = [] } = {}) {
      this._error = error || (e => console.error(e));
      if (!Array.isArray(replays)) {
        throw new Error(`Replays option must be an array of strings: ${replays}`);
      }
      this._replays = new Set(replays);
      this._namedCallbacks = {};
      this._unnamedCallbacks = [];
      this._pastEvents = {};
      target && this._injectSubscribeInterface(target);
    }

    emit(name, data) {
      const event = { data, meta: { name, ts: Date.now() } };
      const callbacks = this._namedCallbacks[name];
      if (callbacks) {
        for (const callback of callbacks) {
          callback(event);
        }
      }
      for (const callback of this._unnamedCallbacks) {
        callback(event);
      }
      if (this._shallStoreForReplay(name)) {
        (this._pastEvents[name] || (this._pastEvents[name] = [])).push(event);
      }
    }

    on(name, callback) {
      this._checkName(name);
      this._checkCallback(callback);
      return this._on(name, this._wrapCallback(callback));
    }

    once(name) {
      this._checkName(name);
      const self = this;
      return new Promise((resolve, reject) => {
        const off = self._on(name, (event) => {
          setTimeout(() => off());
          try {
            resolve(event);
          } catch(e) {
            reject(e);
          }
        });
      });
    }

    clear() {
      this._namedCallbacks = {};
      this._unnamedCallbacks = [];
      this._pastEvents = {};
    }

    // helper //
    _checkName(name) {
      if (typeof name !== 'string') {
        throw new Error(`Event name should be a string: ${name}`);
      }
    }

    _checkCallback(callback) {
      if (typeof callback !== 'function') {
        throw new Error(`Event callback should be a function: ${callback}`);
      }
    }

    _shallStoreForReplay(name) {
      return this._replays.has(name);
    }

    _wrapCallback(callback) {
      const self = this;
      return ({ data, meta }) => {
        try {
          callback(data, meta);
        } catch(e) {
          //self._error(new Error(`Error in callback of event '${meta.name}'`));
          self._error(e);
        }
      };
    }

    _on(name, wrappedCallback) {
      if (name === '*') {
        this._unnamedCallbacks.push(wrappedCallback);
      } else {
        (this._namedCallbacks[name] || (this._namedCallbacks[name] = [])).push(wrappedCallback);
      }
      // if this event type is in replay mode, replay past events
      if (name === '*') {
        for (const key in this._pastEvents) {
          this._pastEvents[key].forEach(wrappedCallback);
        }
      } else {
        this._pastEvents[name] && this._pastEvents[name].forEach(wrappedCallback);
      }
      // return the corresponding unsubscribe function
      return () => this._off(name, wrappedCallback);
    }

    _off(name, wrappedCallback) {
      if (name === '*') {
        removeItem(this._unnamedCallbacks, wrappedCallback);
      } else {
        const callbacks = this._namedCallbacks[name];
        callbacks && removeItem(callbacks, wrappedCallback);
      }
    }

    // TODO: use constructor options
    _injectSubscribeInterface(target) {
      delegateGetters(target, this, ['on', 'once']);
    }

  }

  function buildMeta(name, parent) {
    if (name !== undefined && typeof name !== 'string' && parent === undefined) {
      parent = name;
      name = undefined;
    }

    if (name !== undefined && (typeof name !== 'string' || !name)) {
      throw new Error(`Invalid Component name: "${name}"`);
    }

    return Object.freeze({
      name,
      parent,
      path: buildPath(name, parent),
      uuid: uuidv4(),
    });
  }

  function buildPath(name, parent) {
    return Object.freeze([...(parent && parent.meta && parent.meta.path || []), ...(name ? [name] : [])]);
  }

  class Component {

    constructor(name, parent) {
      const meta = buildMeta(name, parent);
      defineValues(this, { meta });
    
      const error = this._error = this._error.bind(this);
      this._events = new EventEmitter({ target: this, error, replays: ['child'] });

      this._warn =  this._warn.bind(this);

      parent = meta.parent;
      parent && parent._events && parent._events.emit('child', this);
    }

    _warn(...args) {
      const parent = this.meta.parent;
      ((parent && parent._warn) || console.warn)(...args);
    }

    _error(...args) {
      const parent = this.meta.parent;
      ((parent && parent._error) || console.error)(...args);
    }

  }

  defineTypeByKey(Component, 'miso:component');

  class Registry extends Component {

    constructor(name, parent, { libName, keyName } = {}) {
      super(name, parent);
      this._events._replays.add('register'); // hacky but least tedious
      this._libraries = {}; // TODO: use Map so key can be any type
      this._libResolutions = {};
      this._libName = libName;
      switch (typeof keyName) {
        case 'string':
          this._keyFn = (lib => lib[keyName]);
          break;
        case 'function':
          this._keyFn = keyName;
          break;
        default:
          throw new Error(`Expect keyName to be a string or a function: ${keyName}`);
      }
    }

    isRegistered(key) {
      this._checkKey(key);
      return !!this._libraries[key];
    }

    get registered() {
      return Object.values(this._libraries);
    }

    async whenRegistered(key) {
      if (this.isRegistered(key)) {
        return this._libraries[key];
      }
      const { promise } = this._libResolutions[key] || (this._libResolutions[key] = new Resolution());
      return promise;
    }

    register(...libs) {
      for (const lib of libs) {
        this._register(lib);
      }
    }

    _checkKey(key) {
      if (typeof key !== 'string' || !key) {
        throw new Error(`Expect key to be a non-empty string: ${key}`);
      }
    }

    _checkLib(lib) {
      if (typeof lib !== 'function') {
        throw new Error(`Expect lib to be a class or function: ${lib}`);
      }
    }
    
    _register(lib) {
      this._checkLib(lib);
      const key = this._keyFn(lib);
      this._checkKey(key);
      const libs = this._libraries || (this._libraries = {});
      if (libs[key]) ;
      libs[key] = lib;
      this._libResolutions[key] && this._libResolutions[key].resolve(lib);
      this._events.emit('register', lib);
    }

  }

  class CarouselItemViewabilityObserver {

    constructor(callback, options) {
      this._callback = callback;
      this._options = options || {};
      if (options !== false) {
        this._intersection = new IntersectionObserver(this._handleIntersection.bind(this), { threshold: options.area || 0.5 });
        this._continuity = new ContinuityObserver(this._handleContinuity.bind(this), { onDuration: options.duration || 1000 });
      }

      this._displayed = undefined;
      this._intersecting = false;
      this._triggered = new Set();
    }

    observe(element) {
      if (this._options === false) {
        return;
      }
      this._intersection.observe(element);
    }

    unobserve(element) {
      if (this._options === false) {
        return;
      }
      this._intersection.unobserve(element);
    }

    display(index) {
      if (this._options === false) {
        return;
      }
      if (this._triggered.has(index)) {
        index = undefined;
      }
      if (this._displayed === index) {
        return;
      }
      this._displayed = index;
      this._continuity.value = false; // reset first, the old session is invalid now
      this._syncContinuity();
    }

    disconnect() {
      if (this._options === false) {
        return;
      }
      this._continuity.disconnect();
      this._intersection.disconnect();
    }

    get triggeredCount() {
      return this._triggered.size;
    }

    get triggered() {
      return new Set(this._triggered);
    }

    _syncContinuity() {
      this._continuity.value = this._intersecting && this._displayed !== undefined;
    }

    _handleIntersection(entries) {
      this._intersecting = entries[0].isIntersecting;
      this._syncContinuity();
    }

    _handleContinuity(value) {
      const displayed = this._displayed;
      if (value && displayed !== undefined) {
        if (this._triggered.has(displayed)) {
          return;
        }
        this._triggered.add(displayed);
        this._displayed = undefined;
        this._callback(displayed);
      }
    }

  }

  class StallTimeoutAbortController {

    constructor(timeout) {
      this._ac = new AbortController();
      this._timeout = timeout;
      this.touch();
    }

    clear() {
      if (this._timeoutId !== undefined) {
        clearTimeout(this._timeoutId);
        this._timeoutId = undefined;
      }
    }

    touch() {
      this.clear();
      this._timeoutId = setTimeout(() => this.abort(), this._timeout);
    }

    get signal() {
      return this._ac.signal;
    }

    abort(reason) {
      this.clear();
      this._ac.abort(reason || new Error(`Stall timeout: data stay unchanged for ${this._timeout / 1000} seconds.`));
    }

  }

  const API = Object.freeze({
    DATA_ENDPOINT: 'https://api-edge.askmiso.com/v1',
    EVENT_ENDPOINT: 'https://api.askmiso.com/v1',
  });

  class ApiHelpers {

    constructor(client, root) {
      this._client = client;
      this._root = root;
      this._bulk = new Bulk(this._runBulkFetch.bind(this), client._error.bind(client));
    }

    async fetch(url, payload, {
      method = 'POST',
      headers,
      timeout,
      sendApiKeyByHeader,
    } = {}) {
      const { apiKey, request = {} } = this._client.options;
      timeout = timeout || request.timeout;
      sendApiKeyByHeader = sendApiKeyByHeader || request.sendApiKeyByHeader;

      if (sendApiKeyByHeader) {
        headers = { ...headers, 'X-API-KEY': apiKey };
      }
      // TODO: external abort signal
      // TODO: organize arguments
      const body = method !== 'GET' && payload != undefined ? JSON.stringify(payload) : undefined;

      const signal = timeout ? AbortSignal.timeout(timeout) : undefined;

      const res = await (this._root._customFetch || window.fetch)(url, trimObj({
        method,
        headers,
        body,
        cache: 'no-cache',
        mode: 'cors',
        signal,
      }));

      const resBody = await res.json();
      if (res.status >= 400 || resBody.errors) {
        var err = new Error(resBody.message);
        err.data = resBody;
        err.status = res.status;
        throw err;
      }
      return resBody;
    }

    get bulkInfo() {
      return this._bulk.info;
    }

    async fetchForBulk(apiGroup, apiName, payload, { method } = {}) {
      if (method && method !== 'POST') {
        throw new Error(`Non-POST API is not supported in bulk mode: ${url}`);
      }
      return this._bulk.run({ apiGroup, apiName, payload });
    }

    async _runBulkFetch(requests) {
      // TODO: request options?
      const url = this.url(['bulk']);
      const payload = {
        requests: requests.map(({ action: { apiGroup, apiName, payload } }) => ({
          api_name: `${apiGroup}/${apiName}`,
          body: payload,
        })),
      };
      const { data: responses } = await this.fetch(url, payload);
      for (let i = 0, len = requests.length; i < len; i++) {
        const { resolution } = requests[i];
        const { error, status_code, body } = responses[i];
        if (status_code >= 400 || error) {
          resolution.reject({ status_code, body });
        } else {
          resolution.resolve(body);
        }
      }
    }

    sendBeacon(url, payload, { method } = {}) {
      if (method && method !== 'POST') {
        throw new Error(`Non-POST API is not supported in useBeacon mode: ${url}`);
      }
      const successful = this._root._customSendBeacon ?
        this._root._customSendBeacon(url, JSON.stringify(payload)) :
        window.navigator.sendBeacon(url, JSON.stringify(payload));
      if (!successful) {
        throw new Error(`Send beacon unsuccessful: ${url}`);
      }
    }

    url(paths, options = {}) {
      const { apiKey, request = {} } = this._client.options;
      const sendApiKeyByHeader = options.sendApiKeyByHeader || request.sendApiKeyByHeader;
      const apiName = paths.filter(s => s).join('/');
      const url = `${this.getApiEndpoint(apiName)}/${apiName}`;
      return sendApiKeyByHeader ? url : `${url}?api_key=${window.encodeURIComponent(apiKey)}`;
    }

    getApiEndpoint(apiName) {
      const {
        dataEndpoint = API.DATA_ENDPOINT,
        eventEndpoint = API.EVENT_ENDPOINT,
      } = this._client.options;
      return apiName === 'interactions' ? eventEndpoint : dataEndpoint;
    }

    applyUrlPasses(component, { apiGroup, apiName, url }) {
      const client = this._client;
      for (const pass of this._root._urlPasses) {
        try {
          url = pass({ client, apiGroup, apiName, url }) || url;
        } catch(e) {
          (component._error || console.error)(e);
        }
      }
      return url;
    }

    applyPayloadPasses(component, { apiGroup, apiName, payload }) {
      const client = this._client;
      for (const pass of this._root._payloadPasses) {
        try {
          payload = pass({ client, apiGroup, apiName, payload }) || payload;
        } catch(e) {
          (component._error || console.error)(e);
        }
      }
      return payload;
    }

  }

  class ApiBase extends Component {

    // TODO: use private fields (may encounter issues with rollup)

    constructor(api, apiPath) {
      super(apiPath, api);
      this._apiPath = apiPath;
      this.helpers = api.helpers;
      this.clientOptions = api._client.options;
      this.context = api._client.context;
    }

    async _run(apiName, payload, options = {}) {
      const { bulk } = options;
      const bulkInfo = bulk ? { bulk: this.helpers.bulkInfo } : undefined;
      const apiGroup = this._apiPath;
      const url = this._url({ apiGroup, apiName, payload, options });
      payload = this._preprocess({ apiGroup, apiName, payload, options });
      const requestData = { apiGroup, apiName, payload, url, options };
      this._events.emit('request', { ...requestData, ...bulkInfo });
      const response = await this._send(requestData);
      const responseData = { ...requestData, response };
      this._events.emit('response', { ...responseData, ...bulkInfo });
      return this._postprocess(responseData);
    }

    _preprocess({ apiGroup, apiName, payload }) {
      return this.helpers.applyPayloadPasses(this, { apiGroup, apiName, payload });
    }

    _url({ apiGroup, apiName, options }) {
      const url = this.helpers.url([apiGroup, apiName], options);
      return this.helpers.applyUrlPasses(this, { apiGroup, apiName, url, options });
    }

    async _send({ apiGroup, apiName, url, payload, options: { bulk, ...options } = {} }) {
      return bulk ? this.helpers.fetchForBulk(apiGroup, apiName, payload) : this.helpers.fetch(url, payload, options);
    }

    _postprocess({ response }) {
      // TODO: we can introduce response passes
      return response.data;
    }

  }

  const { GROUP: GROUP$4, NAME: NAME$5 } = API$1;

  class Interactions extends ApiBase {

    constructor(api) {
      super(api, GROUP$4.INTERACTIONS);
    }

    async upload(payload, options) {
      try {
        return await this._run(NAME$5.UPLOAD, payload, options);
      } catch (e) {
        if (e.status === 400 && e.message && e.message.toLowerCase().indexOf('playground') > -1) {
          this._warn(`Ignore interactions uploaded to playground app.`);
        } else {
          throw e;
        }
      }
    }

    _url({ apiGroup, apiName, options }) {
      const url = this.helpers.url([this._apiPath], options);
      return this.helpers.applyUrlPasses(this, { apiGroup, apiName, url, options });
    }

    _preprocess({ apiGroup, apiName, payload }) {
      if (apiName === NAME$5.UPLOAD) {
        payload = this._normalizeUploadPayload(payload);
      }
      return super._preprocess({ apiGroup, apiName, payload });
    }

    _normalizeUploadPayload(payload) {
      // TODO: accept string as a shortcut of { type: payload } as well
      if (typeof payload !== 'object') {
        throw new Error(`Interactions payload has to be either an object or an array of objects: ${payload}`);
      }
      if (!Array.isArray(payload)) {
        payload = [payload];
      }
      return { data: payload };
    }

    async _send({ options: { useBeacon = true, ...options } = {}, ...args }) {
      if (useBeacon) {
        const { url, payload } = args;
        this.helpers.sendBeacon(url, payload, options);
        return {};
      } else {
        return super._send({ ...args, options });
      }
    }

  }

  class IterableApiStub {

    constructor(options = {}) {
      this._ac = new AbortController();
      this._options = options;
    }

    async get(options) {
      return this._get({ ...this._options, ...options });
    }

    _get(options) {
      throw new Error('Not implemented');
    }

    abort(reason) {
      this._ac.abort(reason);
    }

    [Symbol.asyncIterator]() {
      const fetch = async ({ signal } = {}) => {
        // TODO: pass signal
        const response = await this.get();
        return [response, this._isFinished(response), this._revisionOf(response)];
      };
      let { pollingInterval: interval, signal, stallTimeout = 120000, ...options } = this._options;
      const stac = new StallTimeoutAbortController(stallTimeout);
      signal = any(this._ac.signal, stac.signal, signal);

      let prevResponse;
      const onResponse = (response, finished) => {
        if (finished) {
          stac.clear();
        } else if (this._isUpdated(prevResponse, response)) {
          stac.touch();
        }
        prevResponse = response;
      };
      return polling(fetch, { interval, signal, onResponse, ...options })[Symbol.asyncIterator]();
    }

    _isFinished(response) {
      return !!(response && response.finished);
    }

    _isUpdated(previousResponse, newResponse) {
      return !previousResponse || previousResponse.answer_stage !== newResponse.answer_stage || previousResponse.answer.length !== newResponse.answer.length;
    }

    _revisionOf(response) {
      return response && response.revision;
    }

  }

  class IdBasedIterableApiStub extends IterableApiStub {

    constructor(api, method, id, options) {
      super(options);
      this._api = api;
      this._method = method;
      this._id = id;
    }

    async _get(options) {
      return this._api[this._method](this._id, options);
    }

  }

  const { GROUP: GROUP$3, NAME: NAME$4 } = API$1;

  let Ask$1 = class Ask extends ApiBase {

    constructor(api) {
      super(api, GROUP$3.ASK);
    }

    async questions(payload, options = {}) {
      if (isId(payload)) {
        return new Answer(this, payload, options);
      }
      const response = await this._run(NAME$4.QUESTIONS, payload, options);
      return new Answer(this, response, options);
    }

    async _questions(payload, options) {
      return this._run(NAME$4.QUESTIONS, payload, options);
    }

    async _questionGet(questionId, options) {
      return this._run(`${NAME$4.QUESTIONS}/${questionId}/answer`, undefined, { ...options, method: 'GET' });
    }

    async relatedQuestions(payload, options = {}) {
      return this._run(NAME$4.RELATED_QUESTIONS, payload, options);
    }

    async search(payload, options = {}) {
      const response = await this._run(NAME$4.SEARCH, payload, options);
      return response.question_id ? new SearchResult(this, response, options) : response;
    }

    async _searchGet(questionId, options) {
      return this._run(`${NAME$4.QUESTIONS}/${questionId}/answer`, undefined, { ...options, method: 'GET' });
    }

    async autocomplete(payload, options) {
      return this._run(NAME$4.AUTOCOMPLETE, payload, options);
    }

    async searchAutocomplete(payload, options) {
      return this._run(NAME$4.SEARCH_AUTOCOMPLETE, payload, options);
    }

  };

  class Answer extends IdBasedIterableApiStub {

    constructor(api, response, options = {}) {
      super(api, '_questionGet', response.question_id, options);
      this._response = response;
    }

    get questionId() {
      return this._id;
    }

  }

  class SearchResult extends IdBasedIterableApiStub {

    constructor(api, response, options = {}) {
      super(api, '_searchGet', response.question_id, options);
      defineValues(this, response);
      this._response = response;
    }

    get questionId() {
      return this._id;
    }

  }

  // helpers //
  function isId(value) {
    return typeof value === 'string' && value.charAt(0) !== '{';
  }

  const { GROUP: GROUP$2, NAME: NAME$3 } = API$1;

  let Search$1 = class Search extends ApiBase {

    constructor(api) {
      super(api, GROUP$2.SEARCH);
    }

    async search(payload, options) {
      return this._run(NAME$3.SEARCH, payload, options);
    }

    async autocomplete(payload, options) {
      return this._run(NAME$3.AUTOCOMPLETE, payload, options);
    }

    async multipleGet(payload, options) {
      return this._run(NAME$3.MGET, payload, options);
    }

  };

  const { GROUP: GROUP$1, NAME: NAME$2 } = API$1;

  let Recommendation$1 = class Recommendation extends ApiBase {

    constructor(api) {
      super(api, GROUP$1.RECOMMENDATION);
    }

    async userToProducts(payload, options) {
      return this._run(NAME$2.USER_TO_PRODUCTS, payload, options);
    }

    async userToCategories(payload, options) {
      return this._run(NAME$2.USER_TO_CATEGORIES, payload, options);
    }

    async userToAttributes(payload, options) {
      return this._run(NAME$2.USER_TO_ATTRIBUTES, payload, options);
    }

    async userToTrending(payload, options) {
      return this._run(NAME$2.USER_TO_TRENDING, payload, options);
    }

    async userToHistory(payload, options) {
      return this._run(NAME$2.USER_TO_HISTORY, payload, options);
    }

    async productToProducts(payload, options) {
      return this._run(NAME$2.PRODUCT_TO_PRODUCTS, payload, options);
    }

  };

  class Api extends Component {

    constructor(client, root) {
      super('api', client);
      this._client = client;
      this.helpers = new ApiHelpers(client, root);
      this.interactions = new Interactions(this);
      this.ask = new Ask$1(this);
      this.search = new Search$1(this);
      this.recommendation = new Recommendation$1(this);
    }

  }

  var api$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    Api: Api,
    ApiBase: ApiBase,
    ApiHelpers: ApiHelpers,
    Ask: Ask$1,
    Interactions: Interactions,
    Recommendation: Recommendation$1,
    Search: Search$1
  });

  let Context$1 = class Context extends Component {

    constructor(client) {
      super('context', client);
      this._client = client;
    }

  };

  var classes = {
    api: api$1,
    context: { Context: Context$1 },
  };

  class AnonymousPlugin {

    constructor(install) {
      defineValues(this, { install });
    }

  }

  function getPluginScriptUrl(id, version, currentScript) {
    // TODO: look up by manifest
    const pkgName = id.slice(4);
    
    if (version === 'dev') {
      const src = currentScript.src;
      const searchIndex = src.indexOf('?');
      const k = searchIndex < 0 ? src.length : searchIndex;
      const i = src.lastIndexOf('/', k) + 1;
      const j = src.indexOf('.', i);
      const ext = j < 0 ? '' : src.slice(j, k); // .min.js or .js
      return `${src.slice(0, i)}plugins/${pkgName}${ext}`;
    } else {
      return `https://cdn.jsdelivr.net/npm/@miso.ai/client-sdk@${version}/dist/umd/plugins/${pkgName}.min.js`;
    }
  }

  class PluginRoot extends Registry {

    constructor(root) {
      super('plugins', root, {
        libName: 'plugin class',
        keyName: 'id',
      });
      this._root = root;
      this._currentScript = document.currentScript;
      this._events._replays.add('install').add('subtree');
      this._installed = {};
      this._installedResolutions = {};
      this._useRequests = {};
      this._subtrees = [];
      this.context = new PluginContext(this, classes);
      this.plugins = new Plugins(this);
    }

    isInstalled(id) {
      this._checkKey(id);
      return !!this._installed[id];
    }

    get installed() {
      return Object.values(this._installed);
    }

    get(id) {
      return this._installed[id];
    }

    getPluginClass(id) {
      return this._libraries[id];
    }

    // TODO: we should be able to support (Class1, Class2, options2, etc.)
    // TODO: refactor use() and _instantiate()
    use(plugin, options) {
      // use(PluginClass) is a shortcut of register() then use()
      if (typeof plugin === 'function' && plugin.id && typeof plugin.id === 'string') {
        this.register(plugin);
        this.use(plugin.id, options);
        return;
      }
      let instance;
      if (typeof plugin === 'string' && this.isInstalled(plugin)) {
        // if already installed, try to run config() instead
        instance = this.get(plugin);
        this._tryConfig(instance, options);
        return;
      }
      if (typeof plugin === 'string' && !this.isRegistered(plugin)) {
        // not registered yet, push a use request
        (this._useRequests[plugin] || (this._useRequests[plugin] = [])).push(options);
        return;
      }
      instance = this._instantiate(plugin, options);
      this._install(instance);
    }

    async install(plugin, options) {
      this.use(plugin, options);
      if (typeof plugin === 'string' && !this.isRegistered(plugin)) {
        await this._tryRegisterRemotely(plugin);
      }
      return this.whenInstalled(plugin);
    }

    async whenInstalled(id) {
      if (typeof id === 'function' && id.id && typeof id.id === 'string') {
        id = id.id;
      }
      if (this.isInstalled(id)) {
        return this.get(id);
      }
      const { promise } = this._installedResolutions[id] || (this._installedResolutions[id] = new Resolution());
      return promise;
    }

    addSubtree(component) {
      this._subtrees.push(component);
      this._events.emit('subtree', component);
    }

    addPayloadPass(pass) {
      if (typeof pass !== 'function') {
        throw new Error(`Expect parameter to be a function: ${pass}`);
      }
      this._root._payloadPasses.push(pass);
    }

    addUrlPass(pass) {
      if (typeof pass !== 'function') {
        throw new Error(`Expect parameter to be a function: ${pass}`);
      }
      this._root._urlPasses.push(pass);
    }

    setCustomFetch(fetch) {
      if (typeof fetch !== 'function') {
        throw new Error(`Expect parameter to be a function: ${fetch}`);
      }
      this._root._customFetch = fetch;
    }

    setCustomSendBeacon(sendBeacon) {
      if (typeof sendBeacon !== 'function') {
        throw new Error(`Expect parameter to be a function: ${sendBeacon}`);
      }
      this._root._customSendBeacon = sendBeacon;
    }

    onHubUpdate(callback) {
      if (typeof callback !== 'function') {
        throw new Error(`Expect parameter to be a function: ${callback}`);
      }
      this._root._hubUpdateCallbacks.push(callback);
    }

    onHubEmit(callback) {
      if (typeof callback !== 'function') {
        throw new Error(`Expect parameter to be a function: ${callback}`);
      }
      this._root._hubEmitCallbacks.push(callback);
    }

    _tryConfig(instance, options) {
      if (options === undefined) {
        return;
      }
      if (typeof instance.config === 'function') {
        instance.config(options);
        this._events.emit('config', [instance, options]);
      } else {
        this._warn(`Attempt to pass options to plugin "${instance.id}", which offers no config() method.`);
      }
    }

    _instantiate(plugin, options) {
      switch (typeof plugin) {
        case 'string':
          this._checkKey(plugin);
          const pluginClass = this._libraries[plugin];
          if (!pluginClass) {
            throw new Error(`Plugin class not found: ${plugin}`);
          }
          const instance = new pluginClass();
          defineValues(instance, { id: plugin });
          this._tryConfig(instance, options);
          return instance;
        case 'function':
          return new AnonymousPlugin(plugin);
      }
      throw new Error(`Unexpected parameters: ${plugin}`);
    }

    _install(instance) {
      if (typeof instance.install !== 'function') {
        // TODO: introduce PluginError
        throw new Error(`Expect plugin.install to be a function: ${instance}`);
      }
      try {
        instance.installed = false;
        instance.install(this.MisoClient, this.context);
        instance.installed = true;
      } catch(e) {
        // TODO: introduce PluginError
        throw e;
      }
      if (instance.id) {
        // we don't track anonymous plugins
        this._installed[instance.id] = instance;
        if (this._installedResolutions[instance.id]) {
          this._installedResolutions[instance.id].resolve(instance);
          delete this._installedResolutions[instance.id];
        }
      }
      this._events.emit('install', instance);
    }

    _register(lib) {
      super._register(lib);
      this._fulfillUseRequests(lib.id);
    }

    _fulfillUseRequests(id) {
      const requests = this._useRequests[id];
      if (requests) {
        for (const options of requests) {
          try {
            this.use(id, options);
          } catch(e) {
            this._error(e);
          }
        }
        delete this._useRequests[id];
      }
    }

    async _tryRegisterRemotely(id) {
      if (id.startsWith('std:')) {
        try {
          await this._registerStdRemotely(id);
          return;
        } catch(e) {
          console.error(e);
        }
      }
      // TODO: try as URL
      throw new Error(`Cannot register plugin remotely: ${id}`);
    }

    async _registerStdRemotely(id) {
      const { version } = this._root;
      const request = version === 'dev' ? `plugin:${id}@dev:${this.MisoClient.uuid}` : `plugin:${id}@${version}`;

      // check if such script already exists
      if (!document.querySelector(`script[data-request="${request}"]`)) {
        // skip if already exists
        const script = document.createElement('script');
        script.async = true;
        script.src = getPluginScriptUrl(id, version, this._currentScript);
        script.setAttribute('data-request', request);
        document.head.appendChild(script);
        // TODO: hook up error event
      }

      // TODO: fine tune
      const Plugin = await new get().get(request);
      !this.isRegistered(id) && this.register(Plugin);
    }

  }

  /**
   * The interface of extended features only for plugin developers.
   */
  class PluginContext {

    constructor(root, classes) {
      delegateGetters(this, root, ['getPluginClass', 'addSubtree', 'addPayloadPass', 'addUrlPass', 'setCustomFetch', 'setCustomSendBeacon', 'onHubUpdate', 'onHubEmit', 'whenInstalled', 'whenRegistered']);
      defineValues(this, { classes });
    }

  }

  /**
   * The interface of plugin features exposed to MisoClient.
   */
   class Plugins {

    constructor(root) {
      delegateGetters(this, root, ['installed', 'registered', 'isInstalled', 'isRegistered', 'whenInstalled', 'whenRegistered', 'get', 'register', 'use', 'install']);
    }

  }

  /**
   * The hidden singleton root component that oversees all client components.
   */
  class Root extends Component {

    constructor() {
      super();
      this._events._replays.add('create');
      this._pluginRoot = new PluginRoot(this);
      this._clients = [];
      this._payloadPasses = [];
      this._urlPasses = [];
      this._customFetch = undefined;
      this._customSendBeacon = undefined;
      this._hubUpdateCallbacks = [];
      this._hubEmitCallbacks = [];
      this.version = sdk_version ;
      this._cmdRes = new Resolution();
    }

    get instances() {
      return [ ...this._clients]; // write protection
    }

    async any() {
      return this._clients[0] || this._any || (this._any = (await this._events.once('create')).data);
    }

    get cmdDone() {
      return this._cmdRes.promise;
    }

  }

  const root$d = new Root();

  function init(MisoClient) {
    const pluginRoot = root$d._pluginRoot;
    root$d.MisoClient = pluginRoot.MisoClient = MisoClient;
    delegateGetters(MisoClient, root$d, ['version', 'instances', 'any', 'meta', 'on', 'once', 'cmdDone']);
    delegateGetters(MisoClient, pluginRoot, ['plugins']);
    return MisoClient;
  }

  function register(client) {
    root$d._clients.push(client);
    root$d._events.emit('create', client);
  }

  function setCmdDone() {
    root$d._cmdRes.resolve();
  }

  var helpers$3 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    debounce: debounce,
    viewable: viewable
  });

  const { currentScript: currentScript$1 } = document;

  let MisoClient$1 = class MisoClient extends Component {

    static attach() {
      (window.MisoClients || (window.MisoClients = [])).push(MisoClient);
      if (window.MisoClient) {
        if (window.MisoClient !== MisoClient) {
          // TODO: check version as well
          console.warn(`window.MisoClient already exists: (${window.MisoClient.version}).`);
        }
        return;
      }
      window.MisoClient = MisoClient;
    }

    // nop, will be replaced by DebugPlugin
    static debug() {}

    constructor(options) {
      super('client', root$d);
      this._config(options);

      this.context = new Context$1(this);
      this.api = new Api(this, root$d);

      register(this);
    }

    get version() {
      return MisoClient.version;
    }

    _config(options) {
      this.options = Object.freeze(this._normalizeOptions(options));
    }

    _normalizeOptions(options = {}) {
      if (typeof options === 'string') {
        options = { apiKey: options };
      }
      if (options.readConfigFromScriptUrl) {
        options = {
          ...this._readConfigFromScriptUrl(),
          ...options,
        };
      }
      if (!options.apiKey) {
        throw new Error('Require API key to initialize miso client.');
      }

      options.dataEndpoint = options.dataEndpoint || options.apiHost;
      options.eventEndpoint = options.eventEndpoint || options.apiHost;
      delete options.apiHost;

      return trimObj(options);
    }

    _readConfigFromScriptUrl() {
      const url = currentScript$1.src || currentScript$1.href; // might be <link> as well
      const params = new URL(new Request(url).url).searchParams;
      return trimObj({
        apiKey: params.get('api_key') || undefined,
      });
    }

  };

  MisoClient$1.helpers = helpers$3;

  defineValues(MisoClient$1, {
    uuid: uuidv4(),
  });

  var MisoClient$2 = init(MisoClient$1);

  const { GROUP, NAME: NAME$1 } = API$1;

  const PLUGIN_ID$4 = 'std:user';

  class UserPlugin extends Component {

    static get id() {
      return PLUGIN_ID$4;
    }

    constructor() {
      super('user');
      this._contexts = new WeakMap();
    }

    install(MisoClient, context) {
      context.addSubtree(this);
      MisoClient.on('create', this._injectClient.bind(this));
      context.addPayloadPass(this._modifyPayload.bind(this));
    }

    _injectClient(client) {
      const context = new UserContext(this);
      this._contexts.set(client, context);
      delegateProperties(client.context, context, ['anonymous_id', 'user_id', 'user_hash', 'user_type']);
    }

    _modifyPayload({ client, apiGroup, apiName, payload }) {
      if (apiGroup === GROUP.INTERACTIONS && apiName === NAME$1.UPLOAD) {
        return this._modifyPayloadForInteractions(client, payload);
      }
      if (apiGroup === GROUP.ASK && apiName === NAME$1.QUESTIONS) {
        return this._modifyPayloadForAsk(client, payload);
      }
      return this._modifyPayloadForOthers(client, payload);
    }

    _modifyPayloadForOthers(client, payload) {
      const { user_id, user_hash, anonymous_id } = client.context;
      const userInfo = user_id ? { user_id, user_hash } : { anonymous_id };
      return { ...userInfo, ...payload };
    }

    _modifyPayloadForAsk(client, payload) {
      const { user_id, user_hash, user_type, anonymous_id } = client.context;
      const userInfo = user_id ? { user_id, user_hash } : { anonymous_id };
      if (user_id && user_type) {
        userInfo.user_type = user_type;
      }
      return { ...userInfo, ...payload };
    }

    _modifyPayloadForInteractions(client, { data }) {
      const { anonymous_id, user_id } = client.context;
      const userInfo = trimObj({ anonymous_id, user_id });
      data = data.map(obj => ({ ...userInfo, ...obj }));
      return { data };
    }

  }

  let _pageBasedAutoAnonymousId;

  function getAutoAnonymousId() {
    // 1. Cache the value for the page
    // 2. Get and set the value from cookies/localStorage is possible
    // 3. In case cookies/localStorage are disabled, generate a new value for each page
    return _pageBasedAutoAnonymousId || (_pageBasedAutoAnonymousId = getOrComputeFromStorage('miso_anonymous_id', uuidv4));
  }

  class UserContext {

    constructor(plugin) {
      this._plugin = plugin;
    }

    get anonymous_id() {
      return this._anonymousId || getAutoAnonymousId();
    }

    set anonymous_id(value) {
      value = asString(value);
      this._anonymousId = value;
      this._plugin._events.emit('set', `anonymous_id = '${value}'`);
    }

    get user_id() {
      return this._userId;
    }

    set user_id(value) {
      value = asString(value);
      this._userId = value;
      this._plugin._events.emit('set', `user_id = '${value}'`);
    }

    get user_hash() {
      return this._userHash;
    }

    set user_hash(value) {
      if (typeof value !== 'string' && typeof value !== 'undefined') {
        throw new Error(`User hash must be a string`);
      }
      this._userHash = value;
      this._plugin._events.emit('set', `user_hash = '${value}'`);
    }

    get user_type() {
      return this._userType;
    }

    set user_type(value) {
      this._userType = value;
      this._plugin._events.emit('set', `user_type = '${value}'`);
    }

  }

  const ID$4 = 'std:page-info';

  class PageInfoPlugin {

    static get id() {
      return ID$4;
    }

    constructor() {
    }

    install(_, { addPayloadPass }) {
      addPayloadPass(this._modifyPayload.bind(this));
    }

    _modifyPayload({ apiGroup, apiName, payload }) {
      return apiGroup === 'interactions' && apiName === 'upload' ?
        this._modifyPayloadForInteractions(payload) : payload;
    }

    _modifyPayloadForInteractions({ data }) {
      data = data.map(obj => ({
        ...obj,
        context: {
          ...getPayloadContext(),
          ...obj.context,
        },
      }));
      return { data };
    }

  }

  function getPayloadContext() {
    return trimObj({
      page: readPageInfo(),
      campaign: readUtm()
    });
  }

  function readPageInfo() {
    return trimObj({
      url: window.location.href,
      referrer: document.referrer || undefined,
      title: document.title,
    });
  }

  function readUtm() {
    const params = new URLSearchParams(window.location.search);
    let utm = trimObj({
      source: params.get('utm_source') || undefined,
      medium: params.get('utm_medium') || undefined,
      name: params.get('utm_campaign') || undefined,
      term: params.get('utm_term') || undefined,
      content: params.get('utm_content') || undefined,
    });
    return Object.keys(utm).length === 0 ? undefined : utm;
  }

  const PLUGIN_ID$3 = 'std:auto-events';

  class AutoEventsPlugin extends Component {

    static get id() {
      return PLUGIN_ID$3;
    }

    constructor() {
      super('auto-events');
      this._contexts = new WeakMap();
    }

    install(MisoClient, context) {
      context.addSubtree(this);
      MisoClient.on('create', this._injectClient.bind(this));
      context.addPayloadPass(this._captureApiRequest.bind(this));
    }

    _injectClient(client) {
      const context = new AutoEventsContext(this);
      this._contexts.set(client, context);
      client.autoEvents = context.interface;
    }

    _captureApiRequest({ client, apiGroup, apiName, payload }) {
      switch (apiGroup) {
        case GROUP$5.SEARCH:
          switch (apiName) {
            case NAME$6.SEARCH:
              this._captureSearchApiRequest(client, payload);
              break;
          }
          break;
      }
    }

    _captureSearchApiRequest(client, { q: keywords }) {
      if (!keywords || keywords === '*') {
        // might be a facet search without real keywords
        return;
      }
      const context = this._contexts.get(client);
      if (!context || !context._config.search) {
        return;
      }
      client.api.interactions.upload({
        type: 'search',
        search: { keywords },
        context: { custom_context: { channel: 'miso_api' } },
      });
    }

  }

  class AutoEventsContext {

    constructor(plugin) {
      this._plugin = plugin;
      this._config = {
        search: true,
      };
      this.interface = Object.freeze({
        config: this.config.bind(this),
      });
    }

    config(options = {}) {
      if (typeof options !== 'object') {
        throw new Error(`Config options must be an object or undefined: ${options}`);
      }
      for (const key of options) {
        if (!this._config.hasOwnProperty(key)) {
          continue;
        }
        const oldValue = this._config[key];
        const newValue = options[key];
        if (newValue !== oldValue) {
          this._config[key] = oldValue;
          this._plugin._events.emit('config', `${key}: ${oldValue} -> ${newValue}`);
        }
      }
      return Object.freeze({
        ...this._config,
      });
    }

  }

  const ID$3 = 'std:interactions';

  class InteractionsPlugin {

    static get id() {
      return ID$3;
    }

    constructor() {
    }

    install(_, { addPayloadPass }) {
      addPayloadPass(this._modifyPayload.bind(this));
    }

    _modifyPayload({ apiGroup, apiName, payload }) {
      return apiGroup === 'interactions' && apiName === 'upload' ?
        this._modifyPayloadForInteractions(payload) : payload;
    }

    _modifyPayloadForInteractions({ data }) {
      return { data: data.map(modifyInteractionRecord) };
    }

  }

  function modifyInteractionRecord(record) {
    const { context = {} } = record;
    const custom_context = {
      ...context.custom_context,
      sdk_version,
    };
    if (!custom_context.uuid) {
      custom_context.uuid = uuidv4();
    }
    return {
      ...record,
      context: {
        ...context,
        custom_context,
      },
    };
  }

  const PLUGIN_ID$2 = 'std:native-fetch';

  function isNativeFunction(fn) {
    return fn.toString().indexOf("[native code]") > -1;
  }

  let _fetchSource;
  let _fetchError;

  const fetchFn = (() => {
    if (isNativeFunction(window.fetch)) {
      _fetchSource = 'original';
      return window.fetch;
    }
    try {
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      document.head.appendChild(iframe); // in case body is not available yet
      // don't remove the iframe to keep the fetch function alive
      _fetchSource = 'borrowed';
      return iframe.contentWindow.fetch;
    } catch (e) {
      _fetchError = e;
    }
    return undefined;
  })();

  class NativeFetchPlugin {

    static get id() {
      return PLUGIN_ID$2;
    }

    install(MisoClient, context) {
      if (!fetchFn) {
        MisoClient.debug(`<plugin:${PLUGIN_ID$2}>`, '[error]', `Failed to obtain native fetch: ${_fetchError.message}`);
        return;
      }
      context.setCustomFetch(fetchFn);
      MisoClient.debug(`<plugin:${PLUGIN_ID$2}>`, '[info]', `Using ${_fetchSource} native fetch`);
    }

  }

  const PLUGIN_ID$1 = 'std:api';

  class ApiPlugin extends Component {

    static get id() {
      return PLUGIN_ID$1;
    }

    constructor() {
      super('api');
    }

    install(MisoClient, context) {
      context.addSubtree(this);
      context.addPayloadPass(this._suppressMetaObject.bind(this));
    }

    _suppressMetaObject(args) {
      if (!this._shallSuppressMetaObject(args)) {
        return args.payload;
      }
      const { payload: { _meta, ...payload } = {} } = args;
      return payload;
    }

    _shallSuppressMetaObject({ apiGroup, apiName }) {
      switch (apiGroup) {
        case GROUP$5.SEARCH:
        case GROUP$5.RECOMMENDATION:
          return true;
      }
      return false;
    }

  }

  const LOGS_UI_ROOT_ID = 'miso-logdump';
  const LOGS_UI_ROOT_CLASS = 'miso-logdump';
  const LOGS_UI_BUTTON_CLASS = `${LOGS_UI_ROOT_CLASS}__download-btn`;
  const DEFAULT_DOWNLOAD_BUTTON_TEXT = 'Miso Log';

  class Logs {

    constructor(options = {}) {
      this._options = options;
      this._logs = [];
    }

    config(options = {}) {
      this._options = {
        ...this._options,
        ...options,
      };
    }

    async showDownloadButton() {
      await loadStyles();
      let element = document.getElementById(LOGS_UI_ROOT_ID);
      if (!element) {
        const button = document.createElement('div');
        button.textContent = this._options.logDownloadButtonText || DEFAULT_DOWNLOAD_BUTTON_TEXT;
        button.classList.add(LOGS_UI_BUTTON_CLASS);
        button.addEventListener('click', () => this.download());

        element = document.createElement('div');
        element.id = LOGS_UI_ROOT_ID;
        element.classList.add(LOGS_UI_ROOT_CLASS);
        element.appendChild(button);

        document.body.appendChild(element);
      }
      element.style.display = 'block';
    }

    _syncUi() {
      const element = document.getElementById(LOGS_UI_ROOT_ID);
      const button = element && element.querySelector(`.${LOGS_UI_BUTTON_CLASS}`);
      if (button) {
        button.textContent = this._options.logDownloadButtonText || DEFAULT_DOWNLOAD_BUTTON_TEXT;
      }
    }

    hideDownloadButton() {
      const element = document.getElementById(LOGS_UI_ROOT_ID);
      if (element) {
        element.style.display = 'none';
      }
    }

    download() {
      const logs = this._logs;
      const blob = new Blob([exportLog(logs)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = this._filename();
      a.click();
    }

    _filename() {
      let { logFilename } = this._options;
      if (typeof logFilename === 'function') {
        const timestamp = getTimestampSegment();
        logFilename = logFilename({ timestamp });
      }
      if (logFilename && typeof logFilename === 'string') {
        return logFilename;
      }
      return getDefaultFileName();
    }

    clear() {
      this._logs = [];
    }

  }

  function getDefaultFileName() {
    return `miso-log.${getTimestampSegment()}.jsonl`;
  }

  function getTimestampSegment() {
    return new Date().toISOString().replaceAll(/[\:\.]/g, '-');
  }

  function exportLog(logs) {
    return logs.map(log => JSON.stringify(dumpValue(shimLog(log), { depth: 10 }))).join('\n');
  }

  function shimLog(log) {
    if (log[0] === '<progressive-markdown>') {
      const len = log.length;
      return [...log.slice(0, len - 1), shimProgressiveMarkdownPosition(log[len - 1])];
    }
    return log;
  }

  function shimProgressiveMarkdownPosition(pos) {
    return pos ? dumpValue(pos, { depth: 2 }) : pos;
  }

  let stylesLoaded$1;

  async function loadStyles() {
    return stylesLoaded$1 || (stylesLoaded$1 = loadStyles$1(resolveCssUrl('logdump')));
  }

  const ID$2 = 'std:debug';

  class DebugPlugin {

    constructor(options = {}) {
      this._options = options;
      this._logs = new Logs(options);
    }

    static get id() {
      return ID$2;
    }

    install(MisoClient) {
      this._injectComponents(MisoClient);
      MisoClient.debug = (...args) => this._logr(...args);
      MisoClient.logs = this._logs;
    }

    config(options = {}) {
      this._options = {
        ...this._options,
        ...options,
      };
      this._logs.config(options);
      if (options.preserveLog) {
        this._log(ID$2, 'ua', window.navigator.userAgent);
      }
    }

    _injectComponents(component, treePath = []) {
      component.on('child', (c) => this._injectComponents(c, treePath));
      component.on('subtree', (c) => this._injectComponents(c, treePath.concat(component.meta.path)));
      component.on('*', (data, meta) => this._handleEvent(component, meta, data, treePath));
    }

    _handleEvent(component, { name }, data, treePath = []) {
      if (name === 'child' || name === 'subtree') {
        return;
      }
      const path = treePath.concat(component.meta.path);
      if (!path.length) {
        switch (name) {
          case 'create':
            this._handleCreateClient(name, data);
            return;
        }
      }
      switch (path[0]) {
        case 'client':
          switch (path[1]) {
            case 'api':
              this._handleApiEvent(name, { ...data, groupName: path[2] });
              return;
          }
          break;
        case 'plugins':
          if (path.length === 1) {
            this._handlePluginsEvent(name, data);
          } else {
            this._handlePluginSpecificEvent(path[1], path.slice(2), name, data);
          }
          return;
      }
      this._logw(path.join('.'), name, data);
    }

    _handleCreateClient(eventName, data) {
      this._logw('client', eventName, data);
    }

    _handleApiEvent(eventName, { groupName, apiName, url, bulk, ...data }) {
      const pathname = new URL(url).pathname;
      const args = ['api', eventName];

      bulk && args.push(`(bulk ${bulk.bulkId})`);

      args.push(`POST ${pathname}`);

      if (groupName === 'interactions') {
        // TODO: handle multiple interactions
        const record = data.payload.data[0];
        const { type, custom_action_name, context: { custom_context: { property } = {} } = {} } = record;
        const name = type === 'custom' && custom_action_name ? `${type}:${custom_action_name}` : type;
        args.push(property ? `${name} (${property})` : `${name}`);
      }

      args.push([{ ...data, url }]);

      this._log(...args);
    }

    _handlePluginsEvent(eventName, plugin) {
      let data = [];
      if (Array.isArray(plugin)) {
        data = plugin.slice(1);
        plugin = plugin[0];
      }
      this._log('plugins', eventName, `${plugin.id || '(anonymous)'}`, [plugin, ...data]);
    }

    _handlePluginSpecificEvent(pluginId, path, name, data) {
      this._logw([pluginId, path.join('.')], name, data);
    }

    _getPath(component) {
      const path = [];
      for (let c = component; c; c = c.meta.parent) {
        c.meta.name && path.push(c.meta.name);
      }
      return path.reverse();
    }

    _logw(path, name, data) {
      if (data === undefined) {
        this._log(path, name);
      } else if (Array.isArray(data)) {
        this._log(path, name, ...data.map(_wrapObj));
      } else {
        this._log(path, name, _wrapObj(data));
      }
    }

    _log(path, name, ...data) {
      this._logr(_path(path), _name(name), ...data);
    }

    _logr(...data) {
      const options = this._options.console || {};
      if (this._options.preserveLog) {
        this._logs._logs.push(data);
      }
      console.log(_tag(options), _style(options), ...data);
    }

  }

  function _tag({ text = 'Miso' } = {}) {
    return `%c${text}`;
  }

  function _style({ color = '#fff', background = '#334cbb' } = {}) {
    return `color: ${color}; background-color: ${background}; padding: 2px 2px 1px 4px;`;
  }

  // format path
  function _path(path) {
    return `<${typeof path === 'string' ? path : path.filter(v => v).join('/')}>`;
  }

  // format event name
  function _name(name) {
    return `[${name}]`;
  }

  function _wrapObj(value) {
    const type = typeof value;
    return type === 'function' || (type === 'object' && !Array.isArray(value)) ? [value] : value;
  }

  const ID$1 = 'std:dry-run';

  class DryRunPlugin {

    constructor(options = {}) {
      this._options = options;
      this.id = 'std:dry-run';
      this.name = 'dry-run';
    }

    static get id() {
      return ID$1;
    }

    // TODO: config({ active })

    install(_, { addUrlPass }) {
      addUrlPass(this._modifyUrl.bind(this));
    }

    _modifyUrl({ apiGroup, apiName, url }) {
      return apiGroup === 'interactions' && apiName === 'upload' ? addUrlParameter(url, 'dry_run', '1') : url;
    }

  }

  function randomInt(min, max) {
    return max == null || (max <= min) ? min : (min + Math.floor(Math.random() * (max - min + 1)));
  }

  // TODO: ref link
  // TODO: autolink
  // TODO: hard line break

  const INLINE_FEATURES = {
    'code-span': () => ['`', '`'],
    'emphasis-1': () => multiply(_emphasisAdfix(1), 2),
    'emphasis-2': () => multiply(_emphasisAdfix(2), 2),
    'emphasis-3': () => multiply(_emphasisAdfix(3), 2),
    'strikethrough': () => ['~', '~'],
    'link': ({ url = 'https://miso.ai' } = {}) => [`[`, `](${url})`],
  };

  function _emphasisAdfix(level = [1, 3]) {
    level = typeof level === 'number' ? level : randomInt(...level);
    return '_*'.charAt(randomInt(0, 1)).repeat(level);
  }

  const INLINE_FEATURE_LIST = Object.keys(INLINE_FEATURES);
  new Set(INLINE_FEATURE_LIST);

  function multiply(obj, i) {
    const arr = [];
    for (let j = 0; j < i; j++) {
      arr.push(typeof obj === 'function' ? obj() : obj);
    }
    return arr;
  }

  MisoClient$2.plugins.register(DebugPlugin, DryRunPlugin, NativeFetchPlugin);
  MisoClient$2.plugins.use(UserPlugin);
  MisoClient$2.plugins.use(PageInfoPlugin);
  MisoClient$2.plugins.use(AutoEventsPlugin);
  MisoClient$2.plugins.use(InteractionsPlugin);
  MisoClient$2.plugins.use(ApiPlugin);

  function mergeRolesOptions(base, overrides) {
    return Object.freeze({
      ...base,
      ...overrides,
      members: mergeRolesMembers(base.members, overrides.members),
      mappings: Object.freeze({ ...base.mappings, ...overrides.mappings }),
    });
  }

  function mergeRolesMembers(base = [], overrides = []) {
    return [...new Set([...base, ...overrides])];
  }

  function concatArrays(a0, a1) {
    return (a0 && a0.length) ? (a1 && a1.length) ? [...a0, ...a1] : a0 : a1;
  }

  function mergeOptions$2(optionsList, merge) {
    let merged = {};
    for (const options of optionsList) {
      if (!options) {
        continue;
      }
      merged = merge(merged, options);
    }
    return trimObj(merged);
  }

  function normalizeOptions$1(options) {
    if (options === undefined) {
      throw new Error(`Expect options to be an object or a boolean value: ${options}`);
    }
    if (typeof options === 'boolean') {
      options = { active: options };
    }
    return options;
  }

  function normalizeApiOptions([name, payload] = []) {
    // TODO: take object form as well
    if (name === false) {
      return { actor: false };
    }
    if (typeof name === 'object' && payload === undefined) {
      payload = name;
      name = undefined;
    }
    let group = undefined;
    if (name && name.indexOf('/') !== -1) {
      [group, name] = name.split('/');
    }
    if ((name && typeof name !== 'string') || (payload !== undefined && typeof payload !== 'object')) {
      throw new Error(`Invalid arguments for useApi(): ${name}, ${payload}`);
    }
    return trimObj({ group, name, payload });
  }

  function mergeApiOptions(...optionsList) {
    if (optionsList[optionsList.length - 1] === false) {
      return false;
    }
    return mergeOptions$2(optionsList, (merged, options) => Object.assign(merged, {
      ...options,
      payload: mergeApiPayloads(merged.payload, options.payload),
    }));
  }

  function mergeApiPayloads(base, overrides) {
    return {
      ...base,
      ...overrides,
      ...mergeObjectValueIfPresent('_meta', base, overrides),
    };
  }

  function mergeObjectValueIfPresent(key, base, overrides) {
    const baseValue = base && base[key];
    const overridesValue = overrides && overrides[key];
    const value = baseValue ? (overridesValue ? { ...baseValue, ...overridesValue } : baseValue) : overridesValue;
    return value !== undefined ? { [key]: value } : {};
  }

  const ATTR_DATA_MISO_PRODUCT_ID = `data-miso-product-id`;
  const DEFAULT_UNIT_ID = 'default';
  const ORGANIC_QUESTION_SOURCE = '_organic';

  const ROLE = Object.freeze({
    CONTAINER: 'container',
    BANNER: 'banner',
    QUERY: 'query',
    FEEDBACK: 'feedback',
    PRODUCTS: 'products',
    CATEGORIES: 'categories',
    ATTRIBUTES: 'attributes',
    RESULTS: 'results',
    ITEMS: 'items',
    QUESTION: 'question',
    ANSWER: 'answer',
    IMAGES: 'images',
    SOURCES: 'sources',
    RELATED_RESOURCES: 'related_resources',
    QUERY_SUGGESTIONS: 'query_suggestions',
    RELATED_QUESTIONS: 'related_questions',
    AFFILIATION: 'affiliation',
    KEYWORDS: 'keywords',
    FACETS: 'facets',
    TOTAL: 'total',
    MORE: 'more',
    SORT: 'sort',
    ERROR: 'error',
  });

  const DATA_ROLE_SET = new Set([
    ROLE.PRODUCTS,
    ROLE.CATEGORIES,
    ROLE.ATTRIBUTES,
    ROLE.RESULTS,
    ROLE.ITEMS,
    ROLE.QUESTION,
    ROLE.ANSWER,
    ROLE.IMAGES,
    ROLE.SOURCES,
    ROLE.RELATED_RESOURCES,
    ROLE.QUERY_SUGGESTIONS,
    ROLE.RELATED_QUESTIONS,
    ROLE.AFFILIATION,
    ROLE.FACETS,
    ROLE.TOTAL,
  ]);

  function isDataRole(role) {
    return DATA_ROLE_SET.has(role);
  }

  const PRODUCT_ROLE_SET = new Set([
    ROLE.PRODUCTS,
    ROLE.IMAGES,
    ROLE.SOURCES,
    ROLE.RELATED_RESOURCES,
  ]);

  function isProductRole(role) {
    return PRODUCT_ROLE_SET.has(role);
  }

  const EVENT_TYPE = Object.freeze({
    IMPRESSION: 'impression',
    VIEWABLE: 'viewable',
    CLICK: 'click',
    SUBMIT: 'submit',
    FEEDBACK: 'feedback',
  });

  const TRACKING_EVENT_TYPES = [
    EVENT_TYPE.IMPRESSION,
    EVENT_TYPE.VIEWABLE,
    EVENT_TYPE.CLICK,
    EVENT_TYPE.SUBMIT,
    EVENT_TYPE.FEEDBACK,
  ];

  const PERFORMANCE_EVENT_TYPES = [
    EVENT_TYPE.IMPRESSION,
    EVENT_TYPE.VIEWABLE,
    EVENT_TYPE.CLICK,
  ];

  const PERFORMANCE_EVENT_TYPE_SET = new Set(PERFORMANCE_EVENT_TYPES);

  function isPerformanceEventType(type) {
    return PERFORMANCE_EVENT_TYPE_SET.has(type);
  }

  const TRACKING_STATUS = Object.freeze({
    UNTRACKED: 'untracked',
    TRACKING: 'tracking',
    TRIGGERED: 'triggered',
  });

  const STATUS = Object.freeze({
    INITIAL: 'initial',
    LOADING: 'loading',
    ERRONEOUS: 'erroneous',
    READY: 'ready',
    ONGOING: 'ongoing',
    DONE: 'done',
    EMPTY: 'empty',
    NONEMPTY: 'nonempty',
    UNANSWERABLE: 'unanswerable',
  });

  function validateEventType(value) {
    if (TRACKING_EVENT_TYPES.indexOf(value) < 0) {
      throw new Error(`Unrecognized event type: ${value}`);
    }
  }

  function validateTrackingStatus(value) {
    if (value !== TRACKING_STATUS.UNTRACKED && value !== TRACKING_STATUS.TRACKING && value !== TRACKING_STATUS.TRIGGERED) {
      throw new Error(`Unrecognized tracking status: ${value}`);
    }
  }

  const WORKFLOW_CONFIGURABLE = Object.freeze({
    API: 'api',
    LAYOUTS: 'layouts',
    DATA_PROCESSOR: 'dataProcessor',
    TRACKERS: 'trackers',
    INTERACTIONS: 'interactions',
    FILTERS: 'filters',
    PAGINATION: 'pagination',
  });

  function normalizeLayoutsOptions(options = {}) {
    if (options === false) {
      return false;
    }
    // fallback: results -> products
    const { results, ...rest } = options;
    if (results !== undefined) {
      console.warn(`useLayouts({ results: ... }) is deprecated, use useLayouts({ ${ROLE.PRODUCTS}: ... }) instead`);
      options = { ...rest, [ROLE.PRODUCTS]: results };
    }
    const normalize = {};
    for (const [role, args] of Object.entries(options)) {
      normalize[normalizeRole(role)] = normalizeLayoutOptions(args);
    }
    return normalize;
  }

  function normalizeRole(role) {
    role = lowerCamelToSnake(role);
    role = kebabToSnake(role);
    return role;
  }

  function normalizeLayoutOptions(args) {
    // take args:
    // * undefined
    // * false
    // * name (string)
    // * options (object)
    // * [name, options]
    if (args === undefined) {
      return undefined;
    }
    let [name, options] = asArray(args);
    if (typeof name === 'object') {
      options = name;
      name = undefined;
    }
    return [name, options];
  }

  function mergeLayoutsOptions(...optionsList) {
    if (optionsList[optionsList.length - 1] === false) {
      return false;
    }
    return mergeOptions$2(optionsList, (merged, options) => {
      for (const [role, args] of Object.entries(options)) {
        merged[role] = mergeLayoutOptions(merged[role], args);
      }
      return merged;
    });
  }

  function mergeLayoutOptions(base, overrides) {
    overrides = normalizeLayoutOptions(overrides);
    if (overrides[0] === false) {
      return overrides;
    }
    return base && overrides ? [overrides[0] || base[0], mergeLayoutParameters(base[1], overrides[1])] : (overrides || base);
  }

  function mergeLayoutParameters(base, overrides) {
    return {
      ...base,
      ...overrides,
      link: { ...(base && base.link), ...(overrides && overrides.link) },
      templates: { ...(base && base.templates), ...(overrides && overrides.templates) },
    };
  }

  function normalizeDataProcessorOptions(fns) {
    fns = asArray(fns);
    for (const fn of fns) {
      if (typeof fn !== 'function') {
        throw new Error(`Expect data processor options to be a function: ${fn}`);
      }
    }
    return fns;
  }

  function mergeDataProcessorOptions(...optionsList) {
    return optionsList.flat().filter(Boolean);
  }

  const DEFAULT_TRACKER_OPTIONS$1 = Object.freeze({
    active: true,
    impression: Object.freeze({
      active: true,
    }),
    viewable: Object.freeze({
      active: true,
      area: 0.5,
      duration: 1000,
    }),
    click: Object.freeze({
      active: true,
      lenient: false,
    }),
  });

  function normalizeTrackersOptions(options = {}) {
    options = normalizeOptions$1(options);
    const { active, ...rest } = options;
    const normalized = {};
    for (const [role, args] of Object.entries(rest)) {
      normalized[role] = normalizeTrackerOptions$1(args);
    }
    return {
      active,
      ...normalized,
    };
  }

  function normalizeTrackerOptions$1(options = {}) {
    options = normalizeOptions$1(options);
    const { active, ...rest } = options;
    for (const [role, args] of Object.entries(rest)) {
      normalizeTrackerEventOptions(args);
    }
    return options;
  }

  function normalizeTrackerEventOptions(options = {}) {
    options = normalizeOptions$1(options);
    return options;
  }

  function mergeTrackersOptions(...optionsList) {
    // TODO: should be able to remove this
    if (optionsList[optionsList.length - 1] === false) {
      return false;
    }
    return mergeOptions$2(optionsList, (merged, options) => {
      for (const [key, args] of Object.entries(options)) {
        if (args === undefined) {
          continue;
        }
        merged[key] = key === 'active' ? args : mergeTrackerOptions(merged[key], args);
      }
      return merged;
    });
  }

  function mergeTrackerOptions(base = {}, overrides = {}) {
    const merged = { ...base };
    for (const [key, args] of Object.entries(overrides)) {
      if (args === undefined) {
        continue;
      }
      merged[key] = TRACKING_EVENT_TYPES.includes(key) ? mergeTrackerEventOptions(base[key], args) : args;
    }
    return merged;
  }

  function mergeTrackerEventOptions(base = {}, overrides = {}) {
    return {
      ...base,
      ...overrides,
    };
  }

  function normalizeInteractionsOptions(options) {
    if (options === undefined) {
      return undefined;
    }
    if (options === false) {
      return {
        handle: () => {},
      };
    }
    // preprocess
    const preprocess = asArray(options.preprocess);
    for (const p of preprocess) {
      if (typeof p !== 'function') {
        throw new Error(`Expect preprocess options to be a function: ${p}`);
      }
    }
    // handle
    if (options.handle && typeof options.handle !== 'function') {
      throw new Error(`Expect handle options to be a function: ${options.handle}`);
    }
    return { ...options, preprocess };
  }

  function mergeInteractionsOptions(...optionsList) {
    if (optionsList[optionsList.length - 1] === false) {
      return false;
    }
    return mergeOptions$2(optionsList, (merged, options) => Object.assign(merged, {
      ...options,
      preprocess: concatArrays(merged.preprocess, options.preprocess),
    }));
  }

  const normalizeFiltersOptions = normalizeOptions$1;

  function mergeFiltersOptions(...optionsList) {
    if (optionsList[optionsList.length - 1] === false) {
      return false;
    }
    return mergeOptions$2(optionsList, (merged, options) => Object.assign(merged, options));
  }

  function normalizePaginationOptions(options) {
    if (options === undefined) {
      throw new Error(`Expect pagination options to be an object or a boolean value: ${options}`);
    }
    if (typeof options === 'boolean') {
      options = { active: options };
    }
    return options;
  }

  function mergePaginationOptions(...optionsList) {
    if (optionsList[optionsList.length - 1] === false) {
      return false;
    }
    return mergeOptions$2(optionsList, (merged, options) => Object.assign(merged, options));
  }

  const FEATURES = [
    {
      key: WORKFLOW_CONFIGURABLE.API,
      normalize: normalizeApiOptions,
      merge: mergeApiOptions,
    },
    {
      key: WORKFLOW_CONFIGURABLE.LAYOUTS,
      normalize: normalizeLayoutsOptions,
      merge: mergeLayoutsOptions,
    },
    {
      key: WORKFLOW_CONFIGURABLE.DATA_PROCESSOR,
      normalize: normalizeDataProcessorOptions,
      merge: mergeDataProcessorOptions,
    },
    {
      key: WORKFLOW_CONFIGURABLE.TRACKERS,
      normalize: normalizeTrackersOptions,
      merge: mergeTrackersOptions,
    },
    {
      key: WORKFLOW_CONFIGURABLE.INTERACTIONS,
      normalize: normalizeInteractionsOptions,
      merge: mergeInteractionsOptions,
    },
    {
      key: WORKFLOW_CONFIGURABLE.FILTERS,
      normalize: normalizeFiltersOptions,
      merge: mergeFiltersOptions,
    },
    {
      key: WORKFLOW_CONFIGURABLE.PAGINATION,
      normalize: normalizePaginationOptions,
      merge: mergePaginationOptions,
    },
  ];



  class WorkflowContextOptions {

    constructor() {
      this._events = new EventEmitter({ target: this });
      this._globals = {};
    }

    _notify(name) {
      this._events.emit(name);
      this._events.emit('_update', name);
    }

  }

  class WorkflowOptions {

    constructor(context = {}, defaults = {}) {
      this._events = new EventEmitter({ target: this });
      this._defaults = defaults; // TODO: we should call normalize() on defaults
      this._context = context || {};
      this._locals = {};

      defineValues(this, {
        resolved: new ResolvedWorkflowOptions(this),
        defaults,
      });

      if (context && context.on) {
        this._unsubscribes = [
          context.on('_update', name => this._notify(name)),
        ];
      }
    }

    _notify(name) {
      this.resolved._invalidate(name);
      this._events.emit(name);
    }

    _destroy() {
      for (const unsubscribe of this._unsubscribes || []) {
        unsubscribe();
      }
      this._unsubscribes = [];
    }

  }

  class ResolvedWorkflowOptions {

    constructor(options) {
      this._options = options;
      this._cache = {};
    }

    _invalidate(key) {
      this._cache[key] = undefined;
    }

    _get({ key, merge }) {
      if (this._cache[key] === undefined) {
        const options = this._options;
        const contextFeature = options._context[key];
        this._cache[key] = merge(options._defaults[key], contextFeature && contextFeature.get(), options._locals[key]);
      }
      return this._cache[key];
    }

  }

  class WorkflowConfigurableFeature {

    constructor(options, store, key, normalize, merge) {
      this._options = options;
      this._store = store;
      this._key = key;
      this._normalize = value => value !== undefined ? normalize(value) : undefined;
      this._merge = merge;
    }

    get() {
      return this._store[this._key];
    }

    set(value) {
      this._set(this._normalize(value));
    }

    merge(value) {
      this._set(this._merge(this.get(), this._normalize(value)));
    }

    _set(value) {
      this._store[this._key] = value;
      this._options._notify(this._key);
    }

  }

  for (const feature of FEATURES) {
    const { key, normalize, merge } = feature;
    Object.defineProperty(WorkflowContextOptions.prototype, key, {
      get: function() {
        const _key = `_${key}`;
        return this[_key] || (this[_key] = new WorkflowConfigurableFeature(this, this._globals, key, normalize, merge));
      },
    });
    Object.defineProperty(WorkflowOptions.prototype, key, {
      get: function() {
        const _key = `_${key}`;
        return this[_key] || (this[_key] = new WorkflowConfigurableFeature(this, this._locals, key, normalize, merge));
      },
    });
    Object.defineProperty(ResolvedWorkflowOptions.prototype, key, {
      get: function() {
        return this._get(feature);
      },
    });
  }

  const DEFAULT_FEATURES = [
    WORKFLOW_CONFIGURABLE.API,
    WORKFLOW_CONFIGURABLE.LAYOUTS,
    WORKFLOW_CONFIGURABLE.DATA_PROCESSOR,
    WORKFLOW_CONFIGURABLE.TRACKERS,
    WORKFLOW_CONFIGURABLE.INTERACTIONS,
  ];

  function makeConfigurable(prototype, features = DEFAULT_FEATURES) {
    for (const feature of features) {
      injectConfigurableFeature(prototype, feature);
    }
  }

  function injectConfigurableFeature(prototype, feature) {
    if (feature === 'api') {
      Object.assign(prototype, {
        useApi(...args) {
          this._options.api.merge(args);
          return this;
        },
        clearApi() {
          this._options.api.set();
          return this;
        },
      });
    } else {
      const upperCased = upperCase(feature);
      Object.assign(prototype, {
        [`use${upperCased}`](value) {
          (this._options[feature]).merge(value);
          return this;
        },
        [`clear${upperCased}`]() {
          (this._options[feature]).set();
          return this;
        },
      });
    }
  }

  // helpers //
  // TODO: move to commons
  function upperCase(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  const DEFAULT_AUTO_QUERY_PARAM = 'q';
  const DEFAULT_AUTO_QUERY_SOURCE_PARAM = 'qs';

  function normalizeAutoQueryOptions({ setValue = true, focus = true, updateUrl = true, param = DEFAULT_AUTO_QUERY_PARAM, sourceParam = DEFAULT_AUTO_QUERY_SOURCE_PARAM, ...options } = {}) {
    return { setValue, focus, updateUrl, param, sourceParam, ...options };
  }

  function autoQuery(options = {}) {
    // TODO: support getting value from URL path
    const { setValue, focus, param, sourceParam } = this._autoQuery = normalizeAutoQueryOptions(options);
    const searchParams = new URLSearchParams(window.location.search);
    const q = searchParams.get(param);
    const qs = searchParams.get(sourceParam) || undefined;
    const { layout } = this._views.get(ROLE.QUERY);
    if (layout) {
      if (q && setValue) {
        layout.value = q;
      }
      if (!q && focus) {
        layout.focus();
      }
    }
    if (q) {
      this.query(trimObj({ q, qs }));
    }
  }

  class WorkflowContext extends Component {

    constructor(name, plugin, client) {
      super(name, plugin);
      this._plugin = plugin;
      this._client = client;
      this._options = new WorkflowContextOptions();
    }

  }

  makeConfigurable(WorkflowContext.prototype);

  function session() {
    return 'session';
  }

  function suggestions() {
    return 'suggestions';
  }

  function completions$1() {
    return 'completions';
  }

  function filters() {
    return 'filters';
  }

  function query$1() {
    return 'query';
  }

  function request() {
    return 'request';
  }

  function response() {
    return 'response';
  }

  function data() {
    return 'data';
  }

  function view(role) {
    return role ? `view:${role}` : 'view';
  }

  function tracker() {
    return 'tracker';
  }

  function interaction() {
    return 'interaction';
  }

  function feedback() {
    return 'feedback';
  }

  function input() {
    return 'input';
  }

  function more() {
    return 'more';
  }

  class Hub {

    constructor(options = {}) {
      (this._events = new EventEmitter())._injectSubscribeInterface(this);
      this._options = options;
      this._states = {};
      defineValues(this, {
        states: new Proxy(this._states, {
          set() {}
        }),
      });
    }

    update(name, state, options = {}) {
      this._states[name] = Object.freeze(state);
      const event = Object.freeze({ action: 'update', name, state, ...options });
      // callback after update, before emit
      if (typeof this._options.onUpdate === 'function') {
        this._options.onUpdate(event);
      }
      // emit
      if (!options.silent) {
        this._events.emit(name, state);
      }
      // callback after emit
      if (typeof this._options.onEmit === 'function') {
        this._options.onEmit(event);
      }
    }

    trigger(name, state) {
      const event = Object.freeze({ action: 'trigger', name, state });
      // callback before emit
      if (typeof this._options.onUpdate === 'function') {
        this._options.onUpdate(event);
      }
      // emit
      this._events.emit(name, state);
      // callback after emit
      if (typeof this._options.onEmit === 'function') {
        this._options.onEmit(event);
      }
    }

  }

  class SessionMaker {

    constructor(hub) {
      this._hub = hub;
      this._sessionIndex = 0;
    }

    restart() {
      const session$1 = Object.freeze({
        uuid: uuidv4(),
        index: this._sessionIndex++,
        meta: {},
      });
      this._hub.update(session(), session$1);
    }

  }

  function isCurrentSession(hub, session) {
    if (!session) {
      return false;
    }
    const { session: currentSession } = hub.states;
    return currentSession && currentSession.index === session.index;
  }

  class DataActor {

    constructor(hub, { source, options }) {
      this._hub = hub;
      this._source = source;
      this._options = options;
      this._unsubscribes = [
        hub.on(session(), session => this._handleSession(session)),
        hub.on(request(), event => this._handleRequest(event)),
      ];
    }

    get active() {
      return this._options.resolved.api.actor !== false;
    }

    get source() {
      return this._source;
    }

    _handleSession(session) {
      // this is mandatory in any case
      /*
      if (!this.active) {
        return;
      }
      */
      // abort ongoing data fetch if any
      if (!this._session || (session.index !== this._session.index)) {
        // new session, abort preview data fetch if necessary
        this._ac && this._ac.abort({
          type: 'new-session',
          message: 'A new session is created, discarding the old one.',
        });
        this._ac = new AbortController();
      }
      this._session = session;

      // TODO: move this to workflow
      // reflect session update
      this._emitResponse({ session });
    }

    async _handleRequest(event) {
      // protocol: inactive -> no reaction
      if (!this.active) {
        return;
      }
      const { session } = this._hub.states;
      const { session: _, ...request } = event;

      // emit response to update request
      this._emitResponse({ session, request });

      try {
        const { signal } = this._ac || {};
        const options = { ...event.options, signal };
        const response = await this._source({ session, ...event, options });
        // takes an iterable, either sync or async
        if (response && response[Symbol.asyncIterator]) {
          // also emit reponse of the head request, if available
          if (response._response) {
            this._emitResponseWithSessionCheck({ session, request, value: response._response });
          }
          let value;
          for await (value of response) {
            // A new session invalidates ongoing data fetch for the old session, terminating the loop
            if (!isCurrentSession(this._hub, session)) {
              break;
            }
            this._emitResponse({ session, request, value });
          }
        } else {
          this._emitResponseWithSessionCheck({ session, request, value: response });
        }
      } catch(error) {
        this._error(error);
        this._emitResponseWithSessionCheck({ session, request, error });
      }
    }

    _emitResponseWithSessionCheck(response) {
      // A new session invalidates ongoing data fetch
      isCurrentSession(this._hub, response.session) && this._emitResponse(response);
    }

    _emitResponse(response$1) {
      this._hub.update(response(), response$1);
    }

    _error(error) {
      // TODO
      console.error(error);
    }

    _destroy() {
      // abort ongoing data fetch if any
      this._ac && this._ac.abort({
        type: 'data-actor-destroy',
        message: 'Data actor is destroyed.',
      });
      for (const unsubscribe of this._unsubscribes) {
        unsubscribe();
      }
      this._unsubscribes = [];
    }

  }

  class ProxyElement {

    constructor(element) {
      this._get = typeof element === 'function' ? element : () => element;
      this._handlers = [];
      this._elementUpdatedHandlers = [];
      this.sync();
    }

    get current() {
      return this._element;
    }

    on(event, handler) {
      if (event === 'element') {
        return this._onElementUpdated(handler);
      }
      const element = this._get();
      if (element) {
        element.addEventListener(event, handler);
      }
      this._handlers.push({ event, handler });
      return () => this._off(event, handler);
    }

    _off(event, handler) {
      const element = this._get();
      if (element) {
        element.removeEventListener(event, handler);
      }
      findAndRemoveItem(this._handlers, en => en.handler === handler);
    }

    _onElementUpdated(handler) {
      this._elementUpdatedHandlers.push(handler);
      return () => {
        removeItem(this._elementUpdatedHandlers, handler);
      };
    }

    sync({ silent = false } = {}) {
      const element = this._get();
      if (this._element === element) {
        return;
      }
      this._offAllFromCurrentElement();
      if (element) {
        for (const { event, handler } of this._handlers) {
          element.addEventListener(event, handler);
        }
      }
      const oldElement = this._element;
      this._element = element;

      if (silent) {
        return;
      }
      for (const handler of this._elementUpdatedHandlers) {
        try {
          handler(element, oldElement);
        } catch (e) {
          console.error(e); // TODO
        }
      }
    }

    _offAllFromCurrentElement() {
      if (this._element) {
        for (const { event, handler } of this._handlers) {
          this._element.removeEventListener(event, handler);
        }
      }
    }

    destroy() {
      this._offAllFromCurrentElement();
    }

  }

  const { IMPRESSION, VIEWABLE, CLICK } = EVENT_TYPE;
  const { UNTRACKED, TRIGGERED } = TRACKING_STATUS;

  const UNTRACKED_STATES = Object.freeze({
    [IMPRESSION]: UNTRACKED,
    [VIEWABLE]: UNTRACKED,
    [CLICK]: UNTRACKED,
  });

  /**
   * Tracking states for a session to keep track of the tracking status of each product.
   * For each entry there are status of impression, viewable, and click events.
   */
  class States {

    constructor(sessionId) {
      this.sessionId = sessionId;
      this._states = new Map(); // item key -> {impression, viewable, click}
    }

    getFullState(item) {
      // when we receive a bind event, impression is trigger, making an entry here
      // so if the state is not found, the product is not present yet => all untracked
      const state = this._states.get(this._getKey(item));
      return state ? { ...state } : UNTRACKED_STATES;
    }

    get(item, type) {
      const state = this._states.get(this._getKey(item));
      return state && state[type] || UNTRACKED;
    }

    set(items, type, status) {
      validateEventType(type);
      validateTrackingStatus(status);
      for (const item of asArray(items)) {
        this._setOne(item, type, status);
      }
    }

    untriggered(items, type) {
      return items.filter(item => this.get(item, type) !== TRIGGERED);
    }

    _getKey(item) {
      // TODO: ad-hoc! should move away to higher level
      return item.product_id || item.text || item.id || item;
    }

    _setOne(item, type, status) {
      computeIfAbsent(this._states, this._getKey(item), () => ({ ...UNTRACKED_STATES }))[type] = status;
    }

  }

  // a dummy item array for manipulating deduplication
  const ITEMLESS_DUMMY_ITEMS = [Symbol('itemless')];

  class Tracker {

    constructor({ hub, role, options }) {
      this._hub = hub;
      this._role = role;
      this._options = options;
      // TODO: know item type

      this._states = new States(this._getSessionId());
    }

    get options() {
      return typeof this._options === 'function' ? this._options() : this._options;
    }

    getState(item) {
      return this._states.getFullState(item);
    }

    _trigger(type, items, meta) {
      validateEventType(type);

      const { options } = this;
      if (!options) {
        return;
      }

      this._syncSession();

      const { deduplicated = true, itemless = false } = options;

      if (deduplicated) {
        if (itemless) {
          items = ITEMLESS_DUMMY_ITEMS;
        }
        items = this._states.untriggered(asArray(items), type);
        if (items.length === 0) {
          return;
        }
        this._states.set(items, type, TRACKING_STATUS.TRIGGERED);
      }

      this._sendToHub({
        type,
        items: itemless ? undefined : items,
        ...meta,
      });
    }

    submit({ value }) {
      this._syncSession();
      this._sendToHub({
        type: EVENT_TYPE.SUBMIT,
        value,
      });
    }

    _sendToHub(args) {
      this._hub.trigger(tracker(), Object.freeze(trimObj({ role: this._role, ...args })));
    }

    _syncSession() {
      const sessionId = this._getSessionId();
      if (!sessionId) {
        return;
      }
      if (!this._states || sessionId !== this._states.sessionId) {
        this._states = new States(sessionId);
      }
    }

    _getSessionId() {
      const { session } = this._getViewState() || {};
      return session && session.uuid;
    }

    _getMisoId() {
      const state = this._getViewState();
      return (state && state.meta && state.meta.miso_id) || undefined;
    }

    _getRequestPayload() {
      const { request } = this._getViewState() || {};
      return request && request.payload;
    }

    _getViewState() {
      return this._hub.states[view(this._role)];
    }

  }

  for (const type of PERFORMANCE_EVENT_TYPES) {
    Tracker.prototype[type] = function(items, meta) {
      this._trigger(type, items, meta);
    };
  }

  function statesEqual(a, b) {
    return a === b || (a && b &&
      a.status === b.status &&
      a.error === b.error &&
      a.value === b.value && // skip deep equals
      a.ongoing === b.ongoing &&
      sessionEquals(a.session, b.session));
  }

  function sessionEquals(a, b) {
    return a === b || (a && b && a.uuid === b.uuid);
  }

  class ViewActor {

    constructor(views, role) {
      this._events = new EventEmitter({ target: this });
      this._views = views;
      this._mapping = asMappingFunction((views._roles.mappings || {})[role] || role);

      defineValues(this, {
        role,
        interface: new View(this),
      });
    }

    get hub() {
      return this._views._hub;
    }

    get element() {
      return this._element;
    }

    set element(element) {
      if (element === this._element) {
        return;
      }
      if (this._element) {
        this._safeApplyOnLayout('unrender', this._element);
      }
      this._element = element;
      this._proxyElement && this._proxyElement.sync();
      this._events.emit('element', element);
      this.refresh({ force: true });
    }

    get proxyElement() {
      if (!this._proxyElement) {
        this._proxyElement = new ProxyElement(() => this.element);
      }
      return this._proxyElement;
    }

    get layout() {
      return this._layout;
    }

    set layout(layout) {
      if (layout === this._layout) {
        return;
      }
      if (layout && typeof layout.render !== 'function') {
        throw new Error(`Render function is mandatory in a layout.`);
      }

      // clean up old layout
      const { element } = this;
      element && this._safeApplyOnLayout('unrender', element);
      this._safeApplyOnLayout('destroy');

      this._layout = layout;

      // initialize new layout
      if (layout) {
        layout._view = this;
        // don't use _safeApplyOnLayout, for any error should be thrown
        if (typeof layout.initialize === 'function') {
          layout.initialize(this);
        }
      }

      // in case the data is already there
      this.refresh({ force: true });
    }

    get tracker() {
      const { role } = this;
      if (role === ROLE.CONTAINER) {
        return this._views._getContainerTracker();
      }
      // TODO: we should move this to workflow level, as there could be multiple view of the same role in the future
      if (!this._tracker) {
        const { hub } = this;
        this._tracker = new Tracker({ hub, role, options: () => this.trackerOptions });
      }
      return this._tracker;
    }
    
    get workflowOptions() {
      return this._views._options.resolved;
    }

    get trackerOptions() {
      return this._views._getTrackerOptions(this.role);
    }

    get filters() {
      return this._views.filters;
    }

    async refresh({ force = false, data } = {}) {
      // protocol: no reaction when layout is absent
      if (!this._layout) {
        return;
      }

      // nothing to do when element is absent
      const { element } = this;
      if (!element) {
        return;
      }

      // sync data
      const previousData = this._data;
      this._data = data = this._sliceData(data || this._views._getData());

      // if data is unchanged, skip unless forced
      if (!force && statesEqual(data, previousData)) {
        return;
      }

      const { session, status, ongoing, request, meta, value } = data;
      const baseState = { session, status, ongoing, request, meta, data: value, ...getDataEmptyness(data) };

      // render
      const notifyUpdate = (state = {}, options) => {
        state !== false && this.updateState({ ...baseState, ...state }, options);
      };
      try {
        await this._layout.render(element, data, { notifyUpdate });
      } catch(error) {
        this._error(error);
        notifyUpdate({ error });
      }
    }

    updateState(state, { silent = false } = {}) {
      // there might be error from notifyUpdate() call
      const status = state.error ? STATUS.ERRONEOUS : state.status;
      state = this._state = Object.freeze(trimObj({ ...state, status }));
      const { role } = this;
      this.hub.update(view(role), state, { silent });
    }

    _sliceData(data) {
      const { value, error, status, meta, ...rest } = data;
      const sliced = {
        value: this._mapping(data, this),
        status,
        data: value,
        meta,
        ...rest,
      };
      if (this.role === ROLE.CONTAINER) {
        // pass empty/nonempty information
        sliced.meta = {
          ...meta,
          empty: this._isContainerEmpty(value),
        };
      }
      return trimObj(sliced);
    }

    _isContainerEmpty(value) {
      const { element } = this;
      if (!element) {
        return false;
      }
      // iterate over all member components' roles
      for (const { role } of element.components) {
        // not a data role -> irrelevant
        if (!isDataRole(role)) {
          continue;
        }
        let sliced = value && value[role];
        if (role === ROLE.QUERY_SUGGESTIONS) {
          // special case: query suggestions -> look up value from hub
          // TODO: adhoc
          const data = this.hub.states[suggestions()];
          sliced = data && data.value;
        }
        if (sliced && sliced.length !== 0) {
          return false;
        }
      }
      return true;
    }

    _syncSize() {
      this._element && this._safeApplyOnLayout('syncSize', this._element);
    }

    _safeApplyOnLayout(method, ...args) {
      if (!this._layout || typeof this._layout[method] !== 'function') {
        return;
      }
      try {
        this._layout[method](...args);
      } catch(e) {
        this._error(e);
      }
    }

    _error(e) {
      this._views._error(e);
    }

    _destroy() {
      this._safeApplyOnLayout('destroy');
      this._proxyElement && this._proxyElement.destroy();
    }

  }

  class View {

    constructor(actor) {
      delegateGetters(this, actor, ['role', 'layout', 'element', 'proxyElement', 'refresh', 'on', 'tracker']);
    }

  }

  function asMappingFunction(fn) {
    switch (typeof fn) {
      case 'function':
        return fn;
      case 'string':
        return data => data.value && data.value[fn];
      default:
        throw new Error(`Invalid mapping function: ${fn}`);
    }
  }

  function getDataEmptyness(data) {
    return isDataStatusRelevantToEmptyness(data) ? { empty: !!isDateValueEmpty(data) } : {};
  }

  function isDataStatusRelevantToEmptyness(data) {
    return data.status === STATUS.READY && !data.ongoing;
  }

  function isDateValueEmpty(data) {
    const { value } = data;
    return value === undefined || ((Array.isArray(value) || typeof value === 'string') && !value.length);
  }

  function mergeState(state = {}, update = {}) {
    return Object.freeze(trimObj({
      ...state,
      ...update,
      facets: Object.freeze(trimObj({
        ...state.facets,
        ...update.facets,
      })),
    }));
  }

  function optionsToState({ sort } = {}) {
    // TODO: facets
    return trimObj({
      facets: Object.freeze({}),
      sort: sortOptionsToState(sort),
    });
  }

  function sortOptionsToState(sort) {
    if (!sort) {
      return undefined;
    }
    const { options = [] } = sort;
    for (const option of options) {
      if (option.default) {
        return Object.freeze(option);
      }
    }
    return Object.freeze(options[0]);
  }

  class Filters {

    constructor(views, { facets: facetsOptions } = {}) {
      this._views = views;
      this._hub = views._hub;
      const error = this._error = this._error.bind(this);
      this._events = new EventEmitter({ target: this, error });
      defineValues(this, { facets: new Facets(this, facetsOptions) });

      this._unsubscribes = [
        views._options.on('filters', () => this._syncOptions()),
      ];

      this._syncOptions();
      this._states = undefined;
    }

    _syncOptions() {
      const options = this._views._options.resolved.filters;
      this._initialStates = optionsToState(options);
      this.apply({ silent: true });
    }

    _getStates() {
      return this._states || this._initialStates;
    }

    update(updates) {
      const oldStates = this._getStates();
      this._states = mergeState({ ...oldStates, ...updates });
      const states = this._getStates();
      this._events.emit('update', { updates, states, oldStates });
    }

    reset() {
      const oldStates = this._states;
      this._states = undefined;
      const states = this._getStates();
      this._events.emit('reset', { states, oldStates });
    }

    apply({ silent = false } = {}) {
      const states = this._getStates();
      this._hub.update(filters(), states, { silent });
      !silent && this._events.emit('apply');
    }

    _error(error) {
      this._views._error(error);
    }

    _destroy() {
      for (const unsubscribe of this._unsubscribes) {
        unsubscribe();
      }
      this._unsubscribes = [];
    }

  }

  class Facets {

    constructor(filters, options = {}) {
      this._filters = filters;
      this._options = options;
    }

    isSelected(field, value) {
      return this._getFieldValues(field).includes(value);
    }

    select(field, value) {
      if (this.isSelected(field, value)) {
        return;
      }
      this._select(field, value);
    }

    unselect(field, value) {
      if (!this.isSelected(field, value)) {
        return;
      }
      this._unselect(field, value);
    }

    toggle(field, value) {
      if (this.isSelected(field, value)) {
        this._unselect(field, value);
      } else {
        this._select(field, value);
      }
    }

    _getFieldValues(field) {
      return this._filters._getStates().facets[field] || [];
    }

    _select(field, value) {
      const values = this._options.multivalued ? [...this._getFieldValues(field), value] : [value];
      values.sort();
      this._filters.update({ facets: { [field]: values } });
    }

    _unselect(field, value) {
      let values = this._getFieldValues(field).filter(v => v !== value);
      if (values.length === 0) {
        values = undefined;
      }
      this._filters.update({ facets: { [field]: values } });
    }

  }

  const TRACKED = Symbol.for('miso:tracked');

  function isTracked(event) {
    return !!event[TRACKED];
  }

  function markAsTracked(event) {
    event[TRACKED] = true;
  }

  const DEFAULT_TRACKER_OPTIONS = Object.freeze({
    impression: Object.freeze({
    }),
    viewable: Object.freeze({
      area: 0.5,
      duration: 1000,
    }),
    click: Object.freeze({
      lenient: false,
    }),
  });

  function mergeOptions$1(def, opt) {
    // if opt is falsy then return false, merge otherwise
    return !!opt && { ...def, ...opt };
  }

  // TODO: don't need this anymore
  function normalizeTrackerOptions(options) {
    // TODO: make this { active: false } to keep it an object
    if (options === false) {
      return false; // turn off all tracking
    }
    if (options === true) {
      options = {};
    }
    if (typeof options !== 'object') {
      throw new Error(`Invalid options: ${options}`);
    }
    const { impression = {}, viewable = {}, click = {}, ...rest } = options;
    return trimObj({
      ...DEFAULT_TRACKER_OPTIONS,
      ...rest,
      impression: mergeOptions$1(DEFAULT_TRACKER_OPTIONS.impression, impression),
      viewable: mergeOptions$1(DEFAULT_TRACKER_OPTIONS.viewable, viewable),
      click: mergeOptions$1(DEFAULT_TRACKER_OPTIONS.click, click),
    });
  }

  function validateClick(options = {}, event) {
    if (!options) {
      return false;
    }

    if (typeof options.validate === 'function') {
      return options.validate(event);
    }

    if (options.lenient) {
      return true;
    }

    // standard criteria
    // 1. each event can only be tracked once
    if (isTracked(event)) {
      return false;
    }
    // 2. it must be a left click
    if (event.button !== 0) {
      return false;
    }
    // 3. event default must not be prevented
    if (event.defaultPrevented) {
      return false;
    }
    // 4. must go through a real link
    if (!findInAncestors(event.target, element => (element.tagName === 'A' && element.href) || undefined)) {
      return false;
    }

    return true;
  }

  class ViewsActor {

    constructor(hub, {
      workflow,
      extensions,
      layouts,
      roles,
      options,
    }) {
      this._hub = hub;
      this._workflowName = workflow;
      this._extensions = extensions;
      this._layoutFactory = layouts;
      this._options = options;
      this._roles = roles;
      this._containers = new Map();
      this._containerTracker = undefined;
      this._views = {};
      this._filters = new Filters(this);

      for (const role of roles.members) {
        if (role === ROLE.CONTAINER) {
          continue;
        }
        this._views[role] = new ViewActor(this, role);
      }

      defineValues(this, {
        interface: new Views(this),
        trackers: new Trackers(this, roles.members),
      });

      const syncSize = () => this.syncSize();
      window.addEventListener('resize', syncSize);

      this._unsubscribes = [
        () => window.removeEventListener('resize', syncSize),
        hub.on(data(), data => this.refresh({ data })),
        options.on('layouts', () => this._syncLayouts()),
      ];

      this._syncLayouts();
    }

    get filters() {
      return this._filters;
    }

    // elements //
    addContainer(element) {
      if (this._containers.has(element)) {
        return;
      }
      const view = new ViewActor(this, ROLE.CONTAINER);
      view.layout = this._createLayout(ROLE.CONTAINER);
      view.element = element;
      this._containers.set(element, view);

      const { components } = element;
      for (const component of components) {
        this.addComponent(component);
      }
    }

    removeContainer(element) {
      const view = this._containers.get(element);
      if (!view) {
        return;
      }
      const { components } = element;
      for (const component of components) {
        this.removeComponent(component);
      }
      view._destroy();
      this._containers.delete(element);
    }

    addComponent(element) {
      this._getViewByElement(element).element = element;
    }

    removeComponent(element) {
      this._getViewByElement(element).element = undefined;
    }

    updateComponentRole(element, oldRole, newRole) {
      // TODO
    }

    containsElement(element) {
      return this._containers.has(element) || this._views[element.role];
    }

    refreshElement(element) {
      const view = element.isContainer ? this._containers.get(element) : this._getViewByElement(element);
      view && view.refresh({ force: true });
    }

    _getViewByElement(element) {
      let { role } = element;
      if (!role) {
        throw new Error('Component must have a role');
      }
      return this.get(role);
    }

    /*
    _requestSyncLayouts() {
      this._setLayoutRequested = true;
      setTimeout(() => {
        if (!this._setLayoutRequested) {
          return;
        }
        this._setLayoutRequested = false;
        this._syncLayouts();
      });
    }
    */

    _syncLayouts() {
      // TODO: put a debug event here
      const { layouts } = this._options.resolved;
      if (layouts === false) {
        // containers
        for (const view of this._containers.values()) {
          view.layout = undefined;
        }
        // components
        for (const view of Object.values(this._views)) {
          view.layout = undefined;
        }
      } else {
        for (let [role, [name, options]] of Object.entries(layouts)) {
          // TODO: try to omit if unchanged
          const fn = () => this._layoutFactory.create(name, { ...options, role, workflow: this._workflowName });
          if (role === ROLE.CONTAINER) {
            for (const view of this._containers.values()) {
              view.layout = fn();
            }
          } else {
            const view = this.get(role);
            if (view) {
              view.layout = fn();
            }
          }
        }
      }
    }

    _createLayout(role) {
      const args = this._options.resolved.layouts[role];
      if (!args) {
        return undefined;
      }
      const [name, options] = args;
      return this._layoutFactory.create(name, { ...options, role, workflow: this._workflowName });
    }

    get(role) {
      return this._views[role];
    }

    get views() {
      return this._getViews(true);
    }

    _getViews(containerFirst = true) {
      return containerFirst ? [
        ...this._containers.values(),
        ...Object.values(this._views),
      ] : [
        ...Object.values(this._views),
        ...this._containers.values(),
      ];
    }

    syncSize() {
      for (const view of Object.values(this._views)) {
        view._syncSize();
      }
    }

    async refresh({ force, data } = {}) {
      data = this._getData(data);
      // container first
      let views = this._getViews(true);

      if (!force && data._inst) {
        const { includes, excludes } = data._inst;
        if (includes) {
          // always include containers
          views = views.filter(view => view.role === ROLE.CONTAINER || includes.includes(view.role));
        }
        if (excludes) {
          views = views.filter(view => !excludes.includes(view.role));
        }
      }

      await Promise.all(views.map(view => view.refresh({ force, data })));
    }

    _getData(data$1) {
      return data$1 || this._hub.states[data()];
    }

    _getTrackerOptions(role) {
      const allTrackerOptions = this._options.resolved.trackers;
      // TODO: don't need this anymore
      return normalizeTrackerOptions((allTrackerOptions && allTrackerOptions[role]) || false);
    }

    _getContainerTracker() {
      if (!this._containerTracker) {
        const hub = this._hub;
        const role = ROLE.CONTAINER;
        this._containerTracker = new Tracker({ hub, role, itemless: true, options: () => this._getTrackerOptions(role) });
      }
      return this._containerTracker;
    }

    _error(e) {
      // TODO: hub trigger error event
      console.error(e);
    }

    _destroy({ dom } = {}) {
      // destroy components, and then containers
      for (const view of this._getViews(false)) {
        // TODO: handle dom option
        view._destroy();
      }
      for (const unsubscribe of this._unsubscribes) {
        unsubscribe();
      }
      this._unsubscribes = [];
      this._filters._destroy();
    }

  }

  class Views {

    constructor(actor) {
      this._actor = actor;
      delegateGetters(this, actor, ['syncSize', 'refresh', 'trackers', 'filters']);
    }

    get(role) {
      return this._actor.get(role).interface;
    }

    get all() {
      return this._actor.views.map(view => view.interface);
    }

  }

  class Trackers {

    constructor(views, roles) {
      this._views = views;
      for (const role of roles) {
        if (role === ROLE.CONTAINER) {
          continue;
        }
        Object.defineProperty(this, role, {
          get: () => views.get(role).tracker,
        });
      }
      Object.defineProperty(this, ROLE.CONTAINER, {
        get: () => views._getContainerTracker(),
      });
    }

  }

  class FeedbackActor {

    constructor(hub) {
      this._hub = hub;
      this._unsubscribes = [
        hub.on(feedback(), state => this._trigger(state)),
      ];
    }
    
    _trigger(state) {
      this._hub.trigger(tracker(), {
        type: EVENT_TYPE.FEEDBACK,
        result_type: 'answer',
        value: state.unselected ? 'unselected' : state.value,
      });
    }

    _destroy() {
      for (const unsubscribe of this._unsubscribes) {
        unsubscribe();
      }
      this._unsubscribes = [];
    }

  }

  class InteractionsActor {

    constructor(hub, { client, options }) {
      this._client = client;
      this._options = options;
      this._unsubscribes = [
        hub.on(interaction(), payload => this._handle(payload)),
      ];
    }

    _handle(payload) {
      // TODO: omit when option == false
      payload = asArray(payload);

      if (payload.length === 0) {
        return;
      }

      this._client.api.interactions.upload(payload, { merge: true });
    }

    destroy() {
      for (const unsubscribe of this._unsubscribes) {
        unsubscribe();
      }
      this._unsubscribes = [];
    }

  }

  function api(client) {
    // TODO: send uuid & unit id
    return async ({ group, name, payload, options }) => {
      if (group === GROUP$5.ASK) {
        switch (name) {
          case NAME$6.QUESTIONS:
            return client.api.ask.questions(payload, options);
          case NAME$6.SEARCH:
            return client.api.ask.search(payload, options);
        }
      }
      // because name is in snake case
      return client.api[group]._run(name, payload, options);
    };
  }

  class RafLayout {

    constructor({ role, workflow, ...options } = {}) {
      defineValues(this, { role, workflow, options });
      this._unsubscribes = [];
      this._rendered = new WeakMap();
      this._element = undefined;
      this._notifyUpdate = undefined;
      this._pending = undefined;
    }

    async render(element, state, controls = {}) {
      this._syncElement(element);

      const rendered = this._rendered.get(element);
      const skip = capture(false);

      // can do some pre-processing here to reducing time cost within RAF
      state = this._preprocess({ state, rendered }, { skip: skip.t }) || state;
      this._updatePending(state, controls);

      // TODO: shall we put this inside _handleInput?
      if (!skip.value) {
        this._handleInput({ state, rendered }, controls);
      }
    }

    _syncElement(element) {
      if (this._element !== element) {
        // clean up state on old element even thought it's a weak reference,
        // for we have no idea what will happen to it
        this._rendered.delete(this._element);
      }
      this._element = element;
    }

    _preprocess({ state }) {
      return state;
    }

    _updatePending(state, controls) {
      this._pending = [Object.freeze(state), controls];
    }

    _takePending() {
      const pending = this._pending;
      this._pending = undefined;
      return pending;
    }

    _handleInput() {
      this._requestRaf();
    }

    _requestRaf() {
      if (this._requested) {
        return;
      }
      this._requested = true;
      requestAnimationFrame(timestamp => this._doRaf(timestamp));
    }

    _doRaf(timestamp) {
      if (!this._requested) {
        return; // just in case
      }
      this._requested = false;
      this._applyRender(timestamp);
    }

    _applyRender(timestamp, extraControls = {}) {
      if (!this._pending) {
        return; // just in case
      }
      let [state, { notifyUpdate }] = this._takePending();
      state = Object.freeze({ ...state, timestamp });

      const rendered = this._rendered.get(this._element);
      const argsForNotifyUpdate = capture([]);
      const stateExtra = capture({});

      // TODO: remove this timestamp, for it's in state already
      this._render(this._element, { state, rendered, timestamp }, { notifyUpdate: argsForNotifyUpdate.args, writeToState: stateExtra.merge, ...extraControls });

      state = Object.freeze({ ...state, ...stateExtra.value });
      this._rendered.set(this._element, state);

      notifyUpdate && notifyUpdate(...argsForNotifyUpdate.value);

      // TODO: should the signature be aligned with _render?
      this._afterRender(this._element, state);
    }

    _render() {
      throw new Error('Unimplemented');
    }

    _afterRender() {}

    destroy() {
      for (const unsubscribe of this._unsubscribes) {
        unsubscribe();
      }
      this._unsubscribes = [];
      this._view = undefined;
      this._element = undefined;
      this._notifyUpdate = undefined;
      this._pending = undefined;
    }

  }

  function requiresImplementation(...names) {
    return names.reduce((acc, name) => {
      acc[name] = unimplemented(name);
      return acc;
    }, {});
  }

  function unimplemented(name) {
    return () => {
      throw new Error(`Template '${name}' is not implemented.`);
    }
  }

  function product$1(layout, state, data, meta) {
    const { templates } = layout;
    const [openTag, closeTag] = tagPair(layout, data);
    return [
      openTag,
      (templates.imageBlock || imageBlock)(layout, data, meta),
      (templates.infoBlock || templates.productInfoBlock || productInfoBlock)(layout, data, meta),
      closeTag,
    ].join('');
  }

  function question$2(layout, state, data) {
    const [openTag, closeTag] = tagPair(layout, data);
    return `${openTag}${data.value || data.text || data}${closeTag}`;
  }

  function article(layout, state, data, meta) {
    const { templates } = layout;
    const [openTag, closeTag] = tagPair(layout, data);
    return [
      openTag,
      (templates.imageBlock || imageBlock)(layout, data, meta),
      (templates.infoBlock || templates.articleInfoBlock || articleInfoBlock)(layout, data, meta),
      (templates.indexBlock || indexBlock)(layout, data, meta),
      closeTag,
    ].join('');
  }

  function image(layout, state, data, meta) {
    const { templates } = layout;
    const [openTag, closeTag] = tagPair(layout, data);
    return [
      openTag,
      (templates.imageBlock || imageBlock)(layout, data, meta),
      (templates.infoBlock || templates.imageInfoBlock || imageInfoBlock)(layout, data, meta),
      closeTag,
    ].join('');
  }

  function affiliation(layout, state, data, meta) {
    const { templates } = layout;
    const [openTag, closeTag] = tagPair(layout, data, { link: false});
    return [
      openTag,
      (templates.infoBlock || templates.affiliationInfoBlock || affiliationInfoBlock)(layout, data, meta),
      (templates.imageBlock || imageBlock)(layout, data, { brand: true, ...meta, }),
      closeTag,
    ].join('');
  }

  function affiliationInfoBlock(layout, data, meta) {
    const { className, templates } = layout;
    return `<div class="${className}__item-info-container">${[
    (templates.titleBlock || titleBlock)(layout, data, meta),
    (templates.descriptionBlock || descriptionBlock)(layout, data, meta),
    (templates.priceBlock || priceBlock)(layout, data, meta),
    (templates.ctaBlock || ctaBlock)(layout, data, meta),
  ].join('')}</div>`;
  }

  function productInfoBlock(layout, data, meta) {
    const { className, templates } = layout;
    return `<div class="${className}__item-info-container">${[
    (templates.titleBlock || titleBlock)(layout, data, meta),
    (templates.descriptionBlock || descriptionBlock)(layout, data, meta),
    (templates.priceBlock || priceBlock)(layout, data, meta),
  ].join('')}</div>`;
  }

  function articleInfoBlock(layout, data, meta) {
    const { className, templates } = layout;
    return `<div class="${className}__item-info-container">${[
    (templates.titleBlock || titleBlock)(layout, data, meta),
    (templates.dateBlock || dateBlock)(layout, data, meta),
    (templates.descriptionBlock || descriptionBlock)(layout, data, meta),
    (templates.ctaBlock || ctaBlock)(layout, data, meta),
  ].join('')}</div>`;
  }

  function imageInfoBlock(layout, data, meta) {
    const { className, templates } = layout;
    return `<div class="${className}__item-info-container">${[
    (templates.titleBlock || titleBlock)(layout, data, meta),
  ].join('')}</div>`;
  }

  function titleBlock({ className }, { title }) {
    return title ? `<div class="${className}__item-title">${escapeHtml(title)}</div>` : '';
  }

  function brandBlock({ className }, { brand, brand_logo }) {
    if (!brand && !brand_logo) {
      return '';
    }
    const content = brand_logo ? `<img class="${className}__item-brand-logo" src="${brand_logo}"${brand ? ` alt="${brand}"` : ''}>` : `<div class="${className}__item-brand">${brand}</div>`;
    return `<div class="${className}__item-brand-container">${content}</div>`;
  }

  function descriptionBlock({ className }, { snippet, description }) {
    return snippet ? `<div class="${className}__item-snippet">${snippet}</div>` : description ? `<div class="${className}__item-desc">${escapeHtml(description)}</div>` : '';
  }

  function dateBlock({ className, templates }, { created_at, updated_at, published_at }) {
    const date = published_at || created_at || updated_at;
    return date ? `<div class="${className}__item-date">${formatDate(date, templates.date)}</div>` : '';
  }

  function priceBlock(layout, data) {
    const { className, templates } = layout;
    const { sale_price, original_price, currency = 'USD' } = data;
    const price = sale_price || original_price;
    if (!price) {
      return '';
    }
    const has_price_difference = original_price !== undefined && sale_price !== undefined && sale_price < original_price;
    const discount_rate_percent = data.discount_rate_percent || (has_price_difference ? Math.floor((1 - sale_price / original_price) * 100) : undefined);

    let content = '';
    // original price
    if (has_price_difference) {
      content += `<span class="${className}__item-original-price miso-price" data-currency="${currency}">${original_price}</span><br>`;
    }
    // current price
    content += `<span class="${className}__item-price miso-price" data-currency="${currency}">${price}</span>`;
    // discount rate
    if (discount_rate_percent) {
      const text = (templates.discountRateText || discountRateText)(layout, { ...data, discount_rate_percent });
      content += ` <span class="${className}__item-discount-rate">${text}</span>`;
    }
    return `<div class="${className}__item-price-container">${content}</div>`;
  }

  function discountRateText(layout, { discount_rate_percent }) {
    return `(${discount_rate_percent}% off)`;
  }

  function imageBlock(layout, data, meta = {}) {
    const { className, templates } = layout;
    const { cover_image, image_src, image_alt } = data;
    if (!cover_image && !image_src) {
      return '';
    }
    const subtype = image_src ? 'image' : 'cover-image';
    const img = subtype === 'image' ?
      `<img class="${className}__item-${subtype}" src="${image_src}"${image_alt ? ` alt="${image_alt}"` : ''}>` :
      `<img class="${className}__item-${subtype}" src="${cover_image}">`;
    const brand = subtype === 'cover-image' && meta.brand ? (templates.brandBlock || brandBlock)(layout, data, meta) : '';
    return `<div class="${className}__item-${subtype}-container">${img}${brand}</div>`;
  }

  function indexBlock({ className }, data, { index }) {
    return `<div class="${className}__item-index-container"><span class="${className}__item-index miso-citation-index" data-index="${index + 1}"></span></div>`;
  }

  function ctaBlock(layout, data, meta) {
    const { className, templates } = layout;
    const cta = helpers$2.asFunction(templates.cta)(layout, data, meta);
    return cta ? `<div class="${className}__item-cta-container">${cta}</div>` : '';
  }

  function cta(layout, data, meta) {
    const { templates } = layout;
    const { url } = data;
    if (!url) {
      return '';
    }
    const [openTag, closeTag] = tagPair(layout, { url }, { classSuffix: 'item-cta', role: 'cta' });
    const ctaText = helpers$2.asFunction(templates.ctaText)(layout, data, meta);
    return ctaText ? `${openTag}${ctaText}${closeTag}` : '';
  }

  // helpers //
  function tagPair({ className, options = {} }, { product_id, url }, { classSuffix = 'item-body', role = 'item', ...meta } = {}) {
    const tag = meta.link !== false && url ? 'a' : 'div';
    const urlAttrs = meta.link !== false && url ? `href="${url}" ${linkAttrs(options.link)}` : '';
    const productAttrs = product_id ? `${ATTR_DATA_MISO_PRODUCT_ID}="${product_id}"` : '';
    const roleAttrs = role ? `data-role="${role}"` : '';
    return [`<${tag} class="${className}__${classSuffix}" ${roleAttrs} ${productAttrs} ${urlAttrs}>`, `</${tag}>`];
  }

  function linkAttrs(link = {}) {
    const { target = '_blank', rel = 'noopener', open = true } = link; // TODO: other properties
    let attrs = '';
    if (open) {
      if (target) {
        attrs += ` target="${target}"`;
      }
      if (rel) {
        attrs += ` rel="${rel}"`;
      }
    }
    return attrs;
  }

  const DEFAULT_DATE_OPTIONS = Object.freeze({ locale: 'en-US', year: 'numeric', month: 'short', day: 'numeric' });
  const DEFAULT_NUMBER_OPTIONS = 'en-US';

  function formatDate(date, fn = DEFAULT_DATE_OPTIONS) {
    switch (typeof fn) {
      case 'function':
        return fn(date);
      case 'string':
        return new Date(date).toLocaleDateString(fn);
      case 'object':
        return new Date(date).toLocaleDateString(fn.locale || DEFAULT_DATE_OPTIONS.locale, fn);
      default:
        throw new Error(`Invalid date format: ${fn}`);
    }
  }

  function formatNumber(number, fn = DEFAULT_NUMBER_OPTIONS) {
    switch (typeof fn) {
      case 'function':
        return fn(number);
      case 'string':
        return new Intl.NumberFormat(fn).format(number);
      case 'object':
        return new Intl.NumberFormat(fn.locale || DEFAULT_NUMBER_OPTIONS.locale, fn).format(number);
      default:
        throw new Error(`Invalid number format: ${fn}`);
    }
  }

  function asFunction(template = '') {
    return typeof template === 'function' ? template : () => template;
  }

  const helpers$2 = Object.freeze({
    tagPair,
    formatDate,
    formatNumber,
    escapeHtml,
    asFunction,
  });

  class TemplateBasedLayout extends RafLayout {

    constructor({ className, templates, ...options } = {}) {
      super(options);
      defineValues(this, {
        className,
        templates: {
          ...requiresImplementation('root'),
          ...templates,
          helpers: helpers$2,
        },
      });
    }

    _preprocess({ state }) {
      const html = this.templates.root(this, state);
      return { ...state, html };
    }

    _render(element, { state }) {
      element.innerHTML = state.html;
    }

  }

  const TAG_NAME$7 = 'miso-banner';

  class MisoBannerElement extends HTMLElement {

    static get tagName() {
      return TAG_NAME$7;
    }

    // lifecycle //
    async connectedCallback() {
      MisoBannerElement.MisoClient.ui.layouts.create('banner').render(this);
    }

  }

  class Viewables {

    constructor() {
      this._entries = new WeakMap();
    }

    isTracked(element) {
      return this._entries.has(element);
    }

    async track(element, options = {}) {
      if (!options) {
        return false;
      }
      const entry = this._entries.get(element);
      if (entry) {
        return false;
      }
      const ac = new AbortController();
      const { signal } = ac;
      this._entries.set(element, { ac });
      let result = false;
      try {
        await viewable(element, { ...options, signal });
        result = true;
      } catch (e) {
        if (e.name !== 'AbortError') {
          throw e;
        }
      } finally {
        this._entries.delete(element);
      }
      return result;
    }

    untrack(element) {
      const entry = this._entries.get(element);
      if (!entry) {
        return;
      }
      entry.ac.abort();
      this._entries.delete(element);
    }

  }

  const TYPE$f = 'container';

  class ContainerLayout extends RafLayout {

    static get type() {
      return TYPE$f;
    }

    constructor({ logo = 'auto', ...options } = {}) {
      super({
        logo,
        ...options,
      });
      this._impression = false;
      this._viewables = new Viewables();
    }

    _syncElement(element) {
      if (this._element !== element) {
        this._viewables.untrack(this._element);
      }
      super._syncElement(element);
    }

    _render(element, data) {
      this._syncBanner(element);
      this._syncStatus(element, data);
      this._trackInteractions(element, data);
    }

    _afterRender(element, state) {
      this._trackInteractions(element, state);
    }

    _syncBanner(element) {
      const bannerTagName = MisoBannerElement.tagName;
      const shallRender = this._shallRenderBanner(element);
      const bannerElement = element.querySelector(bannerTagName);
      if (shallRender && !bannerElement) {
        element.insertAdjacentHTML('beforeend', `<${bannerTagName} visible-when="ready"></${bannerTagName}>`);
      } else if (!shallRender && bannerElement) {
        bannerElement.remove();
      }
    }

    _shallRenderBanner(element) {
      const { logo: globalLogo } = this.options;
      const { logo: localLogo } = element;
      const logo = (localLogo !== undefined && localLogo !== 'auto' ? localLogo : globalLogo);
      // logo === 'auto': only add banner when a component of main role (like producs, answer) is present
      return logo === 'auto' ? element.components.some(({ role }) => isMainRole(role)) : !!logo;
    }

    _syncStatus(element, { state }) {
      if (!element) {
        return;
      }
      const { status, ongoing, meta: { miso_id, empty = false, unanswerable = false } = {} } = state;
      const statuses = [status, empty ? STATUS.EMPTY : STATUS.NONEMPTY];
      if (status === STATUS.READY) {
        statuses.push(ongoing ? STATUS.ONGOING : STATUS.DONE);
      }
      if (unanswerable) {
        statuses.push(STATUS.UNANSWERABLE);
      }
      element.setAttribute('status', statuses.join(' '));
      if (miso_id) {
        element.setAttribute('miso-id', miso_id);
      } else {
        element.removeAttribute('miso-id');
      }
    }

    _trackInteractions(element, state) {
      const { status } = state;
      if (status === STATUS.READY) {
        this._trackImpression();
        this._trackViewable(element); // don't await
      }
    }

    _trackImpression() {
      const { impression: options } = this._view.tracker.options || {};
      if (!options) {
        return;
      }
      if (this._impression) {
        return;
      }
      this._impression = true;
      this._view.tracker.impression();
    }

    async _trackViewable(element) {
      const { viewable: options } = this._view.tracker.options || {};
      if (!options) {
        return;
      }
      if (await this._viewables.track(element, options)) {
        this._view.tracker.viewable();
      }
    }

  }

  function isMainRole(role) {
    return role === ROLE.PRODUCTS || role === ROLE.ANSWER;
  }

  const TYPE$e = 'error';
  const DEFAULT_CLASSNAME$e = 'miso-error';

  function root$c(layout, state) {
    const { className, templates } = layout;
    const { status, value } = state;
    if (status !== 'erroneous') {
      return '';
    }
    return `<div class="${className}"><div class="${className}__message">${templates.message(layout, value)}</div></div>`;
  }

  function message(layout, error) {
    return `Error: ${error.message || error}`;
  }

  const DEFAULT_TEMPLATES$d = Object.freeze({
    root: root$c,
    message,
  });

  class ErrorLayout extends TemplateBasedLayout {

    static get type() {
      return TYPE$e;
    }

    static get defaultTemplates() {
      return DEFAULT_TEMPLATES$d;
    }

    constructor({ className = DEFAULT_CLASSNAME$e, templates, ...options } = {}) {
      super({
        className,
        templates: { ...DEFAULT_TEMPLATES$d, ...templates },
        ...options,
      });
    }

  }

  const LOGO = '<svg viewBox="0 0 500 200"><path d="M131.1,39.4 C144.3,39.4 155,43.8 163.2,52.7 C171.3,61.3 175.2,72.9 175.2,87.6 L175.2,159.1 L140.4,159.1 L140.4,90.6 C140.4,78.7 134.6,71.5 123.7,71.5 C112.3,71.5 105.5,79.7 105.5,93.4 L105.5,159.1 L70.7,159.1 L70.7,90.6 C70.7,78.7 64.9,71.5 54,71.5 C42.6,71.5 35.8,79.7 35.8,93.4 L35.8,159.1 L1,159.1 L1,42.7 L35.8,42.7 L35.8,53.4 C42.1,44.1 52.6,39.4 67,39.4 C80.5,39.4 90.7,44.5 97.4,54.8 C104.6,44.5 115.8,39.4 131.1,39.4 Z M202,42.4 L238.4,42.4 L238.4,159.1 L202,159.1 Z M202,0 L238.4,0 L202,36.4 Z M302.6,76.6 C302.6,81.2 311.7,83.8 323,86.8 C339.2,90.3 360.5,98.7 360.3,124 C360.3,136.6 355.6,146.1 346.2,152.6 C336.8,158.9 325.3,162.1 311.5,162.1 C286.9,162.1 270,152.8 261.1,134.5 L291.6,117.3 C294.6,126.3 301.4,131 311.5,131 C319.9,131 324.2,128.7 324.2,123.8 C324.2,119.1 315,116.3 303.8,113.5 C287.6,109.1 266.5,101.2 266.5,77.5 C266.5,65.4 270.9,56.1 279.6,49.4 C288.5,42.6 299.5,39.4 312.4,39.4 C331.9,39.4 348.6,48.2 358.2,64.3 L328.2,80.3 C324.4,73.6 319.2,70.1 312.4,70.1 C305.9,70.1 302.6,72.2 302.6,76.6 Z M480.4,144.5 C468.4,156.3 453.7,162.1 436.3,162.1 C419,162.1 404.2,156.3 392.2,144.5 C380.3,132.6 374.2,118 374.2,100.8 C374.2,83.6 380.3,69.1 392.2,57.3 C404.2,45.4 419,39.4 436.3,39.4 C453.7,39.4 468.4,45.4 480.4,57.3 C492.4,69.1 498.5,83.6 498.5,100.8 C498.5,118 492.4,132.6 480.4,144.5 Z M417.1,120.5 C422.2,125.6 428.6,128.2 436.3,128.2 C444.1,128.2 450.4,125.6 455.5,120.5 C460.7,115.4 463.3,108.9 463.3,100.8 C463.3,92.6 460.7,86.1 455.5,81 C450.4,75.9 444.1,73.3 436.3,73.3 C428.6,73.3 422.2,75.9 417.1,81 C411.9,86.1 409.3,92.6 409.3,100.8 C409.3,108.9 411.9,115.4 417.1,120.5 Z" /></svg>';

  const THUMB = '<svg viewBox="0 0 16 16"><path d="M8.342 3.652 4.979 5.708a1 1 0 0 0-.479.852v5.561a1 1 0 0 0 .87.992l6.029.79a1 1 0 0 0 1.042-.583l2.534-5.65a1 1 0 0 0-.74-1.394l-3.543-.623.9-3.1A2.097 2.097 0 0 0 10.297 0L8.719 3.237a1 1 0 0 1-.377.415ZM1 6.5a1.5 1.5 0 0 1 3 0v6a1.5 1.5 0 0 1-3 0Z"/></svg>';

  const TYPE$d = 'banner';
  const DEFAULT_CLASSNAME$d = 'miso-banner';

  function root$b(layout) {
    const { className, templates } = layout;
    return `<div class="${className}"><div class="${className}__logo">${templates.logo(layout)}</div></div>`;
  }

  const DEFAULT_TEMPLATES$c = Object.freeze({
    root: root$b,
    logo: () => LOGO,
  });

  // TODO: give a role and make this customizable

  class BannerLayout extends TemplateBasedLayout {

    static get type() {
      return TYPE$d;
    }

    static get defaultTemplates() {
      return DEFAULT_TEMPLATES$c;
    }

    constructor({ className = DEFAULT_CLASSNAME$d, templates, ...options } = {}) {
      super({
        className,
        templates: { ...DEFAULT_TEMPLATES$c, ...templates },
        ...options,
      });
    }

  }

  function tuple(keys, values, elements) {
    const k2b = new Map();
    const e2b = new Map();
    const entries = [];
    for (let index = 0; index < keys.length; index++) {
      const key = keys[index];
      const element = elements[index];
      const value = values[index];
      const entry = Object.freeze({ index, key, value, element });
      k2b.set(key, entry);
      e2b.set(element, entry);
      entries.push(entry);
    }
    return { k2b, e2b, entries };
  }

  function diff(from, to) {
    const entries = [];
    for (const entry of to.entries) {
      const f = from.e2b.get(entry.element);
      if (!f || f.key !== entry.key) {
        entries.push(entry);
      }
    }
    return entries;
  }

  class Bindings {

    constructor() {
      this._k2b = new Map();
      this._e2b = new Map();
      this._entries = [];
    }

    get entries() {
      return [...this._entries];
    }

    get(element) {
      return this._e2b.get(element) || undefined;
    }

    find(key) {
      return this._k2b.get(key) || undefined;
    }

    update(keys, values, elements) {
      const newTuple = tuple(keys, values, elements);
      const oldTuple = { k2b: this._k2b, e2b: this._e2b, entries: this._entries };

      const bounds = diff(oldTuple, newTuple);
      const unbounds = diff(newTuple, oldTuple);

      this._k2b = newTuple.k2b;
      this._e2b = newTuple.e2b;
      this._entries = newTuple.entries;

      return { bounds, unbounds };
    }

    clear() {
      const unbounds = this._entries;
      this._k2b = new Map();
      this._e2b = new Map();
      this._entries = [];
      return { bounds: [], unbounds };
    }

  }

  function makeTrackable(prototype) {
    mixin(prototype, TrackableMixin.prototype);
  }

  class TrackableMixin {

    _initTrackable() {
      this._bindings = new Bindings();
      this._viewables = new Viewables();
    }

    _syncBindings(element, state) {
      const values = this._getItems(state) || [];
      const keys = values.map(value => this._getItemKey(value));
      const elements = this._getItemElements(element);

      const { bounds, unbounds } = this._bindings.update(keys, values, elements);
      this._onBindingsUpdate(bounds, unbounds);
    }

    _clearBindings() {
      const { bounds, unbounds } = this._bindings.clear();
      this._onBindingsUpdate(bounds, unbounds);
    }

    _getItemKey(value) {
      // TODO: ad-hoc!
      return value.product_id || value.text || value.id || value;
    }

    _getItems(state) {
      throw new Error(`Not implemented.`);
    }

    _getItemElements(element) {
      throw new Error(`Not implemented.`);
    }

    _onBindingsUpdate(bounds, unbounds) {
      this._trackImpressions(bounds);
      this._untrackViewables(unbounds);
      this._trackViewables(bounds);
    }

    _trackImpressions(entries) {
      if (entries.length === 0) {
        return;
      }
      const { impression: options } = this._view.tracker.options || {};
      if (!options) {
        return;
      }
      this._view.tracker.impression(entries.map(({ value }) => value));
    }

    _untrackViewables(entries) {
      for (const { element } of entries) {
        this._viewables.untrack(element);
      }
    }

    _trackViewables(entries) {
      if (entries.length === 0) {
        return;
      }
      const { viewable: options } = this._view.tracker.options || {};
      if (!options) {
        return;
      }
      for (const { value, element } of entries) {
        (async () => (await this._viewables.track(element, options)) && this._view.tracker.viewable([value]))();
      }
    }

    _trackClick(event, binding) {
      const { click: options } = this._view.tracker.options || {};
      if (validateClick(options, event)) {
        markAsTracked(event);
        this._view.tracker.click([binding.value]);
      }
    }

    _destroyTrackable() {
      const { unbounds } = this._bindings.clear();
      this._untrackViewables(unbounds);
    }

  }

  function makeTriggerable(prototype) {
    mixin(prototype, TriggerableMixin.prototype);
  }

  class TriggerableMixin {

    _initTriggerable() {
      this._trigger = undefined;
    }

    _syncTrigger(element, state) {
      if (!this.options.infiniteScroll) {
        return;
      }
      const workflowPaginationOptions = this._view.workflowOptions.pagination;
      if (!workflowPaginationOptions.active || workflowPaginationOptions.mode !== 'infiniteScroll') {
        return;
      }
      // only track trigger when ready
      if (state.status === STATUS.READY) {
        this._trackTrigger(element);
      } else {
        this._untrackTrigger();
      }
    }

    async _trackTrigger(element) {
      if (this._trigger) {
        return;
      }
      const triggerElement = element.querySelector('[data-role="trigger"]');
      if (!triggerElement) {
        return;
      }
      const ac = new AbortController();
      this._trigger = Object.freeze({
        element: triggerElement,
        ac,
      });
      let result = false;
      try {
        await viewable(triggerElement, { area: 1, duration: 0, signal: ac.signal });
        result = true;
      } catch (e) {
        if (e.name !== 'AbortError') {
          throw e;
        }
      } finally {
        this._trigger = undefined;
      }
      if (result) {
        this._onTrigger();
      }
    }

    _onTrigger() {
      this._view.hub.trigger(more());
    }

    _untrackTrigger() {
      if (!this._trigger) {
        return;
      }
      this._trigger.ac && this._trigger.ac.abort();
      this._trigger = undefined;
    }

    _destroyTriggerable() {
      this._untrackTrigger();
    }

  }

  function root$a(layout, state) {
    const { className, role, templates, options } = layout;
    const { status } = state;
    const roleAttr = role ? ` data-role="${role}"` : '';
    const itemTypeAttr = options.itemType ? ` data-item-type="${options.itemType}"` : '';
    return `<div class="${className} ${status}"${roleAttr}${itemTypeAttr}>${status === STATUS.READY ? templates[status](layout, state) : ''}${templates.trigger(layout, state)}${templates.loading(layout, state)}</div>`;
  }

  function ready$1(layout, state) {
    const { templates } = layout;
    const values = layout._getItems(state) || [];

    // TODO: handle categories, attributes, etc. by introducing sublayout
    if (values.length > 0 || state.ongoing) { // TODO: ad-hoc ongoing?
      return templates.body(layout, state, values);
    } else {
      return templates.empty(layout, state);
    }
  }

  function body$2(layout, state, values) {
    return layout.templates.list(layout, state, values);
  }

  function list(layout, state, values) {
    const { className, templates, options } = layout;
    const listTag = templates.ordered ? 'ol' : 'ul';
    const itemTypeAttr = options.itemType ? ` data-item-type="${options.itemType}"` : ''; // backward compatible
    // TODO: support separator?
    return `<${listTag} class="${className}__list" data-role="list"${itemTypeAttr}>${templates.items(layout, state, values)}</${listTag}>`;
  }

  function items(layout, state, values, { offset = 0 } = {}) {
    const { templates } = layout;
    let index = offset;
    return values.map(value => templates.item(layout, state, value, index++)).join('');
  }

  function item$3(layout, state, value, index) {
    const { className, templates, options } = layout;
    const { itemType } = options;
    const body = templates[itemType](layout, state, value, { index });
    return `<li class="${className}__item">${body}</li>`;
  }

  function trigger(layout, state) {
    const { className } = layout;
    return `<div class="${className}__trigger" data-role="trigger"></div>`;
  }

  function loading() {
    return `<div class="miso-loading" aria-label="Loading" data-role="loading"></div>`;
  }

  // TODO: let templates.js control what to be included here

  const DEFAULT_TEMPLATES$b = Object.freeze({
    product: product$1,
    article,
    image,
    question: question$2,
    root: root$a,
    [STATUS.READY]: ready$1,
    empty: () => ``,
    body: body$2,
    list,
    ordered: false,
    items,
    item: item$3,
    productInfoBlock,
    articleInfoBlock,
    imageInfoBlock,
    brandBlock,
    titleBlock,
    descriptionBlock,
    dateBlock,
    priceBlock,
    discountRateText,
    ctaBlock,
    cta,
    imageBlock,
    indexBlock,
    trigger,
    loading,
  });

  class CollectionLayout extends TemplateBasedLayout {

    static get defaultTemplates() {
      return DEFAULT_TEMPLATES$b;
    }

    constructor({ templates, itemType = 'product', ...options }) {
      super({
        templates: { ...DEFAULT_TEMPLATES$b, ...templates },
        itemType,
        ...options,
      });
      this._initTrackable();
      this._initTriggerable();
    }

    initialize(view) {
      this._unsubscribes.push(view.proxyElement.on('click', this._onClick.bind(this)));
    }

    _preprocess({ state, rendered }) {
      const incremental = this._shallRenderIncrementally(state, rendered);
      const html = this._html(state, rendered, incremental);
      return {
        ...state,
        incremental,
        html,
      };
    }

    _shallRenderIncrementally(state, rendered) {
      // TODO: compare item ids as well
      return this.options.incremental &&
      rendered && rendered.value && rendered.value.length > 0 &&
      state.value && state.value.length >= rendered.value.length &&
        state.session && rendered.session &&
        state.session.id === rendered.session.id;
    }

    _html(state, rendered, incremental) {
      if (incremental) {
        const offset = rendered.value.length;
        const values = (this._getItems(state) || []).slice(offset);
        return values.length > 0 ? this.templates.items(this, state, values, { offset }) : '';
      } else {
        return this.templates.root(this, state);
      }
    }

    _render(element, { state }, { notifyUpdate }) {
      const { incremental, html } = state;
      if (incremental) {
        if (html) {
          const listElement = this._getListElement(element);
          listElement.insertAdjacentHTML('beforeend', html);
        } else {
          notifyUpdate(false);
        }
      } else {
        element.innerHTML = html;
      }
    }

    _afterRender(element, state) {
      this._syncBindings(element, state);
      this._syncTrigger(element, state);
    }

    _unrender() {
      this._clearBindings();
      this._untrackTrigger();
    }

    _getItems(state) {
      return state.value;
    }

    _getListElement(element) {
      return element.querySelector('[data-role="list"]');
    }

    _getItemElements(element) {
      return element ? Array.from(element.querySelectorAll(`[data-role="item"]`)) : [];
    }

    _onClick(event) {
      const element = event.target.closest(`[data-role="item"]`);
      if (!element) {
        return;
      }
      const binding = this._bindings.get(element);
      if (!binding) {
        return;
      }
      this._trackClick(event, binding);
      this._emitClickEvent(event, binding);
    }

    _emitClickEvent(event, binding) {
      const { session } = this._view._state;
      const { value, element } = binding;
      this._view._events.emit('click', { session, value, element, domEvent: event });
    }

    destroy() {
      this._destroyTrackable();
      this._destroyTriggerable();
      this._view = undefined;
      super.destroy();
    }

  }

  makeTrackable(CollectionLayout.prototype);
  makeTriggerable(CollectionLayout.prototype);

  const TYPE$c = 'list';
  const DEFAULT_CLASSNAME$c = 'miso-list';

  class ListLayout extends CollectionLayout {

    static get type() {
      return TYPE$c;
    }

    static get defaultTemplates() {
      return super.defaultTemplates;
    }

    static get defaultClassName() {
      return DEFAULT_CLASSNAME$c;
    }

    constructor({ className = DEFAULT_CLASSNAME$c, ...options } = {}) {
      super({ className, ...options });
    }

  }

  const TYPE$b = 'cards';
  const DEFAULT_CLASSNAME$b = 'miso-cards';

  class CardsLayout extends CollectionLayout {

    static get type() {
      return TYPE$b;
    }

    static get defaultTemplates() {
      return super.defaultTemplates;
    }

    static get defaultClassName() {
      return DEFAULT_CLASSNAME$b;
    }

    constructor({ className = DEFAULT_CLASSNAME$b, ...options } = {}) {
      super({ className, ...options });
    }

  }

  function setOrRemoveAttribute(element, name, value) {
    if (value === undefined) {
      element.removeAttribute(name);
    } else {
      element.setAttribute(name, value);
    }
  }

  function addOrRemoveClass(element, name, add) {
    if (add) {
      element.classList.add(name);
    } else {
      element.classList.remove(name);
    }
  }

  function resolveCssLength(str) {
    if (typeof str === 'number') {
      return str;
    }
    const [value, unit] = parseLength(str);
    switch (unit) {
      case '':
      case 'px':
        return value;
      case 'rem':
        return remToPx(value);
      default:
        throw new Error(`Unsupported unit: ${unit}`);
    }
  }

  function parseLength(str) {
    const match = str.match(/^([+-]?(?:\d+|\d*\.\d+))([a-z]*)$/);
    if (!match) {
      throw new Error(`Invalid length: ${str}`);
    }
    const value = parseFloat(match[1]);
    const unit = match[2] || '';
    return [value, unit];
  }

  function remToPx(value = 1) {
    return value * parseFloat(getComputedStyle(document.documentElement).fontSize);
  }

  function cssAspectRatio(value) {
    return (value === undefined || value instanceof CssAspectRatio) ? value : new CssAspectRatio(value);
  }

  class CssAspectRatio {

    constructor(value) {
      this._width = NaN;
      this._height = NaN;
      switch (typeof value) {
        case 'number':
          this._width = value;
          this._height = 1;
          break;
        case 'object':
          if (Array.isArray(value)) {
            this._width = parseFloat(value[0]);
            this._height = parseFloat(value[1]);
          }
          break;
        case 'string':
          const i = value.indexOf('/');
          if (i < 0) {
            this._width = parseFloat(value);
            this._height = 1;
          } else {
            this._width = parseFloat(value.slice(0, i).trim());
            this._height = parseFloat(value.slice(i + 1).trim());
          }
          break;
      }
      if (this._width === NaN || this._height === NaN) {
        throw new Error(`Invalid aspect ratio value: ${value}`);
      }
    }

    get width() {
      return this._width;
    }

    get height() {
      return this._height;
    }

    get floatValue() {
      return this._width / this._height;
    }

    scaleBy(factor) {
      factor = cssAspectRatio(factor);
      return cssAspectRatio([factor._width * this._width, factor._height * this._height]);
    }

    toString() {
      return this._height === 1 ? `${this._width}` : `${this._width} / ${this._height}`;
    }
  }

  function makeSwipeable(prototype) {
    mixin(prototype, SwipeableMixin.prototype);
  }

  class SwipeableMixin {
    
    _initSwipeable() {
      this._swipeableContext = {
        itemCount: undefined,
        itemIndex: undefined,
        displayedCount: undefined,
        displayedIndex: undefined,
        displayEventIndex: undefined,
      };
    }

    // TODO: autoplay

    get itemIndex() {
      return this._swipeableContext.itemIndex;
    }

    set itemIndex(index) {
      const context = this._swipeableContext;
      if (context.itemCount === undefined) {
        return;
      }
      if (index < 0) {
        index = context.itemCount - 1;
      } else if (index >= context.itemCount) {
        index = 0;
      }
      context.itemIndex = index;
      requestAnimationFrame(() => this._syncDisplayedSwipeableItemIndex());
    }

    next() {
      if (this._swipeableContext.itemCount === undefined) {
        return;
      }
      this.itemIndex++;
    }

    previous() {
      if (this._swipeableContext.itemCount === undefined) {
        return;
      }
      this.itemIndex--;
    }

    _renderSwipeable(element, states, controls) {
      this._syncSwipeableItemCount(states);
      this._syncDisplayedSwipeableItemCount();
      this._syncDisplayedSwipeableItemIndex();
    }

    _afterRenderSwipeable() {
      this._emitSwipeableDisplayEvent();
    }

    _syncSwipeableItemCount({ state } = {}) {
      const context = this._swipeableContext;
      const items = this._getItems(state);
      const oldItemCount = context.itemCount;
      const itemCount = context.itemCount = items ? items.length : undefined;

      if (itemCount === oldItemCount) {
        return;
      }
      // TODO: concern count === 0
      if (itemCount === undefined) {
        context.itemIndex = undefined;
      } else if (oldItemCount === undefined) {
        context.itemIndex = 0;
      }
    }

    _syncDisplayedSwipeableItemCount() {
      const context = this._swipeableContext;
      const { itemCount } = context;
      if (itemCount === context.displayedCount) {
        return;
      }
      let { element } = this._view;
      element = element.firstElementChild;
      if (!element) {
        return;
      }
      setOrRemoveAttribute(element, 'data-item-count', itemCount);
      context.displayedCount = itemCount;
    }

    _syncDisplayedSwipeableItemIndex() {
      const context = this._swipeableContext;
      const { itemIndex } = context;
      if (itemIndex === context.displayedIndex) {
        return;
      }
      context.displayedIndex = itemIndex;

      this._syncSwipeableListIndex(itemIndex);
      this._syncSwipeableIndicatorIndex(itemIndex);
    }

    _syncSwipeableListIndex(index) {
      const { element } = this._view;
      const listElement = element && this._getListElement(element);
      if (!listElement) {
        return;
      }
      listElement.style.left = `${-index * 100}%`;
    }

    _syncSwipeableIndicatorIndex(index) {
      const { element } = this._view;
      const indicatorElement = element && this._getSwipeableIndicatorElement(element);
      if (!indicatorElement) {
        return;
      }
      let i = 0;
      for (const item of indicatorElement.children) {
        addOrRemoveClass(item, 'active', i === index);
        i++;
      }
    }

    _getSwipeableIndicatorElement(element) {
      return element.querySelector('[data-role="index-indicator"]');
    }

    _emitSwipeableDisplayEvent() {
      const context = this._swipeableContext;
      const index = context.displayedIndex;
      if (context.displayEventIndex === index) {
        return;
      }
      context.displayEventIndex = index;
      this._view._events.emit('display', { index });
    }

    _onClickSwipeable(event) {
      const { target } = event;
      if (target.closest(`[data-role="previous"]`)) {
        event.preventDefault();
        this.previous();
      }
      if (target.closest(`[data-role="next"]`)) {
        event.preventDefault();
        this.next();
      }
    }

    // TODO: swipe gesture

  }

  var version = 'dev'; // this will be replaced by bin/version.js in CD workflow

  function trianglePath(r) {
    const l = 100;
    const d = r * Math.tan(3 * Math.PI / 8);
    const e = d * Math.sin(Math.PI / 4);
    return `M${r} 0L${l-d} 0A${r} ${r} 0 0 1 ${l-e} ${e}L${e} ${l-e}A${r} ${r} 0 0 1 0 ${l-d}L0 ${r}Z`;
  }

  const PREFIX = 'miso-ui-icon';
  const ID = `${PREFIX}-svg-${version.replaceAll('.', '_')}`;

  const ICON_NAME = {
    SEND: 'send',
    SEARCH: 'search',
    TRIANGLE: 'triangle',
    TRIANGLE_EQ: 'triangle-eq',
    CHEVRON: 'chevron',
    CHEVRON_NEGATIVE: 'chevron-negative',
  };

  // CC0 SVGs
  const ICON_SEND = `<symbol id="${PREFIX}-${ICON_NAME.SEND}" viewBox="0 0 32 32"><path fill="currentColor" d="M11.499,19.173l5.801,-5.849c0.389,-0.392 1.022,-0.394 1.414,-0.006c0.392,0.389 0.395,1.022 0.006,1.414l-5.798,5.847l5.306,8.002c0.207,0.313 0.572,0.483 0.945,0.441c0.373,-0.042 0.691,-0.289 0.824,-0.64l9.024,-23.904c0.138,-0.366 0.05,-0.78 -0.226,-1.058c-0.276,-0.278 -0.689,-0.369 -1.057,-0.233l-24.004,8.892c-0.353,0.13 -0.602,0.448 -0.646,0.821c-0.044,0.373 0.125,0.74 0.438,0.948l7.973,5.325Z"/></symbol>`;
  const ICON_SEARCH = `<symbol id="${PREFIX}-${ICON_NAME.SEARCH}" viewBox="0 0 24 24"><path fill="currentColor" d="M4 11C4 7.13401 7.13401 4 11 4C14.866 4 18 7.13401 18 11C18 14.866 14.866 18 11 18C7.13401 18 4 14.866 4 11ZM11 2C6.02944 2 2 6.02944 2 11C2 15.9706 6.02944 20 11 20C13.125 20 15.078 19.2635 16.6177 18.0319L20.2929 21.7071C20.6834 22.0976 21.3166 22.0976 21.7071 21.7071C22.0976 21.3166 22.0976 20.6834 21.7071 20.2929L18.0319 16.6177C19.2635 15.078 20 13.125 20 11C20 6.02944 15.9706 2 11 2Z"/></symbol>`;

  // Custom SVGs
  const ICON_TRIANGLE = `<symbol id="${PREFIX}-${ICON_NAME.TRIANGLE}" viewBox="-5 -5 105 105"><path d="${trianglePath(5)}"/></symbol>`;

  const ICON_TRIANGLE_EQ = `<symbol id="${PREFIX}-${ICON_NAME.TRIANGLE_EQ}" viewBox="-100 -100 200 200"><path d="M12.99 -77.5A15 15,0,0,0,-12.99 -77.5L-73.61 27.5A15 15,0,0,0,-60.62 50L60.62 50A15 15,0,0,0,73.61 27.5L12.99 -77.5Z"/></symbol>`;

  const ICON_CHEVRON = `<symbol id="${PREFIX}-${ICON_NAME.CHEVRON}" viewBox="-100 -100 200 200"><path d="M10.61 -43.94A15 15,0,0,0,-10.61 -43.94L-60.61 6.06A15 15,0,0,0,-39.39 27.27L0 -12.12L39.39 27.27A15 15,0,0,0,60.61 6.06L10.61 -43.94Z"/></symbol>`;

  const ICON_CHEVRON_NEGATIVE = `<symbol id="${PREFIX}-${ICON_NAME.CHEVRON_NEGATIVE}" viewBox="-100 -100 200 200"><path d="M100 100V-200H-200V200H200ZM-10.61 -43.94A15 15,0,0,1,10.61 -43.94L60.61 6.06A15 15,0,0,1,39.39 27.27L0 -12.12L-39.39 27.27A15 15,0,0,1,-60.61 6.06L-10.61 -43.94Z"/></symbol>`;

  const ICONS = [ICON_SEND, ICON_SEARCH, ICON_TRIANGLE, ICON_TRIANGLE_EQ, ICON_CHEVRON, ICON_CHEVRON_NEGATIVE];

  const SPRITES_SVG = `<svg id="${ID}" style="display:none;">${ICONS.join('')}</svg>`;

  let loaded = false;

  function loadSvgSprites() {
    if (loaded || document.head.querySelector(`#${ID}`)) {
      return;
    }
    loaded = true;
    document.head.insertAdjacentHTML('beforeend', SPRITES_SVG);
  }

  loadSvgSprites();

  function _icon(name) {
    return `<svg class="miso-ui-icon miso-ui-icon-${name}"><use href="#${PREFIX}-${name}"></use></svg>`;
  }

  const ICON_NAMES = new Set(Object.values(ICON_NAME));

  function getIcon(name) {
    return ICON_NAMES.has(name) ? _icon(name) : '';
  }
  const TRIANGLE = _icon(ICON_NAME.TRIANGLE);
  const CHEVRON = _icon(ICON_NAME.CHEVRON);
  const CHEVRON_NEGATIVE = _icon(ICON_NAME.CHEVRON_NEGATIVE);

  const TYPE$a = 'carousel';
  const DEFAULT_CLASSNAME$a = 'miso-carousel';

  const DEFAULT_TEMPLATES$a = Object.freeze({
    body: body$1,
    controls,
    controlContainer: controlContainer$1,
    control: control$1,
    controlIcon: controlIcon$1,
    indexIndicator,
    indexIndicatorItem: () => ``,
    trigger: () => ``, // no trigger element
  });

  const INHERITED_DEFAULT_TEMPLATES$1 = Object.freeze({
    ...CollectionLayout.defaultTemplates,
    ...DEFAULT_TEMPLATES$a,
  });

  function body$1(layout, state, values) {
    const { className, templates } = layout;
    return `<div class="${className}__viewport"><div class="${className}__viewport-inner">${templates.list(layout, state, values)}</div></div>${templates.controls(layout, state, values)}`;
  }

  function controls(layout, state, values) {
    const { templates } = layout;
    return `${templates.controlContainer(layout, state, 'previous')}${templates.controlContainer(layout, state, 'next')}${templates.indexIndicator(layout, state, values)}`;
  }

  function controlContainer$1(layout, state, direction) {
    const { className, templates } = layout;
    return `<div class="${className}__control-container-${direction}">${templates.control(layout, state, direction)}</div>`;
  }

  function control$1(layout, state, direction) {
    const { className, templates } = layout;
    return `<div class="${className}__control-${direction}" data-role="${direction}">${templates.controlIcon(layout, state, direction)}</div>`;
  }

  function controlIcon$1(layout) {
    return layout.options.itemType === 'image' ? CHEVRON_NEGATIVE : CHEVRON;
  }

  function indexIndicator(layout, state, values) {
    const { className, templates } = layout;
    return `<ul class="${className}__index-indicator" data-role="index-indicator">${values.map(value => `<li class="${className}__index-indicator-item">${templates.indexIndicatorItem(layout, state, value)}</li>`).join('')}</ul>`;
  }

  class CarouselLayout extends CollectionLayout {

    static get type() {
      return TYPE$a;
    }

    static get defaultTemplates() {
      return INHERITED_DEFAULT_TEMPLATES$1;
    }

    static get defaultClassName() {
      return DEFAULT_CLASSNAME$a;
    }

    constructor({ className = DEFAULT_CLASSNAME$a, templates, ...options } = {}) {
      super({ className, templates: { ...DEFAULT_TEMPLATES$a, ...templates }, ...options });
      this._initSwipeable();
    }

    _render(element, states, controls) {
      super._render(element, states, controls);
      this._renderSwipeable(element, states, controls);
    }

    _afterRender(element, state) {
      super._afterRender(element, state);
      this._afterRenderSwipeable(element, state);
    }

    _onClick(event) {
      this._onClickSwipeable(event);
      super._onClick(event);
    }

  }

  makeSwipeable(CarouselLayout.prototype);

  function calculateItemSizes(itemCount, columnCount) {
    const totalSpaces = columnCount * 2;
    let remainingSpaces = Math.max(totalSpaces - itemCount, 0);

    let small = itemCount;
    // turning a small block into a large block takes 3 extra spaces
    const large = Math.min(Math.floor(remainingSpaces / 3), small);
    small -= large;
    remainingSpaces -= large * 3;
    // turning a small block into a medium block takes 1 extra space
    const medium = Math.min(remainingSpaces, small);
    small -= medium;
    remainingSpaces -= medium;

    return [large, medium, small];
  }

  function item$2(layout, state, value, index) {
    const { className, templates, options } = layout;
    const { itemType } = options;
    const body = templates[itemType](layout, state, value, { index });
    const sizeClass = value._size ? ` ${className}__item-${value._size}` : '';
    return `<li class="${className}__item${sizeClass}">${body}</li>`;
  }

  const DEFAULT_HEIGHT = '16rem';

  const DEFAULT_TEMPLATES$9 = Object.freeze({
    ...CollectionLayout.defaultTemplates,
    item: item$2,
  });

  const TYPE$9 = 'gallery';
  const DEFAULT_CLASSNAME$9 = 'miso-gallery';

  class GalleryLayout extends CollectionLayout {

    static get type() {
      return TYPE$9;
    }

    static get defaultTemplates() {
      return DEFAULT_TEMPLATES$9;
    }

    static get defaultClassName() {
      return DEFAULT_CLASSNAME$9;
    }

    constructor({ className = DEFAULT_CLASSNAME$9, templates, ...options } = {}) {
      super({
        className,
        templates: { ...DEFAULT_TEMPLATES$9, ...templates },
        ...options,
      });
      this._galleryContext = {
        itemAspectRatio: undefined,
        itemCount: undefined,
        columnCount: undefined,
      };
    }

    syncSize() {
      const { element } = this._view;
      const listElement = element && this._getListElement(element);
      if (!listElement) {
        return;
      }
      this._syncListAspectRatio(listElement);
      this._syncItemSizes(listElement);
    }

    _preprocess({ state, rendered }) {
      const incremental = this._shallRenderIncrementally(state, rendered);
      const bodyHtml = incremental ? undefined : this._bodyHtml(state);
      const itemsHtml = this._itemsHtml(state, rendered);
      return {
        ...state,
        ...trimObj({
          incremental,
          bodyHtml,
          itemsHtml,
        }),
      };
    }

    _bodyHtml(state) {
      return this.templates.root(this, { ...state, value: [] });
    }

    _itemsHtml(state, rendered) {
      const offset = (rendered && rendered.value && rendered.value.length) || 0;
      const values = (this._getItems(state) || []).slice(offset);
      return values.length > 0 ? this.templates.items(this, state, values, { offset }) : '';
    }

    _render(element, states, controls) {
      this._syncItemCount(states);
      this._syncCssVariables();
      const listElement = this._renderListElement(element, states, controls);
      if (!listElement) {
        return;
      }
      this._syncListAspectRatio(listElement);
      this._renderItems(listElement, states, controls);
    }

    _renderListElement(element, { state }) {
      const { incremental, bodyHtml } = state;
      if (!incremental) {
        element.innerHTML = bodyHtml;
      }
      return this._getListElement(element);
    }

    _renderItems(listElement, states) {
      if (states.state.incremental) {
        this._appendItems(listElement, states);
      } else {
        this._updateItems(listElement, states);
      }
    }

    _updateItems(listElement, { state }) {
      const { itemSizes } = this._galleryContext;
      const values = this._writeItemSizes(this._getItems(state) || [], itemSizes);
      listElement.innerHTML = this.templates.items(this, state, values);
    }

    _appendItems(listElement, { state }) {
      const { itemSizes } = this._galleryContext;
      // update existing items
      this._syncItemSizes(listElement);
      // append new items
      const offset = listElement.children.length;
      const values = this._writeItemSizes((this._getItems(state) || []).slice(offset), itemSizes, offset);
      listElement.insertAdjacentHTML('beforeend', this.templates.items(this, state, values, { offset }));
    }

    _writeItemSizes(values, [large = 0, medium = 0] = [], offset = 0) {
      let omitted = 0;
      if (offset > 0) {
        omitted = Math.min(offset, large);
        offset -= omitted;
        large -= omitted;
      }
      if (offset > 0) {
        omitted = Math.min(offset, medium);
        offset -= omitted;
        medium -= omitted;
      }
      const results = [];
      for (const value of values) {
        let _size = 'small';
        if (large > 0) {
          _size = 'large';
          large--;
        } else if (medium > 0) {
          _size = 'medium';
          medium--;
        }
        results.push({ ...value, _size });
      }
      return results;
    }

    _syncCssVariables() {
      const context = this._galleryContext;
      let { itemAspectRatio = 1 } = this.options;
      itemAspectRatio = context.itemAspectRatio = cssAspectRatio(itemAspectRatio);
      const { element } = this._view;
      if (!element) {
        return;
      }
      // TODO: skip if equal to default values
      element.style.setProperty('--miso-gallery-item-1x1-aspect-ratio', `${itemAspectRatio}`);
      element.style.setProperty('--miso-gallery-item-1x2-aspect-ratio', `${itemAspectRatio.scaleBy([1, 2])}`);
    }

    _syncListAspectRatio(listElement) {
      const context = this._galleryContext;
      const { itemCount, itemAspectRatio } = context;
      const { height = DEFAULT_HEIGHT } = this.options;
      const resolvedHeight = resolveCssLength(height);
      const width = listElement.clientWidth;
      if (width === 0) {
        context.columnCount = undefined;
        context.itemSizes = undefined;
        return; // probably not visible yet
      }
      const columnCount = context.columnCount = Math.round((width * itemAspectRatio.width * 2) / (resolvedHeight * itemAspectRatio.height));
      context.itemSizes = calculateItemSizes(itemCount, columnCount);

      // update DOM
      listElement.style.aspectRatio = `${columnCount} / 2`;
      listElement.style.height = itemCount > 0 ? 'auto' : '0';
    }

    _syncItemCount({ state } = {}) {
      const items = this._getItems(state);
      this._galleryContext.itemCount = items ? items.length : undefined;
    }

    _syncItemSizes(listElement) {
      const { itemSizes = [] } = this._galleryContext;
      let [large = 0, medium = 0] = itemSizes;
      const { className } = this;

      // update DOM
      for (const itemElement of listElement.children) {
        let lg = false, md = false;
        if (large > 0) {
          lg = true;
          large--;
        } else if (medium > 0) {
          md = true;
          medium--;
        }
        addOrRemoveClass(itemElement, `${className}__item-large`, lg);
        addOrRemoveClass(itemElement, `${className}__item-medium`, md);
        addOrRemoveClass(itemElement, `${className}__item-small`, !lg && !md);
      }
    }

  }

  const TYPE$8 = 'search-box';
  const DEFAULT_CLASSNAME$8 = 'miso-search-box';
  const DEFAULT_AUTOCOMPLETE_CLASSNAME = 'miso-autocomplete';

  function root$9(layout) {
    const { className, templates, role, options, autocomplete } = layout;
    const { placeholder } = options;
    const roleAttr = role ? `data-role="${role}"` : '';
    return `
<div class="${className}" ${roleAttr}>
  <div class="${className}__input-group">
    <input class="${className}__input" type="text" data-role="input" ${placeholder ? `placeholder="${placeholder}"` : ''}>
    <button class="${className}__button" type="submit" data-role="submit">${templates.buttonContent(layout)}</button>
  </div>
  <div class="${autocomplete.className}" data-role="autocomplete"></div>
</div>`.trim();
  }

  function buttonContent(layout) {
    const { templates, options } = layout;
    if (options.buttonText) {
      return options.buttonText; // legacy
    }
    const { buttonText, buttonIcon } = templates;
    const text = typeof buttonText === 'function' ? buttonText(layout) : `${buttonText}`;
    const icon = typeof buttonIcon === 'function' ? buttonIcon(layout) : (getIcon(buttonIcon) || `${buttonIcon}`);
    return text + icon;
  }

  function completions(layout, items) {
    const { templates, workflow, autocomplete } = layout;
    // use options under layout.autocomplete from now on
    layout = {
      templates,
      workflow,
      ...autocomplete,
    };

    const products = [], queries = [];
    for (const item of items) {
      (item.product ? products : queries).push(item);
    }

    return templates.queries(layout, queries) + (queries.length > 0 && products.length > 0 ? `<hr>` : '') + templates.products(layout, products);
  }

  function queries(layout, items) {
    const { templates } = layout;
    return templates.completionList(layout, 'query', items);
  }

  function products(layout, items) {
    const { templates } = layout;
    return templates.completionList(layout, 'product', items);
  }

  function query(layout, { text, text_with_inverted_markups } = {}) {
    return text_with_inverted_markups || escapeHtml(text);
  }

  function product(layout, { product }) {
    const { templates } = layout;
    const [openTag, closeTag] = templates.helpers.tagPair(layout, product, { role: false });
    return [
      openTag,
      templates.imageBlock(layout, product),
      templates.productInfoBlock(layout, product),
      closeTag,
    ].join('');
  }

  function completionList(layout, type, items) {
    const { className, templates } = layout;
    return `<ul class="${className}__${type}-list" data-role="${type}-list">${items.map(item => templates.completionItem(layout, type, item)).join('')}</ul>`;
  }

  function completionItem(layout, type, item) {
    const { className, templates } = layout;
    return `
<li class="${className}__${type}-item" data-role="${type}-item" data-index="${item._index}" tabindex="0">
  ${templates[type](layout, item)}
</li>`.trim();
  }

  const DEFAULT_TEMPLATES$8 = Object.freeze({
    root: root$9,
    buttonContent,
    buttonText: '',
    buttonIcon: 'search',
    completions,
    completionList,
    completionItem,
    queries,
    products,
    query,
    product,
    imageBlock,
    productInfoBlock,
  });

  const DEFAULT_AUTOCOMPLETE_OPTIONS$3 = Object.freeze({
    className: DEFAULT_AUTOCOMPLETE_CLASSNAME,
    debounce: 300,
  });

  class SearchBoxLayout extends TemplateBasedLayout {

    static get type() {
      return TYPE$8;
    }

    static get defaultTemplates() {
      return DEFAULT_TEMPLATES$8;
    }

    static get defaultClassName() {
      return DEFAULT_CLASSNAME$8;
    }

    constructor({ className = DEFAULT_CLASSNAME$8, templates, autocomplete, ...options } = {}) {
      super({
        className,
        templates: { ...DEFAULT_TEMPLATES$8, ...templates },
        ...options,
      });
      defineValues(this, {
        autocomplete: { ...DEFAULT_AUTOCOMPLETE_OPTIONS$3, ...autocomplete },
      });
      this._contexts = new WeakMap();
      this._prevInput = undefined;
      this._debounce = debounce(this.autocomplete.debounce);
    }

    initialize(view) {
      const { proxyElement, hub } = view;
      this._unsubscribes = [
        ...this._unsubscribes,
        proxyElement.on('input', (e) => this._syncInput(e)),
        proxyElement.on('keydown', (e) => this._handleKeyDown(e)),
        proxyElement.on('click', (e) => this._handleClick(e)),
        proxyElement.on('focusin', (e) => this._handleFocusIn(e)),
        proxyElement.on('focusout', (e) => this._handleFocusOut(e)),
        hub.on(completions$1(), () => view.refresh({ force: true })),
      ];
    }

    focus() {
      // TODO: support blur as well
      if (this._element) {
        this._context().focus();
      } else {
        // take a rain check, wait for render
        this._focusRequested = true;
      }
    }

    open() {
      this._element.classList.add('open');
    }

    close() {
      this._element.classList.remove('open');
    }

    set value(value) {
      if (this._element) {
        this._context().value = value;
      } else {
        this._valueRequested = value;
      }
    }

    _preprocess({ state }) {
      state = super._preprocess({ state });
      return {
        ...state,
        completions: this._view.hub.states[completions$1()],
      };
    }

    _render(element, data, controls) {
      if (element.childElementCount === 0) {
        // only render the template once, and also skip if there are children already to allow customized DOM
        super._render(element, data, controls);
      }
      this._updateCompletions(element, data, controls);
    }

    _afterRender(element, state) {
      this._fullfillFocusRequest(element);
      this._fullfillValueRequest(element);
    }

    _updateCompletions(element, { state, rendered }, { writeToState }) {
      if (!state.completions) {
        return;
      }
      const { status = STATUS.INITIAL, session, value: completions } = state.completions;
      const { index } = session;
      if (rendered && rendered.completions.index === index && rendered.completions.status === status) {
        return;
      }
      const context = this._context(element);
      const { autocompleteElement } = context;
      if (!autocompleteElement) {
        return;
      }

      const items = context.trackItems(completions);

      addOrRemoveClass(element, 'nonempty', items.length > 0);
      autocompleteElement.setAttribute('data-status', status);
      autocompleteElement.innerHTML = this.templates.completions(this, items);

      writeToState({ completions: { index, status } });
    }

    _fullfillFocusRequest(element) {
      if (!element || !this._focusRequested) {
        return;
      }
      this._focusRequested = false;
      this._context(element).focus();
    }

    _fullfillValueRequest(element) {
      if (!element || !this._valueRequested) {
        return;
      }
      this._context(element).value = this._valueRequested;
      this._valueRequested = undefined;
    }

    _context(element) {
      element = element || this._view.element;
      if (!element) {
        return Context.empty();
      }
      let context = this._contexts.get(element);
      if (!context) {
        this._contexts.set(element, context = new Context(element));
      }
      return context;
    }

    _syncInput() {
      const { inputElement } = this._context();
      if (!inputElement) {
        return;
      }
      const value = inputElement.value.trim();

      if (this._prevInput === value) {
        return;
      }
      this._prevInput = value;

      const self = this;
      this._debounce(() => self._view.hub.update(input(), { value }));
    }

    _handleFocusIn({ target }) {
      if (!this._element) {
        return;
      }
      if (target.matches('[data-role="input"]')) {
        this._syncInput();
        this.open();
      }
    }

    _handleFocusOut({ relatedTarget }) {
      if (!this._element) {
        return;
      }
      if (!relatedTarget || !findInAncestors(relatedTarget, element => element === this._element || undefined)) {
        this.close();
      }
    }

    _handleKeyDown({ key, target, isComposing }) {
      if (!isComposing && key === 'Enter' && target.matches('[data-role="input"]')) {
        this._submit(target.value);
        target.blur();
      }
      // TODO: select completion items with arrow keys
    }

    _handleClick(event) {
      const { target } = event;
      const { inputElement } = this._context();
      for (let element = target; element && element !== this._element; element = element.parentElement) {
        if (element.matches('[data-role="submit"]') || element.matches('[data-role="button"]') || element.matches('[type="submit"]')) {
          if (inputElement) {
            inputElement.blur();
            this._submit(inputElement.value);
          }
          return;
        }
        if (element.matches('[data-role="query-item"]')) {
          const index = element.getAttribute('data-index');
          const item = this._context().data.get(parseInt(index));
          const value = item && item.text;
          if (value) {
            if (inputElement) {
              inputElement.value = value;
            }
            this._view._events.emit('select', Object.freeze({ value: item, index, domEvent: event }));
            if (!event.defaultPrevented) {
              this._submit(value);
            }
          }
          this.close();
          return;
        }
        if (element.matches('[data-role="product-item"]')) {
          this._view._events.emit('select', Object.freeze({ value: item, index, domEvent: event }));
          return;
        }
      }
    }

    async _submit(value) {
      if (!value || !value.trim()) {
        return;
      }
      this.close();
      // TODO: q -> value
      this._view.hub.update(query$1(), { q: value });
      this._trackSubmit(value);
    }

    _trackSubmit(value) {
      const { [EVENT_TYPE.SUBMIT]: options } = this._view.tracker.options || {};
      if (!options) {
        return;
      }
      this._view.tracker.submit({ value }); // not array
    }

  }

  class Context {

    static empty() {
      return Context._empty || (Context._empty = new Context());
    }

    constructor(element) {
      this._element = element;
      this._cache = {};
      this._data = new Map();
    }

    get inputElement() {
      return this._get('input');
    }

    get autocompleteElement() {
      return this._get('autocomplete');
    }

    get data() {
      return this._data;
    }

    trackItems(completions) {
      let index = 0;
      const data = this._data = new Map();
      const items = [];
      for (const field in completions) {
        for (const item of completions[field]) {
          if (item.product && !item.product.url) {
            continue; // product without URL is not clickable
          }
          item._index = index;
          item._field = field;
          data.set(index, item);
          items.push(item);
          index++;
        }
      }
      return items;
    }

    focus() {
      if (!this._element) {
        return;
      }
      const { inputElement } = this;
      inputElement && inputElement.focus();
    }

    set value(value) {
      if (!this._element) {
        return;
      }
      const { inputElement } = this;
      inputElement && (inputElement.value = value);
    }

    _get(role) {
      return !this._element ? undefined : this._cache[role] || (this._cache[role] = this._element.querySelector(`[data-role="${role}"]`));
    }

  }

  const TYPE$7 = 'option-list';
  const DEFAULT_CLASSNAME$7 = 'miso-option-list';

  function root$8(layout, state) {
    const { className, role, templates } = layout;
    const roleAttr = role ? `data-role="${role}"` : '';
    return `
<div class="${className}" ${roleAttr}>
  ${templates.options(layout, state)}
</div>
`;
  }

  function options$3(layout, state) {
    const { className, templates } = layout;
    const values = state.value || [];
    return `
<ol class="${className}__options" data-role="options">
  ${values.map((value, index) => templates.option(layout, value, { index })).join('')}
</ol>
`;
  }

  function option$3(layout, value) {
    const { className } = layout;
    const text = escapeHtml(value.text || value);
    return `<li class="${className}__option" data-role="option" tabindex="0">${text}</li>`;
  }

  const DEFAULT_TEMPLATES$7 = Object.freeze({
    root: root$8,
    options: options$3,
    option: option$3,
  });

  class OptionListLayout extends TemplateBasedLayout {

    static get type() {
      return TYPE$7;
    }

    static get defaultTemplates() {
      return DEFAULT_TEMPLATES$7;
    }

    static get defaultClassName() {
      return DEFAULT_CLASSNAME$7;
    }

    constructor({ className = DEFAULT_CLASSNAME$7, templates, ...options } = {}) {
      super({
        className,
        templates: { ...DEFAULT_TEMPLATES$7, ...templates },
        ...options,
      });
      this._initTrackable();
    }

    initialize(view) {
      const { proxyElement, hub } = view;
      this._unsubscribes = [
        ...this._unsubscribes,
        proxyElement.on('click', (e) => this._handleClick(e)),
        hub.on(suggestions(), () => this._handleInput()), // TODO: use data mapping
      ];
    }

    _preprocess() {
      return super._preprocess({
        state: this._view.hub.states[suggestions()], // TODO: use data mapping
      });
    }

    _render(element, data, controls) {
      super._render(element, data, controls);
      const { state } = data;
      this._syncOptionValues(element, state);
    }

    _afterRender(element, state) {
      this._syncBindings(element, state);
    }

    _unrender() {
      this._clearBindings();
    }

    _syncOptionValues(element, state) {
      const optionsElement = element && this._getOptionsElement(element);
      if (!optionsElement) {
        return;
      }
      const optionValues = this._getItems(state) || [];
      addOrRemoveClass(optionsElement, 'empty', optionValues.length === 0);
    }

    _getItems(state) {
      return state.value;
    }

    _getOptionsElement(element) {
      return element.querySelector(`[data-role="options"]`);
    }

    _getItemElements(element) {
      return element ? Array.from(element.querySelectorAll(`[data-role="option"]`)) : [];
    }

    _handleClick(event) {
      const element = event.target.closest(`[data-role="option"]`);
      if (!element) {
        return;
      }
      const binding = this._bindings.get(element);
      const option = binding && binding.value;
      if (!option) {
        return;
      }
      this._trackClick(event, binding);
      this._submit(option.text);
    }

    async _submit(value) {
      if (!value) {
        return;
      }
      // TODO: q -> value
      this._view.hub.update(query$1(), { q: value });
    }

    destroy() {
      this._destroyTrackable();
      super.destroy();
    }

  }

  makeTrackable(OptionListLayout.prototype);

  function root$7(layout) {
    const { className, role, templates } = layout;
    const roleAttr = role ? `data-role="${role}"` : '';
    return `
<div class="${className}" ${roleAttr}>
  ${templates.options(layout)}
</div>
`;
  }

  function option$2(layout, data) {
    const { className, templates } = layout;
    return `
<div role="button" class="${className}__option" data-value="${data.value}">
  ${templates.content(layout, data)}
</div>
`;
  }

  const DEFAULT_TEMPLATES$6 = Object.freeze({
    ...requiresImplementation('options'),
    root: root$7,
    option: option$2,
  });

  class RadioLayout extends TemplateBasedLayout {

    static get defaultTemplates() {
      return DEFAULT_TEMPLATES$6;
    }

    constructor({ className, templates, field, defaultValue, ...options } = {}) {
      super({
        className,
        templates: { ...DEFAULT_TEMPLATES$6, ...templates },
        ...options,
      });
      this._field = field;
      this._defaultValue = defaultValue;
    }

    initialize(view) {
      const { proxyElement } = view;
      this._unsubscribes = [
        ...this._unsubscribes,
        view.hub.on(this._field, () => this._refresh()),
        proxyElement.on('click', (e) => this._handleClick(e)),
      ];
      // TODO: it shall not carry the responsibility of setting default value
      this._defaultValue ? this._select(this._defaultValue, { silent: true }) : this._clear({ silent: true });
    }

    _preprocess(states, controls) {
      if (states.rendered) {
        controls.skip(); // only render once
      }
      return super._preprocess(states, controls);
    }

    _handleClick({ target }) {
      const element = findInAncestors(target, (element) => element.hasAttribute('data-value') ? element : undefined);
      if (!element) {
        return;
      }
      let { unselected, value: oldValue } = this._view.hub.states[this._field];
      unselected = unselected || oldValue === undefined;
      const value = element.getAttribute('data-value');
      if (unselected || oldValue === undefined || oldValue !== value) {
        this._select(value);
      } else {
        this._clear();
      }
    }

    _refresh() {
      this._state = this._view.hub.states[this._field];
      requestAnimationFrame(() => this._syncValueAttribute());
    }

    _syncValueAttribute() {
      if (!this._state || !this._view) {
        return;
      }
      const { element } = this._view;
      const root = element && element.children[0];
      if (!root) {
        return;
      }
      let { unselected, value } = this._state;
      if (unselected) {
        root.removeAttribute('data-selected');
      } else {
        root.setAttribute('data-selected', value);
      }
      this._state = undefined;
    }

    _select(value, options) {
      this._submit({ value }, options);
    }

    _clear(options) {
      this._submit({ unselected: true }, options);
    }

    async _submit(state, options) {
      this._view.hub.update(this._field, state, options);
    }

  }

  const TYPE$6 = 'feedback';
  const DEFAULT_CLASSNAME$6 = 'miso-feedback';

  const OPTIONS = [ 'helpful', 'unhelpful' ];

  function options$2(layout) {
    const { templates } = layout;
    return OPTIONS.map(value => templates.option(layout, { value })).join('');
  }

  function content(layout, { value }) {
    const { className, templates, options = {} } = layout;
    return `
${options.icon !== false ? `<i class="${className}__icon">${templates.icon(layout, value)}</i>` : ''}
${options.text !== false ? `<span class="${className}__text">${templates.text(layout, value)}</span>` : ''}
`;
  }

  function icon(layout, value) {
    switch (value) {
      case 'helpful':
      case 'unhelpful':
        return THUMB;
      default:
        return '';
    }
  }

  function text$2(layout, value) {
    switch (value) {
      case 'helpful':
        return 'Helpful';
      case 'unhelpful':
        return 'Not helpful';
      default:
        return '';
    }
  }

  const DEFAULT_TEMPLATES$5 = Object.freeze({
    options: options$2,
    content,
    icon,
    text: text$2,
  });

  class FeedbackLayout extends RadioLayout {

    static get type() {
      return TYPE$6;
    }

    static get defaultTemplates() {
      return DEFAULT_TEMPLATES$5;
    }

    static get defaultClassName() {
      return DEFAULT_CLASSNAME$6;
    }

    constructor({ className = DEFAULT_CLASSNAME$6, templates, ...options } = {}) {
      super({
        className,
        templates: { ...DEFAULT_TEMPLATES$5, ...templates },
        field: feedback(),
        ...options,
      });
      if (options.text === false && options.icon === false) {
        throw new Error('At least one of options.text or options.icon must be enabled');
      }
    }

  }

  const TYPE$5 = 'text';
  const DEFAULT_CLASSNAME$5 = 'miso-text';

  function root$6(layout, { value }) {
    const { className, role, options: { raw = false, tag } } = layout;
    const roleAttr = role ? `data-role="${role}"` : '';
    const content = value !== undefined ? escapeHtml(getFormatFunction(layout)(value)) : '';
    return raw ? content : `<${tag} class="${className}" ${roleAttr}>${content}</${tag}>`;
  }

  function getFormatFunction(layout) {
    let { format } = layout.options;
    const { formatDate, formatNumber } = layout.templates.helpers;
    if (!format) {
      return v => `${v}`;
    }
    switch (typeof format) {
      case 'function':
        return format;
      case 'string':
        format = [format];
        break;
    }
    let [type, args] = format;
    switch (type) {
      case 'date':
        return v => formatDate(v, args);
      case 'number':
        return v => formatNumber(v, args);
      default:
        return v => `${v}`;
    }
  }

  const DEFAULT_TEMPLATES$4 = Object.freeze({
    root: root$6,
  });

  class TextLayout extends TemplateBasedLayout {

    static get type() {
      return TYPE$5;
    }

    static get defaultTemplates() {
      return DEFAULT_TEMPLATES$4;
    }

    static get defaultClassName() {
      return DEFAULT_CLASSNAME$5;
    }

    constructor({
      className = DEFAULT_CLASSNAME$5,
      templates,
      tag = 'p',
      ...options
    } = {}) {
      super({
        className,
        templates: { ...DEFAULT_TEMPLATES$4, ...templates },
        tag,
        ...options,
      });
    }

  }

  class ProgressiveLayout extends RafLayout {

    constructor(options) {
      super(options);
    }

    _takePending() {
      return this._pending;
    }

    _applyRender(timestamp, extraControls = {}) {
      const loop = capture(false);
      super._applyRender(timestamp, { ...extraControls, loop: loop.t });
      if (loop.value) {
        this._requestRaf();
      }
    }

  }

  class PlaintextRenderer {

    clear(element) {
      element.innerText = '';
      return { cursor: 0, done: false };
    }

    update(element, { value: prevValue, cursor: prevCursor }, { value, cursor, done: dataDone }) {
      const length = value.length;
      cursor = Math.min(cursor, length);
      const viewDone = !!dataDone && (cursor === length);

      // in case text already rendered were modified
      const prevRenderedText = prevValue.substring(0, prevCursor);
      const overwrite = !value.startsWith(prevRenderedText);

      // when done, also re-set the entire text so we don't have fragmental text nodes
      if (viewDone || overwrite) {
        element.innerText = value;
      } else {
        element.insertAdjacentText('beforeend', value.substring(prevCursor, cursor));
      }
      viewDone && element.classList.add('done');

      return { cursor, done: viewDone };
    }

  }

  function containerElement(layout, element, { status }) {
    if (!element) {
      return undefined;
    }
    if (element.children.length === 0) {
      element.innerHTML = containerHtml(layout);
    }
    const container = element.children[0];
    container.setAttribute('data-status', status || STATUS.INITIAL);
    return container;
  }

  function containerHtml(layout) {
    let { className, role, options: { tag, format, builtInStyles = true } } = layout;
    if (tag === 'auto') {
      tag = format === 'markdown' ? 'div' : 'p';
    }
    const roleAttr = role ? `data-role="${role}"` : '';
    const classNames = [className, cursorClassName(className)];
    if (builtInStyles && format === 'markdown') {
      classNames.push('miso-markdown');
    }
    return `<${tag} class="${classNames.join(' ')}" ${roleAttr} data-format="${format}"></${tag}>`;
  }

  function cursorClassName(className) {
    return `${className}__cursor`;
  }

  function fromSameSession(a, b) {
    return a && b && a.session && b.session && a.session.uuid === b.session.uuid;
  }

  function normalizeOnDebug(fn) {
    if (fn === true) {
      return defaultOnDebug();
    }
    if (!fn) {
      return undefined;
    }
    if (typeof fn === 'function') {
      return fn;
    }
    throw new Error('onDebug must be a function or a boolean');
  }

  function defaultOnDebug(start = performance.now()) {
    return function({ summary, timestamp, elapsed, ref, operation, conflict }) {
      MisoClient.debug('<progressive-markdown>', `[${formatTimeInSeconds(timestamp - start)}](${formatTimeInMilliseconds(elapsed[0])}, ${formatTimeInMilliseconds(elapsed[1])})`, summary, `${operation}`, ref, conflict);
    };
  }

  function formatTimeInSeconds(t) {
    return `${Math.floor(t) / 1000}s`;
  }

  function formatTimeInMilliseconds(t) {
    return `${Math.floor(t * 100) / 100}ms`;
  }

  const TYPE$4 = 'typewriter';
  const DEFAULT_CLASSNAME$4 = 'miso-typewriter';

  class TypewriterLayout extends ProgressiveLayout {

    static get type() {
      return TYPE$4;
    }

    static get defaultClassName() {
      return DEFAULT_CLASSNAME$4;
    }

    constructor({
      className = DEFAULT_CLASSNAME$4,
      tag = 'auto',
      format = 'markdown',
      tooltip = false,
      speed,
      acceleration,
      nextCursorFn,
      ...options
    } = {}) {
      super({
        tag,
        format,
        tooltip,
        ...options,
      });
      defineValues(this, {
        className,
      });
      this._prevState = undefined;
      this._getNextCursor = typeof nextCursorFn === 'function' ? nextCursorFn : pacer({ speed, acceleration });
      this._readiness = new Resolution();

      // kick off sooner
      if (format === 'markdown') {
        TypewriterLayout.MisoClient.plugins.install('std:ui-markdown');
      }
    }

    initialize() {
      this._setup();
    }

    // setup //
    async _setup() {
      try {
        switch (this.options.format) {
          case 'plaintext':
            await this._setupForPlaintext();
            break;
          default:
            await this._setupForMarkdown();
        }
        this._readiness.resolve();
      } catch (e) {
        this._readiness.reject(e);
      }
    }

    async _setupForMarkdown() {
      const context = await this._view._views._extensions.require('markdown');
      if (!this._view) {
        return; // destroyed
      }
      const cursorClass = cursorClassName(this.className);
      const { onDebug, onCitationLink, variant } = this.options;
      // TODO: options
      this._renderer = context.createRenderer({
        cursorClass,
        getSource: index => this._getSource(index),
        onCitationLink,
        onDebug: normalizeOnDebug(onDebug),
        variant,
      });
      // capture citation link click if necessary
      this._unsubscribes.push(this._view.proxyElement.on('click', (e) => this._onClick(e)));
    }

    _getSource(index) {
      const { data = {} } = this._view._data;
      const { sources = [] } = data;
      return sources[index];
    }

    async _setupForPlaintext() {
      this._renderer = new PlaintextRenderer();
    }

    async _ready() {
      return this._readiness.promise;
    }

    // render //
    async render(...args) {
      await this._ready();
      await super.render(...args);
    }

    _preprocess({ state }) {
      const prev = this._prevState;
      const { value = '', meta, session, status, ongoing } = state;
      const stage = meta && meta.answer_stage || 'result';
      const sameSession = fromSameSession(prev, state);
      const sameStreak = sameSession && (stage === prev.stage);
      const streak = !prev ? 0 : sameStreak ? prev.streak : prev.streak + 1;

      const doneAt = (sameSession && prev && prev.doneAt) || (status === STATUS.READY && !ongoing ? Date.now() : undefined);
      const done = doneAt !== undefined;

      return this._prevState = Object.freeze(trimObj({
        session,
        status,
        value,
        stage,
        streak,
        doneAt,
        done,
      }));
    }

    _render(element, { state, rendered }, { notifyUpdate, writeToState, loop }) {
      const container = containerElement(this, element, state);
      // TODO: distinguish between first render and element replacement
      let result;
      const newStreak = !rendered || state.streak !== rendered.streak;
      if (newStreak) {
        // new typing streak
        result = this._renderer.clear(container, rendered);
      } else {
        const cursor = this._getNextCursor(rendered.cursor, state.doneAt, rendered.timestamp, state.timestamp);
        result = this._renderer.update(container, rendered, { ...state, cursor });
      }
      writeToState(result);

      const ongoing = state.status === STATUS.READY && !result.done;
      // silence on consecutive ongoing renders
      const silent = ongoing && (!rendered || rendered.status === STATUS.READY) && !newStreak;
      notifyUpdate({ ongoing }, { silent });

      ongoing && loop();
    }

    // event //
    _onClick(event) {
      const { target } = event;
      const citationLinkElement = target.closest(`[data-role="citation-link"]`);
      // citation link click
      if (citationLinkElement) {
        const index = parseInt(citationLinkElement.dataset.index);
        if (!Number.isNaN(index)) {
          this._view._events.emit('citation-click', { event, index });
        }
        return;
      }
      // generic link click
      const anchorElement = target.closest('a');
      if (anchorElement) {
        if (!event.defaultPrevented) {
          // TODO: classList, attributes
          const { href, innerText, className } = anchorElement;
          if (href) {
            this._view._events.emit('link-click', trimObj({
              event,
              url: href,
              text: innerText ? innerText.trim() : '',
              className: className || '',
              attributes: dumpElementAttributes(anchorElement),
            }));
          }
        }
        return;
      }
    }
  }

  function dumpElementAttributes(element) {
    const { attributes } = element;
    const attrs = {};
    for (const { name, value } of attributes) {
      if (name.startsWith('data-')) {
        attrs[name] = value;
      }
    }
    try {
      return JSON.stringify(attrs);
    } catch (e) {
      return '{}';
    }
  }

  const TYPE$3 = 'affiliation';
  const DEFAULT_CLASSNAME$3 = 'miso-affiliation';

  function root$5(layout, state) {
    const { className, role, templates, options } = layout;
    const { status } = state;
    const roleAttr = role ? ` data-role="${role}"` : '';
    const data = state.value || {};
    const channelAttr = data.channel ? ` data-channel="${data.channel}"` : '';
    const items = layout._getItems(state);
    const itemCount = items ? items.length : undefined;
    const itemCountAttr = itemCount !== undefined ? ` data-item-count="${itemCount}"` : '';
    const itemTypeAttr = options.itemType ? ` data-item-type="${options.itemType}"` : '';
    return `<div class="${className} ${status}"${roleAttr}${channelAttr}${itemTypeAttr}${itemCountAttr}>${status === STATUS.READY ? templates[status](layout, state) : ''}</div>`;
  }

  function ready(layout, state) {
    const { templates } = layout;
    const items = layout._getItems(state);

    if (items && items.length > 0) {
      return templates.controlContainer(layout, state, 'previous') + templates.body(layout, state) + templates.controlContainer(layout, state, 'next');
    } else {
      return templates.empty(layout, state);
    }
  }

  function controlContainer(layout, state, direction) {
    const { className, templates } = layout;
    return `<div class="${className}__control-${direction}-container">${templates.control(layout, state, direction)}</div>`;
  }

  function control(layout, state, direction) {
    const { className, templates } = layout;
    return `<div class="${className}__control-${direction}" data-role="${direction}">${templates.controlIcon(layout, state, direction)}</div>`;
  }

  function controlIcon(layout, state, direction) {
    return TRIANGLE;
  }

  function body(layout, state) {
    const { className, templates } = layout;
    const items = layout._getItems(state);
    return `<div class="${className}__body">${templates.list(layout, state, items)}</div>`;
  }

  function item$1(layout, state, value, index) {
    const { className, templates, options } = layout;
    const { itemType } = options;
    const header = templates.itemHeader(layout, state, value, { index });
    const body = templates[itemType](layout, state, value, { index });
    return `<li class="${className}__item"><div class="${className}__item-inner">${header}${body}</div></li>`;
  }

  function itemHeader(layout, state, value, meta) {
    const { className, templates } = layout;
    let { itemHeaderLeftText, itemHeaderRightText } = templates;
    itemHeaderLeftText = helpers$2.asFunction(itemHeaderLeftText)(layout, state, value, meta);
    itemHeaderRightText = helpers$2.asFunction(itemHeaderRightText)(layout, state, value, meta);
    return `<div class="${className}__item-header">
  <div class="${className}__item-header-left">${itemHeaderLeftText}</div>
  <div class="${className}__item-header-right">${itemHeaderRightText}</div>
</div>`;
  }

  function itemHeaderRightText(layout, state, value, meta) {
    const { className, templates } = layout;
    const logoText = helpers$2.asFunction(templates.logoText)(layout, state, value, meta) || '';
    const logoImg = helpers$2.asFunction(templates.logoImg)(layout, state, value, meta);
    return logoImg ? `<span class="${className}__item-header-logo-text">${logoText}</span>${logoImg}` : '';
  }

  function logoImg(layout, state, value, meta) {
    const { className, templates } = layout;
    const logoUrl = helpers$2.asFunction(templates.logoUrl)(layout, state, value, meta);
    if (!logoUrl) {
      return '';
    }
    const logoAltText = helpers$2.asFunction(templates.logoAltText)(layout, state, value, meta);
    const logoAltTextAttr = logoAltText ? ` alt="${logoAltText}"` : '';
    return `<img class="${className}__item-header-logo" src="${logoUrl}"${logoAltTextAttr}>`;
  }

  const DEFAULT_TEMPLATES$3 = Object.freeze({
    root: root$5,
    [STATUS.READY]: ready,
    controlContainer,
    control,
    controlIcon,
    body,
    item: item$1,
    itemHeader,
    affiliation,
    ctaText: 'View deal',
    itemHeaderLeftText: `Today's best deals`,
    itemHeaderRightText,
    logoImg,
    logoText: 'Selected by',
  });

  const INHERITED_DEFAULT_TEMPLATES = Object.freeze({
    ...CollectionLayout.defaultTemplates,
    ...DEFAULT_TEMPLATES$3,
  });

  /*
  function normalizeAutoplayOptions(options) {
    if (options === true) {
      options = { interval: 10000 };
    } else if (typeof options === 'number') {
      if (options <= 0) {
        options = false;
      } else {
        options = { interval: Math.max(options, 500) };
      }
    }
    return options;
  }

  function autoplayOptionsEquals(a, b) {
    if (a === b) {
      return true;
    }
    if (!a || !b) {
      return false;
    }
    return a.interval === b.interval;
  }
  */

  class AffiliationLayout extends CollectionLayout {

    static get type() {
      return TYPE$3;
    }

    static get defaultTemplates() {
      return INHERITED_DEFAULT_TEMPLATES;
    }

    static get defaultClassName() {
      return DEFAULT_CLASSNAME$3;
    }

    constructor({ className = DEFAULT_CLASSNAME$3, templates, autoplay, ...options } = {}) {
      super({ className, itemType: 'affiliation', templates: { ...DEFAULT_TEMPLATES$3, ...templates }, ...options });
      this._itemCount = undefined;
      this._itemIndex = 0;
      this._displayedCount = undefined;
      this._displayedIndex = undefined;
      this._viewable = undefined;

      // TODO: extract this
      /*
      this._autoplay = {};
      this.autoplay(autoplay);
      */
    }

    initialize(view) {
      super.initialize(view);
      const { viewable: options } = this._view.tracker.options || {};
      this._viewable = new CarouselItemViewabilityObserver(this._onViewable.bind(this), options);
    }

    /*
    autoplay(options = false) {
      options = normalizeAutoplayOptions(options);
      if (autoplayOptionsEquals(options, this._autoplay.options)) {
        return;
      }
      if (this._autoplay.options) {
        clearInterval(this._autoplay.intervalId);
      }
      this._autoplay = { options };
      // TODO: use slower transition speed for autoplay
      // TODO: pause on hover
      // TODO: cooldown after manual interaction
      if (options) {
        this._autoplay.intervalId = setInterval(() => this.next(), options.interval);
      }
    }
    */

    get itemIndex() {
      return this._itemIndex;
    }

    set itemIndex(index) {
      if (this._itemCount === undefined) {
        return;
      }
      if (index < 0) {
        index = this._itemCount - 1;
      } else if (index >= this._itemCount) {
        index = 0;
      }
      this._itemIndex = index;
      requestAnimationFrame(() => this._syncItemIndex());
    }

    next() {
      if (this._itemCount === undefined) {
        return;
      }
      this.itemIndex++;
    }

    previous() {
      if (this._itemCount === undefined) {
        return;
      }
      this.itemIndex--;
    }

    _getItems(state) {
      const { products } = state.value || {};
      return products;
    }

    _render(element, states, controls) {
      super._render(element, states, controls);
      // sync again for incremental item rendering
      this._syncItemCount(states);
      this._syncItemIndex();
    }

    _syncElement(element) {
      const oldElement = this._element;
      super._syncElement(element);
      this._syncViewableElement(oldElement, element);
    }

    _syncViewableElement(oldElement, newElement) {
      if (oldElement === newElement) {
        return;
      }
      oldElement && this._viewable.unobserve(oldElement);
      newElement && this._viewable.observe(newElement);
    }

    _syncItemCount({ state } = {}) {
      const items = this._getItems(state);
      const itemCount = this._itemCount = items ? items.length : undefined;
      if (itemCount === this._displayedCount) {
        return;
      }
      let { element } = this._view;
      element = element.firstElementChild;
      if (!element) {
        return;
      }
      setOrRemoveAttribute(element, 'data-item-count', itemCount);
      this._displayedCount = itemCount;
    }

    _syncItemIndex() {
      const index = this._itemIndex;
      if (index === this._displayedIndex) {
        return;
      }
      const { element } = this._view;
      const listElement = element && this._getListElement(element);
      if (!listElement) {
        return;
      }
      this._displayedIndex = index;
      listElement.style.left = `${-index * 100}%`;
      this._viewable.display(index);
      this._view._events.emit('display', { index });
    }

    _onViewable(index) {
      const item = this._getRenderedItemData(index);
      if (!item) {
        return;
      }
      this._view.tracker.viewable([item]);
    }

    _getRenderedItemData(index) {
      const { value } = this._rendered.get(this._element) || {};
      if (!value) {
        return undefined;
      }
      const { products = [] } = value;
      return products[index];
    }

    _trackViewables() {} // omit default behavior for we want to track by other means

    _onClick(event) {
      const element = event.target;
      if (element.closest(`[data-role="previous"]`)) {
        this.previous();
        return;
      }
      if (element.closest(`[data-role="next"]`)) {
        this.next();
        return;
      }
      super._onClick(event);
    }

  }

  const TYPE$2 = 'facets';
  const DEFAULT_CLASSNAME$2 = 'miso-facets';
  const DEDAULT_FACET_CLASSNAME = 'miso-facet';
  const CUSTOM_ATTRIBUTES_PREFIX = 'custom_attributes.';

  function root$4(layout, state) {
    const { className, role, templates } = layout;
    const roleAttr = role ? `data-role="${role}"` : '';
    return `<div class="${className}" ${roleAttr}>${templates.facets(layout, state)}</div>`;
  }

  function facets(layout, state) {
    const { templates } = layout;
    const { facet_fields = {} } = state.value || {};
    return Object.keys(facet_fields).map(field => templates.facet(layout, { field, entries: facet_fields[field] }, state));
  }

  function facet(layout, facet, state) {
    const { facetClassName = DEDAULT_FACET_CLASSNAME, templates } = layout;
    const { field } = facet;
    return `<div class="${facetClassName}" data-role="facet" data-field="${escapeHtml(field)}">${templates.header(layout, facet, state)}${templates.options(layout, facet, state)}</div>`;
  }

  function header(layout, facet, state) {
    const { facetClassName = DEDAULT_FACET_CLASSNAME, templates } = layout;
    return `<div class="${facetClassName}__header">${templates.title(layout, facet, state)}</div>`;
  }

  function title(layout, { field }) {
    if (field.startsWith(CUSTOM_ATTRIBUTES_PREFIX)) {
      field = field.substring(CUSTOM_ATTRIBUTES_PREFIX.length);
    }
    // TODO: to words
    return escapeHtml(field);
  }

  function options$1(layout, { field, entries }, state) {
    const { facetClassName = DEDAULT_FACET_CLASSNAME, templates } = layout;
    return `<ul class="${facetClassName}__options" data-role="options">${entries.map(([value, count]) => templates.option(layout, { field, value, count }, state)).join('')}</ul>`;
  }

  function option$1(layout, entry, state) {
    const { facetClassName = DEDAULT_FACET_CLASSNAME, templates } = layout;
    return `
<li class="${facetClassName}__option" data-role="option" tabindex="0">
  <span class="${facetClassName}__value">${templates.value(layout, entry, state)}</span>
  <span class="${facetClassName}__count">${templates.count(layout, entry, state)}</span>
</li>`;
  }


  function value(layout, { value }, state) {
    return escapeHtml(value);
  }

  function count(layout, { count }, state) {
    return layout.templates.helpers.formatNumber(count);
  }

  const DEFAULT_TEMPLATES$2 = Object.freeze({
    root: root$4,
    facets,
    facet,
    header,
    title,
    options: options$1,
    option: option$1,
    value,
    count,
  });

  function getItemKey(field, value) {
    return `${field}:::${value}`;
  }

  function getSelectedValues(facets) {
    const selections = {};
    for (const field in facets) {
      selections[field] = new Set(facets[field]);
    }
    return selections;
  }

  class FacetsLayout extends TemplateBasedLayout {

    static get type() {
      return TYPE$2;
    }

    static get defaultTemplates() {
      return DEFAULT_TEMPLATES$2;
    }

    static get defaultClassName() {
      return DEFAULT_CLASSNAME$2;
    }

    constructor({ className = DEFAULT_CLASSNAME$2, templates, ...options } = {}) {
      super({
        className,
        templates: { ...DEFAULT_TEMPLATES$2, ...templates },
        ...options,
      });
      this._bindings = new Bindings();
    }

    initialize(view) {
      const { proxyElement, filters } = view;
      this._unsubscribes = [
        ...this._unsubscribes,
        proxyElement.on('click', (e) => this._handleClick(e)),
        filters.on('update', (e) => this._updateSelections(e)),
        filters.on('reset', () => this._syncSelections()),
      ];
    }

    _render(element, data, controls) {
      super._render(element, data, controls);
    }

    _afterRender(element, state) {
      this._syncBindings(element, state);
      this._syncSelections();
    }

    _unrender() {
      this._clearBindings();
    }

    _syncSelections() {
      const selectedValues = getSelectedValues(this._view.hub.states[filters()].facets);
      for (const { value: { field, value }, element } of this._bindings.entries) {
        this._setSelected(element, selectedValues[field] && selectedValues[field].has(value));
      }
    }

    _updateSelections({ updates }) {
      const selectedValues = getSelectedValues(updates.facets);
      for (const { value: { field, value }, element } of this._bindings.entries) {
        if (!selectedValues[field]) {
          continue;
        }
        this._setSelected(element, selectedValues[field].has(value));
      }
    }

    _setSelected(element, selected) {
      if (!element) {
        return;
      }
      if (selected) {
        element.classList.add('selected');
      } else {
        element.classList.remove('selected');
      }
    }

    _syncBindings(element, state) {
      if (!element || !state.value) {
        return;
      }
      const items = this._getItems(state);
      const keys = [];
      const values = [];
      const elements = [];
      for (const facetElement of this._getFacetElements(element)) {
        const field = facetElement.getAttribute('data-field');
        const _values = items[field];
        if (!_values) {
          continue;
        }
        const itemElements = this._getItemElements(facetElement);
        for (let i = 0; i < itemElements.length; i++) {
          const itemElement = itemElements[i];
          const value = _values[i];
          if (!value) {
            break;
          }
          keys.push(getItemKey(field, value));
          values.push({ field, value });
          elements.push(itemElement);
        }
      }
      this._bindings.update(keys, values, elements);
    }

    _clearBindings() {
      this._bindings.clear();
    }

    _getItems({ value } = {}) {
      const { facet_fields = {} } = value || {};
      const items = {};
      for (const field in facet_fields) {
        // the key needs to be matched against data-field attribute
        items[escapeHtml(field)] = facet_fields[field].map(([value]) => value);
      }
      return items;
    }

    _getFacetElements(element) {
      return Array.from(element.querySelectorAll(`[data-role="facet"]`));
    }

    _getFacetElement(element, field) {
      return element.querySelector(`[data-role="facet"][data-field="${field}"]`);
    }

    _getItemElements(element) {
      return Array.from(element.querySelectorAll(`[data-role="option"]`));
    }

    _handleClick(event) {
      // only left click
      if (event.button !== 0) {
        return;
      }
      const element = event.target.closest(`[data-role="option"]`);
      if (!element) {
        return;
      }
      const binding = this._bindings.get(element);
      const option = binding && binding.value;
      if (!option) {
        return;
      }
      const { field, value } = option;
      this._view.filters.facets.toggle(field, value);
      this._view.filters.apply(); // TODO: support autoApply = false
    }

    destroy() {
      this._bindings.clear();
      super.destroy();
    }

  }

  const TYPE$1 = 'select';
  const DEFAULT_CLASSNAME$1 = 'miso-select';

  function root$3(layout, state) {
    const { className, role, templates } = layout;
    const roleAttr = role ? `data-role="${role}"` : '';
    const values = layout._getItems(state);
    const selected = values.find(value => value.selected) || values[0];
    return `
<div class="${className}" ${roleAttr}>
  ${templates.button(layout, selected)}
  ${templates.options(layout, state)}
</div>`;
  }

  function button(layout, value) {
    const { className, templates } = layout;
    return `<button class="${className}__button" data-role="button" tabindex="0">${templates.text(layout, value)}</button>`;
  }

  function options(layout, state) {
    const { className, templates } = layout;
    const values = layout._getItems(state);
    return `<ul class="${className}__options">${values.map((value, index) => templates.option(layout, value, { index })).join('')}</ul>`;
  }

  function option(layout, value) {
    const { className, templates } = layout;
    const selectedClass = value.selected ? 'selected' : '';
    return `<li class="${className}__option ${selectedClass}" data-role="option" tabindex="0">${templates.text(layout, value)}</li>`;
  }

  function text$1(layout, value) {
    return escapeHtml(value && value.text && kebabOrSnakeToHuman(value.text) || value || '');
  }

  const DEFAULT_TEMPLATES$1 = Object.freeze({
    root: root$3,
    button,
    options,
    option,
    text: text$1,
  });

  class SelectLayout extends TemplateBasedLayout {

    static get type() {
      return TYPE$1;
    }

    static get defaultTemplates() {
      return DEFAULT_TEMPLATES$1;
    }

    static get defaultClassName() {
      return DEFAULT_CLASSNAME$1;
    }

    constructor({ className = DEFAULT_CLASSNAME$1, templates, ...options } = {}) {
      super({
        className,
        templates: { ...DEFAULT_TEMPLATES$1, ...templates },
        ...options,
      });
      this._initTrackable();
    }

    initialize(view) {
      const { proxyElement } = view;
      this._unsubscribes = [
        ...this._unsubscribes,
        proxyElement.on('click', (e) => this._handleClick(e)),
      ];
    }

    _afterRender(element, state) {
      this._syncBindings(element, state);

    }

    _unrender() {
      this._clearBindings();
    }

    _getItems(state) {
      return state.value || [];
    }

    _getOptionsElement(element) {
      return element.querySelector(`[data-role="options"]`);
    }

    _getItemElements(element) {
      return element ? Array.from(element.querySelectorAll(`[data-role="option"]`)) : [];
    }

    _handleClick(event) {
      if (!this._element) {
        return;
      }
      for (let element = event.target; element && element !== this._element; element = element.parentElement) {
        const { role } = element.dataset;
        switch (role) {
          case 'button':
            this._toggle();
            break;
          case 'option':
            const binding = this._bindings.get(element);
            this._select(binding && binding.value);
            break;
        }
      }
    }

    _toggle() {
      if (!this._element) {
        return;
      }
      const child = this._element.children[0];
      child && child.classList.toggle('open');
    }

    async _select(value) {
      if (!value) {
        return;
      }
      // TODO: reflect selection right away
      this._view._events.emit('select', { value });
    }

    destroy() {
      this._destroyTrackable();
      super.destroy();
    }

  }

  makeTrackable(SelectLayout.prototype);

  const TYPE = 'more-button';
  const DEFAULT_CLASSNAME = 'miso-more-button';

  function root$2(layout, state) {
    const { className, role, templates } = layout;
    const roleAttr = role ? ` data-role="${role}"` : '';
    const disabledAttr = state.status !== STATUS.READY ? ' disabled' : '';
    return `
<div class="${className}"${roleAttr}${disabledAttr}>
  ${templates.text(layout)}
</div>
`;
  }

  const DEFAULT_TEMPLATES = Object.freeze({
    root: root$2,
    text,
  });

  function text(layout) {
    return 'More';
  }

  class MoreButtonLayout extends TemplateBasedLayout {

    static get type() {
      return TYPE;
    }

    static get defaultTemplates() {
      return DEFAULT_TEMPLATES;
    }

    static get defaultClassName() {
      return DEFAULT_CLASSNAME;
    }

    constructor({ className = DEFAULT_CLASSNAME, templates, ...options } = {}) {
      super({
        className,
        templates: { ...DEFAULT_TEMPLATES, ...templates },
        ...options,
      });
    }

    initialize(view) {
      this._unsubscribes = [
        ...this._unsubscribes,
        view.proxyElement.on('click', (e) => this._handleClick(e)),
      ];
    }

    _handleClick(event) {
      // only left click
      if (event.button !== 0) {
        return;
      }
      const button = event.target.closest('[data-role="more"]');
      if (!button || button.disabled) {
        return;
      }
      this._view.hub.trigger(more());
    }

  }

  var layouts = /*#__PURE__*/Object.freeze({
    __proto__: null,
    AffiliationLayout: AffiliationLayout,
    BannerLayout: BannerLayout,
    CardsLayout: CardsLayout,
    CarouselLayout: CarouselLayout,
    CollectionLayout: CollectionLayout,
    ContainerLayout: ContainerLayout,
    ErrorLayout: ErrorLayout,
    FacetsLayout: FacetsLayout,
    FeedbackLayout: FeedbackLayout,
    GalleryLayout: GalleryLayout,
    ListLayout: ListLayout,
    MoreButtonLayout: MoreButtonLayout,
    OptionListLayout: OptionListLayout,
    SearchBoxLayout: SearchBoxLayout,
    SelectLayout: SelectLayout,
    TemplateBasedLayout: TemplateBasedLayout,
    TextLayout: TextLayout,
    TypewriterLayout: TypewriterLayout
  });

  // role mappings //
  function mappingSortData(_, { hub, workflowOptions = {} } = {}) {
    const { sort: { options = [] } = {} } = workflowOptions.filters || {};
    if (!options.length) {
      return [];
    }
    const { sort } = hub.states[filters()] || {};
    const selectedField = (sort && sort.field) || findDefaultSortOption(options).field;
    if (!selectedField) {
      return options;
    }
    // mark selected
    return options.map(option => {
      return {
        ...option,
        selected: option.field === selectedField,
      };
    });
  }

  function findDefaultSortOption(options) {
    for (const option of options) {
      if (option.default) {
        return option;
      }
    }
    return options[0];
  }

  // data //
  function getRevision(data) {
    return data && data.value && data.value.revision;
  }

  function writeDataStatus(data) {
    const status = getStatus(data);
    const ongoing = status === STATUS.READY ? data.ongoing : undefined;
    return trimObj({ status, ongoing, ...data }); // let orinigal data override status and ongoing
  }

  function getStatus(data) {
    if (!data) {
      return STATUS.INITIAL;
    }
    const { request, error, value } = data;
    return error ? STATUS.ERRONEOUS : value ? STATUS.READY : request ? STATUS.LOADING : STATUS.INITIAL;
  }

  function writeMisoIdToMeta(data) {
    const { value } = data;
    if (!value) {
      return data;
    }
    const { miso_id } = value;
    if (!miso_id) {
      return data;
    }
    return {
      ...data,
      meta: {
        ...data.meta,
        miso_id,
      },
    };
  }

  function writeMisoIdToSession(data) {
    const { session, value } = data;
    if (!session || !value) {
      return;
    }
    const { miso_id } = value;
    if (!miso_id) {
      return;
    }
    session.meta.miso_id = miso_id;
  }

  function writeMisoIdFromSession(data) {
    const { session, value } = data;
    if (!session || !value) {
      return data;
    }
    const { meta: { miso_id } = {} } = session;
    if (!miso_id) {
      return data;
    }
    return {
      ...data,
      meta: {
        ...data.meta,
        miso_id,
      },
    };
  }

  function writeKeywordsToData(data) {
    const { request, value } = data;
    // we still want the value in loading status
    if (!request) {
      return data;
    }
    const { payload } = request || {};
    const { q: keywords } = payload || {};
    if (!keywords) {
      return data;
    }
    return {
      ...data,
      value: {
        ...value,
        keywords,
      },
    };
  }

  function writeAnswerStageToMeta(data) {
    const { value } = data;
    if (!value) {
      return data;
    }
    const { answer_stage } = value;
    if (!answer_stage) {
      return data;
    }
    // 1. put answer_stage to meta
    // 2. mark ongoing flag
    return {
      ...data,
      ongoing: !value.finished,
      meta: {
        ...data.meta,
        answer_stage,
      },
    };
  }

  function retainFacetCountsInData(data, currentFacetCounts) {
    if (!currentFacetCounts) {
      return data;
    }
    const { status, value } = data;
    switch (status) {
      case STATUS.INITIAL:
      case STATUS.LOADING:
        break;
      default:
        return data;
    }
    if (value && value.facet_counts) {
      return data;
    }
    return {
      ...data,
      value: {
        ...value,
        facet_counts: currentFacetCounts,
      },
    };
  }

  function concatItemsFromMoreResponse(oldData, newData, { role = ROLE.PRODUCTS } = {}) {
    if (!newData.value) {
      return oldData;
    }
    const { [role]: oldProducts = [], facet_counts, total } = oldData.value;
    const { [role]: newProducts = [] } = newData.value;
    // keep old exhaustion flag, just in case
    // TODO

    // use old values of facet_counts and total, for they are affected by product_id exclusion
    return {
      ...newData,
      value: {
        ...newData.value,
        facet_counts,
        total,
        [role]: [...oldProducts, ...newProducts],
      },
    }
  }

  function writeExhaustionToData(data, { role = ROLE.PRODUCTS } = {}) {
    const { status, request, value } = data;
    // keep track of the exhaustion state
    if (status !== STATUS.READY || !request || !value) {
      return data;
    }
    const { [role]: items } = value;
    if (!items) {
      return data;
    }
    const { rows } = request.payload;
    const { length } = items;
    const exhausted = length < rows;
    if (!exhausted) {
      return data;
    }
    return {
      ...data,
      meta: {
        ...data.meta,
        exhausted: true,
      },
    };
  }

  // interactions //
  function buildBaseInteraction(args) {
    const { role, type, items } = args;
    const payload = {
      type: type === 'viewable' ? 'viewable_impression' : type,
      context: {
        custom_context: trimObj({
          property: role,
        }),
      },
    };

    if (isPerformanceEventType(type)) {
      if (isProductRole(role)) {
        payload.product_ids = (items || []).map(v => typeof v === 'string' ? v : v.product_id).filter(v => v);
      } else {
        payload.product_ids = [];
        payload.context.custom_context.items = (items || []).map(v => v.text || v.id || v);
      }
    }

    switch (type) {
      case EVENT_TYPE.SUBMIT:
        payload.context.custom_context.value = args.value;
        break;
      case EVENT_TYPE.FEEDBACK:
        payload.context.custom_context.value = payload.value = args.value;
        payload.context.custom_context.result_type = payload.result_type = args.result_type;
        break;
    }

    return trimObj(payload);
  }

  function writeAffiliationInfoToInteraction(payload, args) {
    if (args.role !== ROLE.AFFILIATION) {
      return payload;
    }
    const { items } = args;
    const channel = (items[0] && items[0].channel) || undefined;
    const positions = items.map(v => v.position);
    return mergeInteraction(payload, {
      context: {
        custom_context: {
          channel,
          positions,
        },
      },
    });
  }

  function writeEventTargetToInteraction(payload, { event_target } = {}) {
    if (!event_target) {
      return payload;
    }
    return mergeInteraction(payload, {
      context: {
        custom_context: {
          event_target,
        },
      },
    });
  }

  function mergeInteraction(base = {}, patch = {}) {
    return trimObj({
      ...base,
      ...patch,
      context:trimObj({
        ...base.context,
        ...patch.context,
        custom_context: trimObj({
          ...(base.context && base.context.custom_context),
          ...(patch.context && patch.context.custom_context),
        }),
      }),
    });
  }

  function writeUnanswerableToMeta(data) {
    const { value } = data;
    if (!value) {
      return data;
    }
    if (!value.finished || value.finish_reason !== 'success' || (value.sources && value.sources.length > 0)) {
      return data;
    }
    return {
      ...data,
      meta: {
        ...data.meta,
        unanswerable: true,
      },
    };
  }

  const DEFAULT_API_OPTIONS$7 = Object.freeze({});

  const DEFAULT_LAYOUTS$7 = Object.freeze({
    [ROLE.CONTAINER]: ContainerLayout.type,
    [ROLE.ERROR]: ErrorLayout.type,
  });

  const DEFAULT_TRACKERS$7 = Object.freeze({});

  const DEFAULT_OPTIONS$8 = Object.freeze({
    api: DEFAULT_API_OPTIONS$7,
    layouts: DEFAULT_LAYOUTS$7,
    trackers: DEFAULT_TRACKERS$7,
  });

  const ROLES_OPTIONS$a = Object.freeze({
    mappings: {
      [ROLE.ERROR]: data => data.error,
    },
  });

  class Workflow extends Component {

    constructor(args) {
      super(args.name || 'workflow', args.plugin);

      let { context, plugin, client, defaults, options } = args;
      this._context = context;
      this._plugin = plugin = plugin || context._plugin;
      this._client = client = client || context._client;
      args = Object.freeze({ ...args, plugin, client });

      this._name = args.name;
      this._roles = args.roles;

      this._extensions = plugin._getExtensions(client);
      this._defaults = defaults;
      this._options = options || new WorkflowOptions(context && context._options, defaults);
      this._hub = new Hub({
        onUpdate: event => this._onHubUpdate(event),
        onEmit: event => this._onHubEmit(event),
      });
      this._sessionContext = new WeakMap();

      client._events.emit('workflow', this);

      this._initProperties(args);
      this._initActors(args);
      this._initSubscriptions(args);
      this._initSession(args);
    }

    _initProperties() {}

    _initActors({ name, roles }) {
      const hub = this._hub;
      const client = this._client;
      const options = this._options;
      const extensions = this._extensions;
      const layouts = this._plugin.layouts;

      this._sessions = new SessionMaker(hub);
      this._data = new DataActor(hub, { source: api(client), options });
      this._views = new ViewsActor(hub, { extensions, layouts, roles, options, workflow: name });
      this._interactions = new InteractionsActor(hub, { client, options });
    }

    _initSubscriptions({ roles }) {
      this._unsubscribes = [
        this._hub.on(response(), data => this.updateData(data)),
        this._hub.on(tracker(), args => this._onTracker(args)),
      ];
      if (roles.main) {
        this._unsubscribes.push(this._hub.on(view(roles.main), state => this._onMainViewUpdate(state)));
      }
    }

    _initSession() {
      this.restart();
    }

    _getSessionContext(session) {
      let context = this._sessionContext.get(session);
      if (!context) {
        this._sessionContext.set(session, context = {});
      }
      return context;
    }

    // hub //
    _onHubUpdate(event) {
      this._runCallbacks(this._client.meta.parent._hubUpdateCallbacks, event);
    }

    _onHubEmit(event) {
      this._runCallbacks(this._client.meta.parent._hubEmitCallbacks, event);
      this._emitAsWorkflowEvent(event);
    }

    _emitAsWorkflowEvent({ action: _action, name, state, silent }) {
      if (!silent) {
        this._emit(name, { _action, ...state });
      }
    }

    // properties //
    get uuid() {
      // TODO: review this
      return this.session && this.session.uuid;
    }

    get session() {
      return this._hub.states[session()];
    }

    get states() {
      return this._hub.states;
    }

    get status() {
      const data$1 = this._hub.states[data()];
      return data$1 && data$1.status;
    }

    get views() {
      return this._views.interface;
    }

    // lifecycle //
    restart() {
      this._emitInterruptEventIfNecessary();
      this._sessions.restart();
      return this;
    }

    _emitInterruptEventIfNecessary() {
      const { main } = this._roles;
      if (!main) {
        return;
      }
      const state = this._hub.states[view(main)] || {};
      if (state.session && state.status === STATUS.LOADING) {
        // it's interrupted by a new question
        this._emitLifecycleEvent('interrupt', state);
        this._emitLifecycleEvent('finally', state);
      }
    }

    _onMainViewUpdate(state) {
      const { status } = state;
      const done = status === STATUS.READY;
      const erroneous = status === STATUS.ERRONEOUS;
      const eventName = erroneous ? 'error' : status;
      this._emitLifecycleEvent(eventName, state);
      if (done) {
        this._emitLifecycleEvent('done', state);
      }
      if (done || erroneous) {
        this._emitLifecycleEvent('finally', state);
      }
    }

    _shallEmitLifecycleEvent(name, { session }) {
      const context = this._getSessionContext(session);
      const events = context.lifecycleEvents || (context.lifecycleEvents = new Set());
      const emitted = events.has(name);
      events.add(name);
      return !emitted;
    }

    _emitLifecycleEvent(name, event) {
      if (!this._shallEmitLifecycleEvent(name, event)) {
        return;
      }
      this._emit(name, event);
    }

    // request //
    _request(options = {}) {
      const { session } = this;
      const event = mergeApiOptions(this._options.resolved.api, { ...options, session });
      this._hub.update(request(), event);
    }

    // data //
    updateData(data$1) {
      if (!data$1) {
        throw new Error(`Data is required.`);
      }
      const { session } = data$1;
      if (!session) {
        throw new Error(`Session is required to update data.`);
      }
      if (!this.session) {
        throw new Error(`No session is created yet. Call workflow.restart() to start a new session.`);
      }
      if (session.uuid !== this.session.uuid) {
        return; // ignore data for old session or inactive session
      }

      // compare revision to omit outdated data, if any
      const revision = getRevision(data$1);
      if (!isNullLike(revision)) {
        const currentRevision = getRevision(this._hub.states[data()]);
        if (!isNullLike(currentRevision) && revision <= currentRevision) {
          return;
        }
      }

      this._updateData(data$1);

      return this;
    }

    _updateData(data) {
      data = this._defaultProcessData(data);
      for (const process of this._options.resolved.dataProcessor) {
        data = process(data);
      }

      this._updateDataInHub(data);
    }

    _defaultProcessData(data) {
      data = writeDataStatus(data);
      data = writeMisoIdToMeta(data);
      return data;
    }

    _updateDataInHub(data$1) {
      this._hub.update(data(), data$1);
    }

    // TODO: notifyViewUpdateAll()

    notifyViewUpdate(role, state) {
      state = {
        status: STATUS.READY,
        session: this.session,
        ...state,
      };
      this._hub.update(view(role), state);
      return this;
    }

    // trackers //
    get trackers() {
      return this._views.trackers;
    }

    _onTracker(args) {
      const payload = this._buildInteraction(args);
      this._sendInteraction(payload);
    }

    _buildInteraction(args) {
      let payload = buildBaseInteraction(args);
      payload = this._defaultProcessInteraction(payload, args);
      const { preprocess = [] } = this._options.resolved.interactions;
      for (const p of preprocess) {
        payload = p(payload, args);
      }
      return payload;
    }

    _defaultProcessInteraction(payload, args) {
      payload = this._writeApiInfoToInteraction(payload, args);
      payload = this._writeMisoIdToInteraction(payload, args);
      payload = writeAffiliationInfoToInteraction(payload, args);
      return payload;
    }

    _writeApiInfoToInteraction(payload) {
      const { group, name } = this._options.resolved.api;
      return mergeInteraction(payload, {
        context: {
          custom_context: {
            api_group: group,
            api_name: name,
          },
        },
      });
    }

    _writeMisoIdToInteraction(payload, args) {
      // TODO: ad-hoc, try to pass info from tracker
      const state = this._hub.states[view(args.role)] || {};
      const miso_id = (state.meta && state.meta.miso_id) || undefined;
      return miso_id ? mergeInteraction(payload, { miso_id }) : payload;
    }

    _sendInteraction(payload) {
      const { handle } = this._options.resolved.interactions;
      if (typeof handle === 'function') {
        handle(payload);
      } else {
        this._hub.trigger(interaction(), payload);
      }
    }

    // destroy //
    destroy(options) {
      this._events.emit('destroy');
      this._destroy(options);
    }

    _destroy({ dom } = {}) {
      for (const unsubscribe of this._unsubscribes || []) {
        unsubscribe();
      }
      this._unsubscribes = [];

      this._views._destroy({ dom });
      this._data._destroy();
    }

    // helper //
    _runCallbacks(callbacks, event) {
      for (const callback of callbacks) {
        try {
          callback({ workflow: this, ...event });
        } catch(e) {
          this._error(e);
        }
      }
    }

    _emit(name, data) {
      this._events.emit(name, { _event: name, ...data });
      if (this._context) {
        this._context._events.emit(name, { workflow: this, _event: name, ...data });
      }
    }

  }

  makeConfigurable(Workflow.prototype);

  Object.assign(Workflow, {
    DEFAULT_API_OPTIONS: DEFAULT_API_OPTIONS$7,
    DEFAULT_LAYOUTS: DEFAULT_LAYOUTS$7,
    DEFAULT_TRACKERS: DEFAULT_TRACKERS$7,
    DEFAULT_OPTIONS: DEFAULT_OPTIONS$8,
    ROLES_OPTIONS: ROLES_OPTIONS$a,
  });

  function processData(data) {
    if (!data || !data.value) {
      return data;
    }
    const { value } = data;
    return {
      ...data,
      value: processValue(value)
    };
  }

  function processValue(value) {
    if (value.sovrn_aff) {
      const { sovrn_aff, ...rest } = value;
      value = {
        ...rest,
        affiliation: processSovrnData(sovrn_aff),
      };
    }
    return postProcessValue(value);
  }

  function postProcessValue(value) {
    const { affiliation } = value;
    if (!affiliation) {
      return value;
    }
    let { channel, products } = affiliation;
    if (!products) {
      return value;
    }
    products = products.map(product => ({ ...product }));
    let i = 0;
    for (const product of products) {
      if (channel) {
        product.channel = channel;
      }
      product.position = i++;
    }
    return {
      ...value,
      affiliation: {
        ...affiliation,
        products,
      },
    };
  }

  function processSovrnData({ products, ...sovrn_aff }) {
    return {
      channel: 'sovrn',
      ...sovrn_aff,
      products: products.map(processSovrnProduct),
    };
  }

  function processSovrnProduct({
    id,
    deeplink: url,
    headline: title,
    description,
    currency,
    retailPrice: original_price,
    salePrice: sale_price,
    discountRate: discount_rate_percent,
    image: cover_image,
    thumbnail,
    merchant,
    ...product
  }) {
    const brand = merchant && merchant.name;
    const brand_logo = merchant && merchant.logo;
    return trimObj({
      id: `sovrn-${id}`,
      title,
      description,
      cover_image,
      url,
      currency,
      original_price,
      sale_price,
      discount_rate_percent,
      brand,
      brand_logo,
      custom_attributes: flatten({
        sovrn_id: id,
        thumbnail,
        merchant,
        ...product,
      }),
    });
  }

  function flatten(obj, prefix = '') {
    return Object.keys(obj).reduce((acc, key) => {
      const value = obj[key];
      if (value === undefined) {
        return acc;
      }
      const prefixedKey = prefix ? `${prefix}_${key}` : key;
      if (typeof value === 'object') {
        return { ...acc, ...flatten(value, prefixedKey) };
      }
      return { ...acc, [prefixedKey]: value };
    }, {});
  }

  function enableUseLink(prototype) {
    mixin(prototype, UseLinkMixin.prototype);
  }

  class UseLinkMixin {

    useLink(fn, options = {}) {
      if (typeof fn !== 'function' && fn !== false) {
        throw new Error('useLink(fn) expects fn to be a function or false');
      }
      this._linkFn = fn ? [fn, options] : false;
      return this;
    }

    _submitToPage(args = {}) {
      if (!this._linkFn) {
        return;
      }
      // TODO: we want a submit event
      const url = this._getSubmitUrl(args);
      const [_, options = {}] = this._linkFn;
      if (options.open === false) {
        window.location.href = url;
      } else {
        const target = options.target || '_blank';
        const windowFeatures = options.windowFeatures || '';
        window.open(url, target, windowFeatures);
      }
    }

    _getSubmitUrl({ q, ...args } = {}) {
      if (!this._linkFn) {
        throw new Error('useLink(fn) must be called before _getSubmitUrl()');
      }
      return this._linkFn[0](q, args);
    }

  }

  const DEFAULT_API_OPTIONS$6 = Object.freeze({
    ...Workflow.DEFAULT_API_OPTIONS,
    group: GROUP$5.ASK,
    payload: {
      ...Workflow.DEFAULT_API_OPTIONS.payload,
      source_fl: ['cover_image', 'url', 'created_at', 'updated_at', 'published_at'],
      cite_link: 1,
      cite_start: '[',
      cite_end: ']',
    },
  });

  const DEFAULT_AUTOCOMPLETE_OPTIONS$2 = Object.freeze({
    actor: false,
    api: {
      group: GROUP$5.ASK,
      name: NAME$6.AUTOCOMPLETE,
    },
  });

  const DEFAULT_LAYOUTS$6 = Object.freeze({
    ...Workflow.DEFAULT_LAYOUTS,
    [ROLE.QUERY]: [SearchBoxLayout.type, { placeholder: 'Ask a question' }],
    [ROLE.QUESTION]: [TextLayout.type, { tag: 'h2' }],
    [ROLE.ANSWER]: TypewriterLayout.type,
    [ROLE.FEEDBACK]: FeedbackLayout.type,
    [ROLE.IMAGES]: [GalleryLayout.type, { incremental: true, itemType: 'image' }],
    [ROLE.SOURCES]: [ListLayout.type, { incremental: true, itemType: 'article', templates: { ordered: true } }],
    [ROLE.AFFILIATION]: [AffiliationLayout.type, { incremental: true, itemType: 'affiliation', link: { rel: 'noopener nofollow' } }],
  });

  const DEFAULT_TRACKERS$6 = Object.freeze({
    ...Workflow.DEFAULT_TRACKERS,
    [ROLE.ANSWER]: {
      active: true,
      itemless: true,
      deduplicated: false,
      click: DEFAULT_TRACKER_OPTIONS$1.click, // click only
    },
    [ROLE.IMAGES]: DEFAULT_TRACKER_OPTIONS$1,
    [ROLE.SOURCES]: DEFAULT_TRACKER_OPTIONS$1,
    [ROLE.AFFILIATION]: DEFAULT_TRACKER_OPTIONS$1,
    [ROLE.PRODUCTS]: DEFAULT_TRACKER_OPTIONS$1,
  });

  const DEFAULT_OPTIONS$7 = Object.freeze({
    ...Workflow.DEFAULT_OPTIONS,
    api: DEFAULT_API_OPTIONS$6,
    autocomplete: DEFAULT_AUTOCOMPLETE_OPTIONS$2,
    layouts: DEFAULT_LAYOUTS$6,
    trackers: DEFAULT_TRACKERS$6,
  });

  const ROLES_OPTIONS$9 = mergeRolesOptions(Workflow.ROLES_OPTIONS, {
    main: ROLE.ANSWER,
    members: Object.keys(DEFAULT_LAYOUTS$6),
  });

  class AnswerBasedWorkflow extends Workflow {

    // constructor //
    _initProperties(args) {
      super._initProperties(args);
      this._questionId = undefined;
      this._autoQuery = false;
    }

    _initActors(args) {
      super._initActors(args);
      this._feedback = new FeedbackActor(this._hub);
    }

    _initSubscriptions(args) {
      super._initSubscriptions(args);
      this._unsubscribes = [
        ...this._unsubscribes,
        this._hub.on(query$1(), args => this._query(args)),
        this._views.get(ROLE.ANSWER).on('citation-click', event => this._onCitationClick(event)),
        this._views.get(ROLE.ANSWER).on('link-click', event => this._onAnswerLinkClick(event)),
      ];
    }

    // lifecycle //
    restart() {
      // clear question id from previous session
      if (this._questionId) {
        this._questionId = undefined;
      }
      // restart
      super.restart();
    }

    _shallEmitLifecycleEvent(name, event) {
      return name === 'answer-stage' || super._shallEmitLifecycleEvent(name, event);
    }

    _emitInterruptEventIfNecessary() {
      const state = this._hub.states[view(this._roles.main)] || {};
      if (state.session && state.status !== STATUS.INITIAL && (state.status !== STATUS.READY || state.ongoing)) {
        // it's interrupted by a new question
        this._emitLifecycleEvent('interrupt', state);
        this._emitLifecycleEvent('finally', state);
      }
    }

    _onMainViewUpdate(state) {
      const { status, session } = state;
      const done = status === STATUS.READY && !state.ongoing;
      const erroneous = status === STATUS.ERRONEOUS;
      const eventName = done ? 'done' : erroneous ? 'error' : status;
      // answer-stage
      const context = this._getSessionContext(session);
      const oldAnswerStage = context.answerStage;
      const newAnswerStage = state.meta && state.meta.answer_stage;
      if (newAnswerStage && newAnswerStage !== oldAnswerStage) {
        this._emitLifecycleEvent('answer-stage', Object.freeze({ ...state, answer_stage: newAnswerStage }));
        context.answerStage = newAnswerStage;
      }
      // ready, done, or error
      this._emitLifecycleEvent(eventName, state);
      if (done || erroneous) {
        // finally
        this._emitLifecycleEvent('finally', state);
      }
    }

    // properties //
    get questionId() {
      return this._questionId;
    }

    // query //
    autoQuery(options = {}) {
      autoQuery.call(this, options);
    }

    query(args) {
      // TODO: also accept "question", "questionSource"?
      if (!args.q) {
        throw new Error(`q is required in query() call`);
      }
      this._hub.update(query$1(), args);
    }

    _query(args = {}) {
      if (this._linkFn) {
        this._submitToPage(args);
        return;
      }
      // start a new session
      this.restart();

      // keep track of question source on this session, for suggested questions interactions
      this._writeQuestionSourceToSession(args);

      // build payload and trigger request
      const payload = this._buildPayload(args);
      this._request({ payload });
    }

    _writeQuestionSourceToSession(args) {
      this.session.meta.question_source = args.qs || ORGANIC_QUESTION_SOURCE; // might be null, not undefined
    }

    _buildPayload() {
      throw new Error(`Not implemented`);
    }

    _writeWikiLinkTemplateToPayload(payload) {
      if (!this._autoQuery || !this._autoQuery.param || this._autoQuery.param === DEFAULT_AUTO_QUERY_PARAM) {
        return payload;
      }
      return {
        ...payload,
        wiki_link_template: `?${this._autoQuery.param}=%s`,
      };
    }

    // data //
    _updateData(data) {
      // capture question ID and register at context
      this._writeQuestionIdFromData(data);

      // if it's the head response, write question id and return
      if (data.value && !data.value.answer_stage) {
        this._handleHeadResponse(data);
        return;
      }
      super._updateData(data);

      // update URL if autoQuery.updateUrl is not false
      this._updateUrlIfNecessary(data);
    }

    _handleHeadResponse(data) {}

    _defaultProcessData(data) {
      data = super._defaultProcessData(data);
      data = processData(data);
      data = writeAnswerStageToMeta(data);
      return data;
    }

    _writeQuestionIdFromData({ value }) {
      value && this._writeQuestionId(value.question_id);
    }

    _updateUrlIfNecessary({ value, request }) {
      if (!this._autoQuery || !this._autoQuery.updateUrl) {
        return;
      }
      const { param, sourceParam } = this._autoQuery;
      const question = (value && value.question) || (request && request.payload && request.payload.question);
      const questionSource = request && request.payload && request.payload._meta && request.payload._meta.question_source;

      if (!question) {
        return; // at initial phase
      }

      const url = new URL(window.location);
      const currentQuestion = url.searchParams.get(param);
      const currentQuestionSource = url.searchParams.get(sourceParam) || ORGANIC_QUESTION_SOURCE;
      if (question === currentQuestion && questionSource === currentQuestionSource) {
        return;
      }
      url.searchParams.set(param, question);
      if (questionSource === ORGANIC_QUESTION_SOURCE) {
        url.searchParams.delete(sourceParam);
      } else {
        url.searchParams.set(sourceParam, questionSource);
      }
      window.history.replaceState({}, '', url);
    }

    // interactions //
    _defaultProcessInteraction(payload, args) {
      payload = super._defaultProcessInteraction(payload, args);
      payload = this._writeAskPropertiesToInteraction(payload, args);
      payload = this._writeAnswerClickInteraction(payload, args);
      payload = writeEventTargetToInteraction(payload, args);
      return payload;
    }

    _writeAskPropertiesToInteraction(payload = {}, args) {
      const question_source = this._getQuestionSourceFromViewState(args);
      const question_id = this.questionId;
      return mergeInteraction(payload, {
        context: {
          custom_context: {
            question_source,
            question_id,
          },
        },
      });
    }

    _writeAnswerClickInteraction(payload, args) {
      if (args.role !== ROLE.ANSWER) {
        return payload;
      }
      const { items = [] } = args;
      return mergeInteraction(payload, {
        context: {
          custom_context: {
            urls: items.map(item => item.url),
            texts: items.map(item => item.text),
            class_names: items.map(item => item.className),
            attributes: items.map(item => item.attributes),
          },
        },
      });
    }

    _getQuestionSourceFromViewState(args) {
      const { request } = this._hub.states[view(args.role)] || {};
      const { payload } = request || {};
      return (payload && payload._meta && payload._meta.question_source) || undefined;
    }

    // handlers //
    _onCitationClick({ index, event }) {
      if (isTracked(event)) {
        return;
      }
      const { value } = this.states[data()] || {};
      const { sources } = value || {};
      // index is 1-based
      const source = sources && sources[index - 1];
      if (!source || !source.product_id) {
        return;
      }
      // TODO: should we track impression as well?
      markAsTracked(event);
      // distinguish from regular sources element click
      // TODO
      this._views.trackers.sources.click([source.product_id], { event_target: 'citation-link' });
    }

    _onAnswerLinkClick({ event, ...item }) {
      if (isTracked(event)) {
        return;
      }
      markAsTracked(event);
      // put everything into args and let _defaultProcessInteraction() handles it
      // for it's hard to make it a standard item
      this._views.trackers.answer.click([], { items: [item] });
    }

    // helpers //
    _writeQuestionId(questionId) {
      if (!this._questionId && questionId) {
        this._questionId = questionId;
      }
    }

    _clearQuestionId() {
      // clear question id from previous session
      this._questionId = undefined;
    }

    // destroy //
    _destroy(options) {
      this._feedback._destroy();
      // this._autocomplete._destroy();
      super._destroy(options);
    }

  }

  enableUseLink(AnswerBasedWorkflow.prototype);

  Object.assign(AnswerBasedWorkflow, {
    DEFAULT_API_OPTIONS: DEFAULT_API_OPTIONS$6,
    DEFAULT_AUTOCOMPLETE_OPTIONS: DEFAULT_AUTOCOMPLETE_OPTIONS$2,
    DEFAULT_LAYOUTS: DEFAULT_LAYOUTS$6,
    DEFAULT_TRACKERS: DEFAULT_TRACKERS$6,
    DEFAULT_OPTIONS: DEFAULT_OPTIONS$7,
    ROLES_OPTIONS: ROLES_OPTIONS$9,
  });

  const DEFAULT_API_OPTIONS$5 = Object.freeze({
    ...AnswerBasedWorkflow.DEFAULT_API_OPTIONS,
    name: NAME$6.QUESTIONS,
    payload: {
      ...AnswerBasedWorkflow.DEFAULT_API_OPTIONS.payload,
      related_resource_fl: ['cover_image', 'url', 'created_at', 'updated_at', 'published_at'],
    },
  });

  const DEFAULT_LAYOUTS$5 = Object.freeze({
    ...AnswerBasedWorkflow.DEFAULT_LAYOUTS,
    [ROLE.QUERY]: [SearchBoxLayout.type, { templates: { buttonIcon: 'send' } }],
    [ROLE.RELATED_RESOURCES]: [ListLayout.type, { incremental: true, itemType: 'article' }],
    [ROLE.QUERY_SUGGESTIONS]: OptionListLayout.type,
  });

  const DEFAULT_TRACKERS$5 = Object.freeze({
    ...AnswerBasedWorkflow.DEFAULT_TRACKERS,
    [ROLE.RELATED_RESOURCES]: DEFAULT_TRACKER_OPTIONS$1,
    [ROLE.QUERY_SUGGESTIONS]: {
      ...DEFAULT_TRACKER_OPTIONS$1,
      click: {
        ...DEFAULT_TRACKER_OPTIONS$1.click,
        validate: event => event.button === 0, // loosen criteria, for it's not a hyperlink
      },
    },
  });

  const DEFAULT_OPTIONS$6 = Object.freeze({
    ...AnswerBasedWorkflow.DEFAULT_OPTIONS,
    api: DEFAULT_API_OPTIONS$5,
    layouts: DEFAULT_LAYOUTS$5,
    trackers: DEFAULT_TRACKERS$5,
  });

  const ROLES_OPTIONS$8 = mergeRolesOptions(AnswerBasedWorkflow.ROLES_OPTIONS, {
    members: Object.keys(DEFAULT_LAYOUTS$5),
  });

  class Ask extends AnswerBasedWorkflow {

    constructor(context, parentQuestionId) {
      super({
        name: 'ask',
        context,
        roles: ROLES_OPTIONS$8,
        defaults: DEFAULT_OPTIONS$6,
        parentQuestionId,
      });
    }

    _initProperties(args) {
      super._initProperties(args);
      const { parentQuestionId } = args;
      defineValues(this, { parentQuestionId });
    }

    _initSubscriptions(args) {
      this._setSuggestedQuestions();
      super._initSubscriptions(args);
    }

    _setSuggestedQuestions() {
      const { previous } = this;
      if (!previous) {
        return;
      }
      // TODO: write question_source from payload._meta, so we don't need to write it to session.meta
      const values = previous.states[data()].value;
      const value = values.suggested_followup_questions || values.followup_questions || [];
      this._hub.update(suggestions(), { value: value.map(text => ({ text })) });
    }

    _initSession(args) {
      // register at context
      args.parentQuestionId && this._context._byPqid.set(args.parentQuestionId, this);
      this._context._events.emit('create', this);
      super._initSession(args);
    }

    // lifecycle //
    restart() {
      if (this._questionId) {
        this._context._byQid.delete(this._questionId);
      }
      super.restart();
    }

    // properties //
    get rootQuestionId() {
      return this._context.root.questionId;
    }

    get previous() {
      const { parentQuestionId } = this;
      return parentQuestionId ? this._context.getByQuestionId(parentQuestionId) : undefined;
    }

    get next() {
      const { questionId } = this;
      return questionId ? this._context.getByParentQuestionId(questionId) : undefined;
    }

    getOrCreateNext() {
      const { questionId } = this;
      return questionId ? this._context.getByParentQuestionId(questionId, { autoCreate: true }) : undefined;
    }

    // query //
    _buildPayload({ q, qs, ...options } = {}) {
      const { parentQuestionId } = this;
      let payload = trimObj({
        ...options,
        question: q, // question, not q
        parent_question_id: parentQuestionId,
        _meta: {
          ...options._meta,
          question_source: qs || ORGANIC_QUESTION_SOURCE, // might be null, not undefined
        },
      });
      payload = this._writeWikiLinkTemplateToPayload(payload);
      return payload;
    }

    // interactions //
    _writeAskPropertiesToInteraction(payload, args) {
      const root_question_id = this.rootQuestionId;
      let { property } = (payload.context && payload.context.custom_context) || {};
      let question_id, parent_question_id, question_source;

      if (args.role === ROLE.QUERY_SUGGESTIONS) {
        property = 'suggested_followup_questions';
        parent_question_id = this.previous && this.previous.parentQuestionId;
        question_id = this.parentQuestionId;
        question_source = this.previous && this.previous.session.meta.question_source;
      } else {
        parent_question_id = this.parentQuestionId;
        question_id = this.questionId;
        question_source = this._getQuestionSourceFromViewState(args);
      }

      return mergeInteraction(payload, {
        context: {
          custom_context: {
            property,
            root_question_id,
            parent_question_id,
            question_id,
            question_source,
          },
        }
      });
    }

    // helpers //
    _writeQuestionId(questionId) {
      // capture question ID and register at context
      if (!this._questionId && questionId) {
        this._questionId = questionId;
        this._context._byQid.set(questionId, this);
      }
    }

    _clearQuestionId() {
      // clear question id from previous session
      if (this._questionId) {
        this._context._byQid.delete(this._questionId);
        this._questionId = undefined;
      }
    }

    // destroy //
    _destroy(options) {
      const { parentQuestionId, questionId } = this;
      if (parentQuestionId) {
        this._context._byPqid.delete(parentQuestionId);
      }
      if (questionId) {
        this._context._byQid.delete(questionId);
      }
      super._destroy(options);
    }

  }

  class Asks extends WorkflowContext {

    constructor(plugin, client) {
      super('asks', plugin, client);
      this._byQid = new Map();
      this._byPqid = new Map();
      this._root = new Ask(this); // initialize with default workflow
    }

    get root() {
      return this._root;
    }

    get workflows() {
      return [this._root, ...this._byPqid.values()];
    }

    getByQuestionId(questionId) {
      if (typeof questionId !== 'string') {
        throw new Error(`Required ID to be a string: ${questionId}`);
      }
      return this._byQid.get(questionId);
    }

    getByParentQuestionId(parentQuestionId, { autoCreate = false } = {}) {
      if (parentQuestionId === undefined) {
        return this._root;
      }
      if (typeof parentQuestionId !== 'string') {
        throw new Error(`Required ID to be a string: ${parentQuestionId}`);
      }
      let workflow = this._byPqid.get(parentQuestionId);
      if (!workflow && autoCreate) {
        workflow = new Ask(this, parentQuestionId);
      }
      return workflow;
    }

    reset({ root = true, events, ...options } = {}) {
      // clear event listeners on context
      if (events === undefined) {
        events = !!root; // events are default to be true only when root = true
      }
      if (events) {
        this._events.clear();
      }

      // destroy all follow-up workflows
      for (const workflow of this._byPqid.values()) {
        workflow.destroy(options);
      }

      // reset root workflow
      if (root) {
        this._root.restart();
      }
    }

  }

  const DEFAULT_ROWS = 10;
  const DEFAULT_PAGE_LIMIT = 10;

  const DEFAULT_API_OPTIONS$4 = Object.freeze({
    ...Workflow.DEFAULT_API_OPTIONS,
    group: GROUP$5.SEARCH,
    payload: {
      ...Workflow.DEFAULT_API_OPTIONS.payload,
      fl: ['cover_image', 'url', 'created_at', 'updated_at', 'published_at', 'title'],
      rows: DEFAULT_ROWS,
    },
  });

  const DEFAULT_LAYOUTS$4 = Object.freeze({
    ...Workflow.DEFAULT_LAYOUTS,
    [ROLE.QUERY]: [SearchBoxLayout.type],
    [ROLE.PRODUCTS]: [ListLayout.type, { incremental: true, infiniteScroll: true }],
    [ROLE.KEYWORDS]: [TextLayout.type, { raw: true }],
    [ROLE.TOTAL]: [TextLayout.type, { raw: true, format: 'number' }],
    [ROLE.FACETS]: [FacetsLayout.type],
    [ROLE.SORT]: [SelectLayout.type],
    [ROLE.MORE]: [MoreButtonLayout.type],
  });

  const DEFAULT_TRACKERS$4 = Object.freeze({
    ...Workflow.DEFAULT_TRACKERS,
    [ROLE.PRODUCTS]: DEFAULT_TRACKER_OPTIONS$1,
  });

  const DEFAULT_PAGINATION$1 = Object.freeze({
    active: false,
    mode: 'infiniteScroll',
    pageLimit: 10,
  });

  const DEFAULT_OPTIONS$5 = Object.freeze({
    ...Workflow.DEFAULT_OPTIONS,
    api: DEFAULT_API_OPTIONS$4,
    layouts: DEFAULT_LAYOUTS$4,
    trackers: DEFAULT_TRACKERS$4,
    pagination: DEFAULT_PAGINATION$1,
  });

  const ROLES_OPTIONS$7 = mergeRolesOptions(Workflow.ROLES_OPTIONS, {
    main: ROLE.PRODUCTS,
    members: Object.keys(DEFAULT_LAYOUTS$4),
    mappings: {
      [ROLE.FACETS]: 'facet_counts',
      [ROLE.SORT]: mappingSortData,
    },
  });

  class SearchBasedWorkflow extends Workflow {

    _initSubscriptions(args) {
      super._initSubscriptions(args);
      this._unsubscribes = [
        ...this._unsubscribes,
        this._hub.on(query$1(), args => this._query(args)),
        this._hub.on(filters(), () => this._refine()),
        this._hub.on(more(), () => this._more()),
        this._views.get(ROLE.SORT).on('select', event => this._handleSortSelect(event)),
      ];
    }

    restart() {
      super.restart();
      this._page = 0;
    }

    // properties //
    get exhausted() {
      const data$1 = this._hub.states[data()];
      return !!(data$1 && data$1.meta && data$1.meta.exhausted);
    }

    get page() {
      return this._page;
    }

    // query //
    autoQuery(options = {}) {
      autoQuery.call(this, options);
    }

    query(args) {
      if (!args.q) {
        throw new Error(`q is required in query() call`);
      }
      this._hub.update(query$1(), args);
    }

    _query(args) {
      // keep track of the query args for refine and more calls
      this._queryArgs = args;

      // start a new session
      this.restart();

      // payload
      const payload = this._buildPayload(args);

      this._request({ payload });
    }

    _refine() {
      // remember current facet_counts
      const { facet_counts } = this._hub.states[data()].value || {};
      this._currentFacetCounts = facet_counts;

      // start a new session
      this.restart();

      // payload
      const query = this._getQuery();
      const payload = this._buildPayload(query);

      this._request({ payload });
    }

    // TODO: expose API
    _more() {
      // if still loading, complain
      if (this.status !== STATUS.READY) {
        throw new Error(`Can not call more() while loading.`);
      }
      // no more pages, ignore
      if (this.exhausted || this._page >= DEFAULT_PAGE_LIMIT - 1) {
        return;
      }
      // don't create a new session!

      this._page++;

      // payload
      const query = this._getQuery();
      let payload = this._buildPayload(query);
      payload = this._processPayloadForMoreRequest(payload);

      this._request({ payload });
    }

    _getQuery() {
      // TODO: just get from the hub
      return this._queryArgs;
    }

    _getPageSize() {
      return this._options.resolved.api.payload.rows;
    }

    _buildPayload(payload) {
      payload = this._writeFiltersToPayload(payload);
      payload = this._writePageInfoToPayload(payload);
      return payload;
    }

    _writeFiltersToPayload(payload) {
      const filters$1 = this._hub.states[filters()];
      const { facets, sort } = filters$1 || {};
      return trimObj({
        ...payload,
        facet_filters: this._buildFacetFilters(facets),
        order_by: this._buildOrderBy(sort),
      });
    }

    _buildFacetFilters(facets) {
      if (!facets) {
        return undefined;
      }
      const filters = {};
      for (const field in facets) {
        const values = facets[field];
        if (!values || !values.length) {
          continue; // just in case
        }
        filters[field] = {
          terms: values,
        };
      }
      return Object.keys(filters).length ? filters : undefined;
    }

    _buildOrderBy(sort) {
      if (!sort) {
        return undefined;
      }
      return asArray(sort);
    }

    _writePageInfoToPayload(payload) {
      return {
        ...payload,
        _meta: {
          ...payload._meta,
          page: this._page,
        },
      };
    }

    _processPayloadForMoreRequest(payload = {}) {
      const data$1 = this._hub.states[data()];
      const { [this._roles.main]: items = [] } = (data$1 && data$1.value) || {};
      const productIds = items.map(item => item.product_id).filter(v => v);
      const exclude = [...(payload.exclude || []), ...productIds];
      if (exclude.length === 0) {
        return payload;
      }
      return {
        ...payload,
        exclude,
      };
    }

    // data //
    _defaultProcessData(data) {
      data = super._defaultProcessData(data);
      data = writeKeywordsToData(data);
      data = retainFacetCountsInData(data, this._currentFacetCounts);
      data = writeExhaustionToData(data, { role: this._roles.main });
      return data;
    }

    _updateDataInHub(data) {
      data = this._appendResultsFromMoreRequest(data);
      super._updateDataInHub(data);
    }

    _appendResultsFromMoreRequest(data$1) {
      const { request } = data$1;
      if (!request) {
        return data$1; // the initial state
      }
      const { _meta } = request.payload;
      if (!_meta || !_meta.page) {
        return data$1; // not from "more" request
      }
      // concat records if it's from "more" request
      const currentData = this._hub.states[data()];
      return concatItemsFromMoreResponse(currentData, data$1, { role: this._roles.main });
    }

    // view actions //
    _handleSortSelect({ value } = {}) {
      if (!value) {
        return;
      }
      this._views.filters.update({ sort: value });
      this._views.filters.apply();
    }

  }

  makeConfigurable(SearchBasedWorkflow.prototype, [WORKFLOW_CONFIGURABLE.PAGINATION, WORKFLOW_CONFIGURABLE.FILTERS]);

  Object.assign(SearchBasedWorkflow, {
    DEFAULT_API_OPTIONS: DEFAULT_API_OPTIONS$4,
    DEFAULT_LAYOUTS: DEFAULT_LAYOUTS$4,
    DEFAULT_TRACKERS: DEFAULT_TRACKERS$4,
    DEFAULT_PAGINATION: DEFAULT_PAGINATION$1,
    DEFAULT_OPTIONS: DEFAULT_OPTIONS$5,
    ROLES_OPTIONS: ROLES_OPTIONS$7,
  });

  const ROLES_OPTIONS$6 = Object.freeze({
    members: [],
  });

  function shimDefaults({ layouts, trackers, ...options } = {}) {
    return {
      active: false,
      ...options,
      layouts: {},
      trackers: {},
    };
  }

  function sameInputValue(a, b) {
    return getInputValue(a) === getInputValue(b);
  }

  function getInputValue(args) {
    return (args && args.value && args.value.trim()) || undefined;
  }

  class Autocomplete extends Workflow {

    constructor(superworkflow, { defaults, ...args } = {}) {
      super({
        name: 'autocomplete',
        plugin: superworkflow._plugin,
        client: superworkflow._client,
        defaults: shimDefaults(defaults),
        roles: ROLES_OPTIONS$6,
        superworkflow,
        ...args,
      });
    }

    _initProperties(args) {
      super._initProperties(args);
      this._superworkflow = args.superworkflow;
      this._active = args.defaults.active;
    }

    _initSubscriptions(args) {
      // TODO: how to sync options updates
      super._initSubscriptions(args);
      this._unsubscribes = [
        ...this._unsubscribes,
        args.superworkflow._hub.on(input(), args => this._query(args)),
      ];
    }

    // API //
    get enabled() {
      return this._active;
    }

    enable() {
      this._active = true;
    }

    disable() {
      this._active = false;
    }

    // query //
    _query(args) {
      if (!this._active || sameInputValue(args, this._args)) {
        return;
      }
      this._args = args;

      // start a new session
      this.restart();
      const { session } = this;
      session.meta.input = args;

      // if input value is blank, emit empty response
      if (!getInputValue(args)) {
        this._updateCompletions({ session, status: STATUS.INITIAL });
        return;
      }

      // payload
      const payload = this._buildPayload(args);

      // request
      this._request({ payload });
    }

    _buildPayload(args) {
      return { q: getInputValue(args) };
    }

    // data //
    _updateDataInHub(data) {
      if (data.value) {
        data = {
          ...data,
          value: data.value.completions,
        };
      }
      // update completion field in superworkflow hub
      this._updateCompletions(data);
    }

    _updateCompletions(data) {
      // TODO: session is different
      this._superworkflow.updateCompletions(data);
    }

  }

  function makeAutocompletable(prototype) {
    mixin(prototype, AutocompletableMixin.prototype);
  }

  class AutocompletableMixin {

    _initAutocomplete(args) {
      this._autocomplete = new Autocomplete(this, { defaults: args.defaults.autocomplete });
    }

    get autocomplete() {
      return this._autocomplete;
    }

    updateCompletions(data) {
      this._hub.update(completions$1(), data);
      return this;
    }

    _destroyAutocomplete() {
      this._autocomplete && this._autocomplete._destroy();
      this._autocomplete = undefined;
    }

  }

  const ROLES_OPTIONS$5 = mergeRolesOptions(AnswerBasedWorkflow.ROLES_OPTIONS, {
    mappings: {
      [ROLE.QUESTION]: ROLE.KEYWORDS,
    },
  });

  class HybridSearchAnswer extends AnswerBasedWorkflow {

    constructor(superworkflow) {
      super({
        name: 'hybrid-search/answer',
        plugin: superworkflow._plugin,
        client: superworkflow._client,
        options: superworkflow._options,
        defaults: superworkflow._defaults,
        roles: ROLES_OPTIONS$5,
        superworkflow,
      });
    }

    _initProperties(args) {
      super._initProperties(args);
      this._initAutocomplete(args);
      this._superworkflow = args.superworkflow;
    }

    _initSession() {} // no reset here, will manually reset later

    restart() {
      super.restart();
      // cascade restart to the sibling
      const results = this._superworkflow._results;
      results._views.filters.reset();
      results.restart();
      this._resultsSession = results.session; // keep track of the session
    }

    // query //
    _buildPayload(payload) {
      payload = this._writeQuestionSourceToPayload(payload);
      payload = this._writeWikiLinkTemplateToPayload(payload);
      payload = this._superworkflow._results._writeFiltersToPayload(payload);
      return payload;
    }

    _writeQuestionSourceToPayload({ qs, ...payload } = {}) {
      return {
        ...payload,
        _meta: {
          ...payload._meta,
          question_source: qs || ORGANIC_QUESTION_SOURCE, // might be null, not undefined
        },
      };
    }

    // data //
    _defaultProcessData(data) {
      data = super._defaultProcessData(data);
      data = writeKeywordsToData(data);
      data = writeMisoIdFromSession(data);
      data = writeUnanswerableToMeta(data);
      return data;
    }

    _updateDataInHub(data) {
      switch (data.status) {
        case STATUS.INITIAL:
        case STATUS.LOADING:
          // share the initial/loading status with its sibling
          this._dispatchDataToSibling(data);
          break;
      }
      super._updateDataInHub(data);
    }

    _handleHeadResponse(data) {
      super._handleHeadResponse(data);
      // keep track of miso_id in session
      writeMisoIdToSession(data);
      // share the search results with its sibling
      this._dispatchDataToSibling(data);
    }

    _dispatchDataToSibling(data) {
      this._resultsSession && this._superworkflow._results.updateData({ ...data, session: this._resultsSession });
    }

    // interactions //
    _defaultProcessInteraction(payload, args) {
      return this._superworkflow._defaultProcessInteraction(payload, args);
    }

    _defaultProcessInteraction0(payload, args) {
      return super._defaultProcessInteraction(payload, args);
    }

    // destroy //
    _destroy(options) {
      this._destroyAutocomplete();
      super._destroy(options);
    }

  }

  makeAutocompletable(HybridSearchAnswer.prototype);

  // we want to override members, not adding to it
  const ROLES_OPTIONS$4 = {
    ...SearchBasedWorkflow.ROLES_OPTIONS,
    members: [ROLE.PRODUCTS, ROLE.KEYWORDS, ROLE.TOTAL, ROLE.FACETS, ROLE.SORT, ROLE.MORE, ROLE.ERROR],
  };

  class HybridSearchResults extends SearchBasedWorkflow {

    constructor(superworkflow) {
      super({
        name: 'hybrid-search/results',
        plugin: superworkflow._plugin,
        client: superworkflow._client,
        options: superworkflow._options,
        defaults: superworkflow._defaults,
        roles: ROLES_OPTIONS$4,
        superworkflow,
      });
    }

    _initProperties(args) {
      super._initProperties(args);
      this._superworkflow = args.superworkflow;
    }

    _initSession() {} // no reset here, will manually reset later

    // lifecycle //
    _emitLifecycleEvent(name, event) {
      super._emitLifecycleEvent(name, event);
      this._superworkflow._emitLifecycleEvent(name, event);
    }

    // query //
    _getQuery() {
      // get stored query from sibling
      return this._superworkflow._answer._hub.states[query$1()];
    }

    _buildPayload(payload) {
      // borrow the work from the sibling
      payload = this._superworkflow._answer._writeQuestionSourceToPayload(payload);
      payload = this._writeFiltersToPayload(payload);
      payload = this._writePageInfoToPayload(payload);
      payload = this._writeQuestionIdToPayload(payload);
      return { ...payload, answer: false };
    }

    _buildOrderBy(sort) {
      if (!sort) {
        return undefined;
      }
      // works differently than search
      return sort.field;
    }

    _writeQuestionIdToPayload(payload) {
      return {
        ...payload,
        _meta: trimObj({
          ...payload._meta,
          question_id: this._superworkflow._answer.questionId,
        }),
      };
    }

    // data //
    _defaultProcessData(data) {
      data = super._defaultProcessData(data);
      writeMisoIdToSession(data);
      return data;
    }

    // interactions //
    _defaultProcessInteraction(payload, args) {
      return this._superworkflow._defaultProcessInteraction(payload, args);
    }

    _defaultProcessInteraction0(payload, args) {
      return super._defaultProcessInteraction(payload, args);
    }

  }

  Object.assign(HybridSearchResults, {
    ROLES_OPTIONS: ROLES_OPTIONS$4,
  });

  function getSubworkflowByRole(role) {
    // TODO: ROLE.ERROR
    return HybridSearchResults.ROLES_OPTIONS.members.includes(role) ? 'results' : 'answer';
  }

  class HybridSearchViewsActor {

    constructor(workflow) {
      this._workflow = workflow;
      this._containers = new Set();
    }

    get(role) {
      return this._getSubviews(role).get(role);
    }

    addContainer(element) {
      if (this._containers.has(element)) {
        return;
      }
      this._containers.add(element);

      const { components } = element;
      for (const component of components) {
        this.addComponent(component);
      }
    }

    removeContainer(element) {
      for (const subworkflow of this._workflow._subworkflows) {
        subworkflow._views.removeContainer(element);
      }
      this._containers.delete(element);
    }

    addComponent(element) {
      this._getViewByElement(element).element = element;
      this._addContainerToSubviews(element._container, element);
    }

    removeComponent(element) {
      this._getViewByElement(element).element = undefined;
      this._removeContainerFromSubviewsIfNecessary(element._container);
    }

    updateComponentRole(element, oldRole, newRole) {
      // TODO
    }

    refreshElement(element) {
      const view = element.isContainer ? this._containers.get(element) : this._getViewByElement(element);
      view && view.refresh({ force: true });
    }

    // helpers //
    _getSubworkflow(role) {
      return this._workflow._getSubworkflow(getSubworkflowByRole(role));
    }

    _getAllSubviews() {
      return this._workflow._subworkflows.flatMap(subworkflow => subworkflow._views);
    }

    _getSubviews(role) {
      return this._getSubworkflow(role)._views;
    }

    _getViewByElement(element) {
      let { role } = element;
      if (!role) {
        throw new Error('Component must have a role');
      }
      return this.get(role);
    }

    _addContainerToSubviews(container, child) {
      if (!container) {
        return;
      }
      const { role } = child;
      const subviews = this._getSubviews(role);
      if (subviews._containers.has(container)) {
        return;
      }
      // check if the container is in other subviews
      for (const otherSubviews of this._getAllSubviews()) {
        if (otherSubviews === subviews) {
          continue;
        }
        if (otherSubviews._containers.has(container)) {
          // find the conflicting element
          for (const component of container.components) {
            if (otherSubviews.containsElement(component)) {
              throw new Error(`<${container.tagName.toLowerCase()}> cannot contain both <${component.tagName.toLowerCase()}> and <${child.tagName.toLowerCase()}>, for they don't share the same data lifecycle.`);
            }
          }
          throw new Error(`Failed to add container <${container.tagName.toLowerCase()}> with child component <${child.tagName.toLowerCase()}>.`);
        }
      }
      // add the container to the subviews
      subviews.addContainer(container);
    }

    _removeContainerFromSubviewsIfNecessary(container) {
      if (!container || container.components.length > 0) {
        return;
      }
      for (const subviews of this._getAllSubviews()) {
        subviews.removeContainer(container);
      }
    }

  }

  const DEFAULT_API_OPTIONS$3 = Object.freeze({
    group: GROUP$5.ASK,
    name: NAME$6.SEARCH,
    payload: {
      ...AnswerBasedWorkflow.DEFAULT_API_OPTIONS.payload,
      ...SearchBasedWorkflow.DEFAULT_API_OPTIONS.payload,
      source_fl: ['cover_image', 'url', 'created_at', 'updated_at', 'published_at', 'title'],
    },
  });

  const DEFAULT_LAYOUTS$3 = Object.freeze({
    ...AnswerBasedWorkflow.DEFAULT_LAYOUTS,
    ...SearchBasedWorkflow.DEFAULT_LAYOUTS,
    [ROLE.QUERY]: [SearchBoxLayout.type, { placeholder: '' }],
    [ROLE.QUESTION]: [TextLayout.type, { raw: true }],
  });

  const DEFAULT_TRACKERS$3 = Object.freeze({
    ...AnswerBasedWorkflow.DEFAULT_TRACKERS,
    ...SearchBasedWorkflow.DEFAULT_TRACKERS,
  });

  const DEFAULT_PAGINATION = Object.freeze({
    ...SearchBasedWorkflow.DEFAULT_PAGINATION,
    active: true,
  });

  const DEFAULT_AUTOCOMPLETE_OPTIONS$1 = Object.freeze({
    api: {
      group: GROUP$5.ASK,
      name: NAME$6.SEARCH_AUTOCOMPLETE,
      payload: {
        completion_fields: ['suggested_queries'],
      },
    },
  });

  const DEFAULT_OPTIONS$4 = Object.freeze({
    ...AnswerBasedWorkflow.DEFAULT_OPTIONS,
    ...SearchBasedWorkflow.DEFAULT_OPTIONS,
    api: DEFAULT_API_OPTIONS$3,
    layouts: DEFAULT_LAYOUTS$3,
    trackers: DEFAULT_TRACKERS$3,
    autocomplete: DEFAULT_AUTOCOMPLETE_OPTIONS$1,
    pagination: DEFAULT_PAGINATION,
  });

  const ROLES_OPTIONS$3 = Object.freeze({
    main: ROLE.PRODUCTS,
    members: Object.keys(DEFAULT_LAYOUTS$3),
    mappings: Object.freeze({
      ...AnswerBasedWorkflow.ROLES_OPTIONS.mappings,
      ...SearchBasedWorkflow.ROLES_OPTIONS.mappings,
    }),
  });

  class HybridSearch extends Workflow {

    constructor(plugin, client) {
      super({
        name: 'hybrid-search',
        plugin,
        client,
        roles: ROLES_OPTIONS$3,
        defaults: DEFAULT_OPTIONS$4,
      });
    }

    _initProperties(args) {
      super._initProperties(args);
      this._subworkflows = [
        this._answer = new HybridSearchAnswer(this),
        this._results = new HybridSearchResults(this),
      ];
    }

    _getSubworkflow(name) {
      switch (name) {
        case 'answer':
          return this._answer;
        case 'results':
          return this._results;
        default:
          throw new Error(`Invalid subworkflow: ${name}`);
      }
    }

    _initActors() {
      this._views = new HybridSearchViewsActor(this);
    }

    _initSession() {
      this._results._sessions.restart();
      this._answer._sessions.restart();
    }

    // configuration //
    useLink(fn, options) {
      this._answer.useLink(fn, options);
      return this;
    }

    // properties //
    get answer() {
      return this._answer;
    }

    get results() {
      return this._results;
    }

    get questionId() {
      return this._answer.questionId;
    }

    get filters() {
      return this._results._views.filters;
    }

    get autocomplete() {
      return this._answer.autocomplete;
    }

    // query //
    autoQuery(options) {
      this._answer.autoQuery(options);
    }

    query(args) {
      this._answer.query(args);
    }

    // interactions //
    _defaultProcessInteraction(payload, args) {
      payload = this._answer._defaultProcessInteraction0(payload, args);
      payload = this._results._defaultProcessInteraction0(payload, args);
      return payload;
    }

    // destroy //
    _destroy() {
      for (const subworkflow of this._subworkflows) {
        subworkflow.destroy();
      }
      super._destroy();
    }

  }

  makeConfigurable(HybridSearch.prototype, [WORKFLOW_CONFIGURABLE.PAGINATION, WORKFLOW_CONFIGURABLE.FILTERS]);

  const DEFAULT_API_OPTIONS$2 = Object.freeze({
    ...Workflow.DEFAULT_API_OPTIONS,
    group: GROUP$5.ASK,
    name: NAME$6.RELATED_QUESTIONS,
  });

  const DEFAULT_LAYOUTS$2 = Object.freeze({
    ...Workflow.DEFAULT_LAYOUTS,
    [ROLE.RELATED_QUESTIONS]: [ListLayout.type, { itemType: 'question', link: { rel: 'noopener nofollow' } }],
    [ROLE.QUERY]: [SearchBoxLayout.type, { placeholder: 'Ask a question' }],
  });

  const DEFAULT_TRACKERS$2 = Object.freeze({
    ...Workflow.DEFAULT_TRACKERS,
    [ROLE.RELATED_QUESTIONS]: DEFAULT_TRACKER_OPTIONS$1,
    [ROLE.CONTAINER]: {
      ...DEFAULT_TRACKER_OPTIONS$1,
      itemless: true,
    },
    [ROLE.QUERY]: {
      [EVENT_TYPE.SUBMIT]: {
        active: true,
      },
    },
  });

  const DEFAULT_OPTIONS$3 = Object.freeze({
    ...Workflow.DEFAULT_OPTIONS,
    api: DEFAULT_API_OPTIONS$2,
    layouts: DEFAULT_LAYOUTS$2,
    trackers: DEFAULT_TRACKERS$2,
  });

  const ROLES_OPTIONS$2 = mergeRolesOptions(Workflow.ROLES_OPTIONS, {
    main: ROLE.RELATED_QUESTIONS,
    members: Object.keys(DEFAULT_LAYOUTS$2),
  });

  class Explore extends Workflow {

    constructor(plugin, client) {
      super({
        name: 'explore',
        plugin,
        client,
        roles: ROLES_OPTIONS$2,
        defaults: DEFAULT_OPTIONS$3,
      });
    }

    _initProperties(args) {
      super._initProperties(args);
      this._productId = undefined;
      this._linkFn = undefined;
    }

    _initSubscriptions(args) {
      super._initSubscriptions(args);
      this._unsubscribes = [
        ...this._unsubscribes,
        this._views.get(ROLE.RELATED_QUESTIONS).on('click', event => this._handleRelatedQuestionClick(event)),
        this._hub.on(query$1(), args => this._query(args)),
      ];
    }

    // configuration //
    set productId(value) {
      console.warning('DEPRECATED: use useApi() instead');
      this.useApi({
        product_id: value,
      });
    }

    useApi(options) {
      const { product_id } = options;
      if (product_id) {
        this._productId = product_id;
      }
      return super.useApi(options);
    }

    useLink(fn, options) {
      UseLinkMixin.prototype.useLink.call(this, fn, options);
      // also put options to layouts
      if (options) {
        this.useLayouts({
          [ROLE.RELATED_QUESTIONS]: { link: options },
        });
      }
      return this;
    }

    // lifecycle //
    start({ relatedQuestions = true } = {}) {
      if (this._linkFn === undefined) {
        throw new Error('Must define link mapping function with useLink(fn) before calling start()');
      }
      // in explore workflow, start() triggers query
      // TODO: we should still make the query lifecycle
      if (relatedQuestions) {
        this._request();
      } else {
        // TODO: ad-hoc
        const { session } = this;
        this.updateData({ session, request: {}, value: { related_questions: [] } });
      }
      return this;
    }

    notifyViewUpdate(role = ROLE.RELATED_QUESTIONS, ...args) {
      super.notifyViewUpdate(role, ...args);
      return this;
    }

    _defaultProcessData(data) {
      data = super._defaultProcessData(data);
      data = this._addUrlToRelatedQuestions(data);
      return data;
    }

    _addUrlToRelatedQuestions(data) {
      const { value } = data;
      if (!value || !value.related_questions) {
        return data;
      }
      const linkFn = this._linkFn && this._linkFn[0];
      const related_questions = value.related_questions.map(linkFn ? (text => ({ text, url: this._getSubmitUrl({ q: text, generated: true }) })) : (text => ({ text })));
      return {
        ...data,
        value: {
          ...value,
          related_questions,
        },
      };
    }

    _handleRelatedQuestionClick({ value: question, ...event }) {
      this._events.emit('select', Object.freeze({ ...event, question }));
    }

    query(args) {
      if (!args.q) {
        throw new Error(`q is required in query() call`);
      }
      this._hub.update(query$1(), args);
    }

    _query(args) {
      this._submitToPage({ ...args, generated: false });
    }

    _getSubmitUrl(args) {
      let url = UseLinkMixin.prototype._getSubmitUrl.call(this, args);
      if (!args.generated || !this._productId) {
        return url;
      }
      return `${url}&qs=${encodeURIComponent(this._productId)}`;
    }

  }

  enableUseLink(Explore.prototype);

  const DEFAULT_API_OPTIONS$1 = Object.freeze({
    group: GROUP$5.SEARCH,
    name: NAME$6.SEARCH,
    payload: {
      fl: ['*'],
    },
  });

  const DEFAULT_AUTOCOMPLETE_OPTIONS = Object.freeze({
    api: {
      group: GROUP$5.SEARCH,
      name: NAME$6.AUTOCOMPLETE,
      payload: {
        completion_fields: ['suggested_queries', 'title'],
        fl: ['title', 'url', 'cover_image'],
      },
    },
  });

  const DEFAULT_LAYOUTS$1 = Object.freeze({
    ...SearchBasedWorkflow.DEFAULT_LAYOUTS,
  });

  const DEFAULT_TRACKERS$1 = Object.freeze({
    ...SearchBasedWorkflow.DEFAULT_TRACKERS,
  });

  const DEFAULT_OPTIONS$2 = Object.freeze({
    ...SearchBasedWorkflow.DEFAULT_OPTIONS,
    api: DEFAULT_API_OPTIONS$1,
    autocomplete: DEFAULT_AUTOCOMPLETE_OPTIONS,
    layouts: DEFAULT_LAYOUTS$1,
    trackers: DEFAULT_TRACKERS$1,
  });

  const ROLES_OPTIONS$1 = SearchBasedWorkflow.ROLES_OPTIONS;

  class Search extends SearchBasedWorkflow {

    constructor(plugin, client) {
      super({
        name: 'search',
        plugin,
        client,
        roles: ROLES_OPTIONS$1,
        defaults: DEFAULT_OPTIONS$2,
      });
    }

    _initProperties(args) {
      super._initProperties(args);
      this._initAutocomplete(args);
    }

    notifyViewUpdate(role = ROLE.PRODUCTS, ...args) {
      super.notifyViewUpdate(role, ...args);
      return this;
    }

    // destroy //
    _destroy(options) {
      this._destroyAutocomplete();
      super._destroy(options);
    }

  }

  makeAutocompletable(Search.prototype);

  const DEFAULT_API_OPTIONS = Object.freeze({
    ...Workflow.DEFAULT_API_OPTIONS,
    group: GROUP$5.RECOMMENDATION,
    name: NAME$6.USER_TO_PRODUCTS,
    payload: {
      ...Workflow.DEFAULT_API_OPTIONS.payload,
      fl: ['*'],
    },
  });

  const DEFAULT_LAYOUTS = Object.freeze({
    ...Workflow.DEFAULT_LAYOUTS,
    [ROLE.PRODUCTS]: ListLayout.type,
  });

  const DEFAULT_TRACKERS = Object.freeze({
    ...Workflow.DEFAULT_TRACKERS,
    [ROLE.PRODUCTS]: DEFAULT_TRACKER_OPTIONS$1,
  });

  const DEFAULT_OPTIONS$1 = Object.freeze({
    ...Workflow.DEFAULT_OPTIONS,
    api: DEFAULT_API_OPTIONS,
    layouts: DEFAULT_LAYOUTS,
    trackers: DEFAULT_TRACKERS,
  });

  const ROLES_OPTIONS = mergeRolesOptions(Workflow.ROLES_OPTIONS, {
    main: ROLE.PRODUCTS,
    members: Object.keys(DEFAULT_LAYOUTS),
  });

  class Recommendation extends Workflow {

    constructor(context, id) {
      super({
        name: 'recommendation',
        context,
        roles: ROLES_OPTIONS,
        defaults: DEFAULT_OPTIONS$1,
        id,
      });
    }

    _initProperties(args) {
      super._initProperties(args);
      const { id } = args;
      defineValues(this, { id });
    }

    _initSession(args) {
      this._context._members.set(args.id, this);
      super._initSession(args);
    }

    // lifecycle //
    start() {
      // in recommendation workflow, start() triggers query
      this._request();
      return this;
    }

    notifyViewUpdate(role = ROLE.PRODUCTS, ...args) {
      super.notifyViewUpdate(role, ...args);
      return this;
    }

    // interactions //
    _defaultProcessInteraction(payload, args) {
      payload = super._defaultProcessInteraction(payload, args);
      payload = this._writeUnitIdToInteraction(payload, args);
      return payload;
    }

    _writeUnitIdToInteraction(payload) {
      const unit_id = this.id;
      const unit_instance_uuid = this.uuid;
      return mergeInteraction(payload, {
        context: {
          custom_context: {
            unit_id,
            unit_instance_uuid,
          },
        },
      });
    }

    // destroy //
    _destroy(options) {
      this._context._members.delete(this.id);
      super._destroy(options);
    }

  }

  class Recommendations extends WorkflowContext {

    constructor(plugin, client) {
      super('recommendations', plugin, client);
      this._members = new Map();
    }

    workflows() {
      return [...this._members.values()];
    }

    create(unitId = DEFAULT_UNIT_ID) {
      if (this._members.has(unitId)) {
        throw new Error(`Unit already exists: ${unitId}`);
      }
      return new Recommendation(this, unitId);
    }

    has(unitId = DEFAULT_UNIT_ID) {
      return this._members.has(unitId);
    }

    get(unitId = DEFAULT_UNIT_ID) {
      if (typeof unitId !== 'string') {
        throw new Error(`Required unit ID to be a string: ${unitId}`);
      }
      return this._members.get(unitId) || new Recommendation(this, unitId);
    }

  }

  let Combo$1 = class Combo extends Component {
    
    constructor({
      name,
      plugin,
      MisoClient,
      ...options
    }) {
      super(name || 'combo', plugin);
      this._name = name;
      this._plugin = plugin;
      this._MisoClient = MisoClient;
      this._options = options;
    }

    get MisoClient() {
      return this._MisoClient;
    }

    get element() {
      return this._element;
    }

    async waitForElement() {
      return this._element || (this._elementRes || (this._elementRes = new Resolution())).promise;
    }

    set element(element) {
      // TODO: guard against multiple element assignment
      this._element = element;
      this._elementRes && this._elementRes.resolve(element);
    }

    start(options) {
      if (this._started) {
        return;
      }
      this._started = true;
      if (options) {
        this.config(options);
      }
      this._start();
    }

    _start() {
      throw new Error('Unimplemented');
    }

  };

  const CLASS_PREFIX$1 = 'miso-ask-combo';
  const CONAINER_TAG$1 = 'miso-ask';

  var _constants$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    CLASS_PREFIX: CLASS_PREFIX$1,
    CONAINER_TAG: CONAINER_TAG$1
  });

  /**
   * The phrase displayed right before <miso-question>
   */
  const question$1 = 'You asked...';

  /**
   * The phrase displayed right before <miso-sources>
   */
  const sources$1 = 'This reply is based on the following articles';

  /**
   * The phrase displayed right before <miso-query-suggestions>
   */
  const querySuggestions = 'Related questions you can explore';

  /**
   * The phrase displayed right before <miso-related-resources>
   */
  const relatedResources = 'Go beyond, and learn more about this topic';

  var _phrases$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    querySuggestions: querySuggestions,
    question: question$1,
    relatedResources: relatedResources,
    sources: sources$1
  });

  // TODO: rename classPrefix -> rootClass?
  // TODO: placeholder

  let Sections$2 = class Sections {

    constructor({ helpers }) {
      this._helpers = helpers;
    }

    errorSection(options) {
      const { section, container } = this._helpers;
      return section(options, { name: 'error' }, [
        container(options, { name: 'error', visibleWhen: 'erroneous' }, '<miso-error></miso-error>'),
      ]);
    }

    answerGroup(options) {
      return [
        this.answer(options),
        this.affiliation(options),
        this.sources(options),
      ];
    }

    answer(options) {
      const { container } = this._helpers;
      return container(options, { name: 'answer', visibleWhen: 'ready' }, [
        ...this.question(options),
        '<miso-answer></miso-answer>',
        '<miso-feedback></miso-feedback>',
      ]);
    }

    question(options) {
      const { phrase } = this._helpers;
      return [
        phrase(options, { name: 'question', tag: 'div' }),
        '<miso-question></miso-question>',
      ];
    }

    sources(options) {
      const { container, phrase } = this._helpers;
      return container(options, { name: 'sources', visibleWhen: 'nonempty' }, [
        phrase(options, { name: 'sources', tag: 'h3' }),
        '<miso-sources></miso-sources>',
      ]);
    }

    affiliation(options) {
      const { container } = this._helpers;
      const { affiliation = true } = options || {};
      if (!affiliation) {
        return '';
      }
      return container(options, { name: 'affiliation', visibleWhen: 'nonempty' }, [
        '<miso-affiliation></miso-affiliation>',
      ]);
    }

  };

  class Helpers {

    constructor(context) {
      this._context = context;
      defineValues(this, { lowerCamelToKebab, kebabToLowerCamel, kebabOrSnakeToLowerCamel });
    }

    // options //
    normalizeOptions({
      classPrefix,
      circledCitationIndex = true,
      phrases,
      ...options
    } = {}) {
      classPrefix = classPrefix || this._context.CLASS_PREFIX;
      phrases = this.normalizePhraseOptions(phrases);
      return { classPrefix, circledCitationIndex, phrases, ...options };
    }

    normalizePhraseOptions(options = {}) {
      if (!options) {
        return {};
      }
      const normalized = {};
      for (const key in options) {
        normalized[this.normalizePhraseOptionKey(key)] = options[key];
      }
      return normalized;
    }

    normalizePhraseOptionKey(key) {
      key = kebabOrSnakeToLowerCamel(key);
      if (key === 'relatedQuestions') {
        return 'querySuggestions'; // legacy key
      }
      return key;
    }

    // html //
    phrase(options, { name, tag = 'div', inline = false }) {
      const { classPrefix } = options;
      const mainClass = inline ? `${classPrefix}__phrase-inline` : `${classPrefix}__phrase`;
      return `<${tag} class="${mainClass} ${classPrefix}__${name}-phrase">${this.phraseText(options, kebabToLowerCamel(name))}</${tag}>`;
    }

    phraseText(options, key) {
      const { phrases = {} } = options;
      const fn = phrases[key] || this._context.DEFAULT_PHRASES[key];
      switch (typeof fn) {
        case 'function':
          return fn(options);
        case 'string':
          return fn;
        default:
          return '';
      }
    }

    section({ classPrefix }, { name }, body) {
      return this.element('section', {
        classes: [`${classPrefix}__section`, `${classPrefix}__${name}`],
      }, body);
    }

    container({ classPrefix, circledCitationIndex, parentQuestionId }, { name, visibleWhen, logo = false }, body) {
      const classes = [`${classPrefix}__${name}-container`];
      circledCitationIndex && classes.push('miso-circled-citation-index');
      return this.element(this._context.CONAINER_TAG, { classes, visibleWhen, logo, parentQuestionId }, body);
    }

    element(tag, attributes = {}, body = '') {
      return `<${tag}${this.attrs(attributes)}>${Array.isArray(body) ? body.join('') : body}</${tag}>`;
    }

    attrs({ classes = [], ...attributes } = {}) {
      let str = ``;
      if (classes.length) {
        str += ` class="${classes.join(' ')}"`;
      }
      for (const name in attributes) {
        const value = attributes[name];
        if (value !== undefined) {
          str += ` ${lowerCamelToKebab(name)}="${value}"`;
        }
      }
      return str;
    }

  }

  let Sections$1 = class Sections extends Sections$2 {

    constructor() {
      super({ helpers: helpers$1 });
    }

    answerGroup(options) {
      const { container } = this._helpers;
      return [
        ...super.answerGroup(options),
        container(options, { name: 'bottom-spacing', visibleWhen: 'ongoing' }),
      ];
    }

    answer(options) {
      const { container } = this._helpers;
      return container(options, { name: 'answer', visibleWhen: 'ready' }, [
        options.parentQuestionId ? '<hr>' : '',
        ...this.question(options),
        '<miso-answer></miso-answer>',
        '<miso-feedback></miso-feedback>',
      ]);
    }

    sources(options) {
      const { container, phrase } = this._helpers;
      return container(options, { name: 'sources', visibleWhen: 'nonempty' }, [
        '<hr>',
        phrase(options, { name: 'sources', tag: 'h3' }),
        '<miso-sources></miso-sources>',
      ]);
    }

    followUps(options) {
      const { classPrefix, features = {} } = options;
      return features.followUpQuestions === false ? '' : `<div id="${classPrefix}__follow-ups" class="${classPrefix}__follow-ups"></div>`;
    }

    relatedResourcesSection(options) {
      const { container, phrase, section } = this._helpers;
      const { features = {}, logo = true } = options;
      const body = features.relatedResources === false ? '' : container(options, { name: 'related-resources', visibleWhen: 'nonempty', logo }, [
        phrase(options, { name: 'related-resources', tag: 'h2' }),
        '<miso-related-resources></miso-related-resources>',
      ]);
      return section(options, { name: 'related-resources' }, body);
    }

    querySuggestions(options) {
      const { container, phrase } = this._helpers;
      const { features = {} } = options;
      return features.querySuggestions === false ? '' :
        container(options, { name: 'query-suggestions', visibleWhen: 'initial+nonempty' }, [
          phrase(options, { name: 'query-suggestions', tag: 'h3' }),
          '<miso-query-suggestions></miso-query-suggestions>',
        ]);
    }

  };

  const helpers$1 = externalize(new Helpers({ ..._constants$1, DEFAULT_PHRASES: _phrases$1 }));
  const sections$1 = externalize(new Sections$1({ helpers: helpers$1 }));

  function root$1(options = {}) {
    const { normalizeOptions, section, container } = helpers$1;
    const { followUps, relatedResourcesSection, answerGroup } = sections$1;
    options = normalizeOptions(options);
    return [
      section(options, { name: 'question' }, [
        container(options, { name: 'query' }, '<miso-query></miso-query>'),
      ]),
      section(options, { name: 'answer' }, answerGroup(options)),
      followUps(options),
      relatedResourcesSection(options),
    ].join('');
  }
  function followUp(options = {}) {
    const { normalizeOptions, section, container } = helpers$1;
    const { querySuggestions, answerGroup } = sections$1;
    options = normalizeOptions(options);
    return section(options, { name: 'follow-up' }, [
      querySuggestions(options),
      container(options, { name: 'query', visibleWhen: 'initial loading' }, '<miso-query></miso-query>'),
      ...answerGroup(options),
    ]);
  }

  var _templates$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    followUp: followUp,
    helpers: helpers$1,
    root: root$1,
    sections: sections$1
  });

  function wireFollowUps(client, element, { template = followUp, ...options } = {}) {
    if (!client) {
      throw new Error('client is required');
    }
    if (typeof template !== 'function') {
      throw new Error('template must be a function or undefined');
    }
    if (!element) {
      return;
    }
    const context = client.ui.asks;
    const rootWorkflow = client.ui.ask;

    // 1. when an answer is fully populated, insert a new section for the follow-up question
    context.on('done', (event) => {
      element.insertAdjacentHTML('beforeend', template({ ...options, parentQuestionId: event.workflow.questionId }));
    });
    // 2. if user starts over, clean up existing follow-up questions
    rootWorkflow.on('loading', () => {
      // clean up the entire follow-ups section
      element.innerHTML = '';
      // destroy all follow-up workflows
      context.reset({ root: false });
    });
  }

  function wireRelatedResources(client, element) {
    if (!client) {
      throw new Error('client is required');
    }
    if (!element) {
      return;
    }
    client.ui.asks.on('loading', (event) => {
      // When a new query starts, associate the last section container (for related resources) to that workflow
      for (const container of element.querySelectorAll('miso-ask')) {
        container.workflow = event.workflow;
      }
    });
  }

  const constants$1 = Object.freeze(_constants$1);
  const phrases$1 = Object.freeze(_phrases$1);
  const templates$1 = Object.freeze(_templates$1);

  var _ask = /*#__PURE__*/Object.freeze({
    __proto__: null,
    constants: constants$1,
    phrases: phrases$1,
    templates: templates$1,
    wireFollowUps: wireFollowUps,
    wireRelatedResources: wireRelatedResources
  });

  // TODO: generalize

  const { currentScript } = document;

  const DEFAULT_OPTIONS = Object.freeze({
    templates: templates$1,
    autostart: true,
  });

  const GROUPS = ['templates', 'phrases', 'features'];

  class AskComboOptions {

    constructor() {
      this._defaults = DEFAULT_OPTIONS;
      this._scriptSrc = readFromScriptSrc();
      this._pageUrl = readFromPageUrl();
    }

    resolve(options) {
      return normalizeOptions(mergeOptions(this._defaults, this._scriptSrc, options, this._pageUrl));
    }

  }

  function mergeOptions(...optionsList) {
    let merged = {};
    for (const options of optionsList) {
      if (options) {
        merged = mergeTwoOptions(merged, options);
      }
    }
    return merged;
  }

  function mergeTwoOptions(merged, overrides) {
    if (!overrides) {
      return merged;
    }
    Object.assign(merged, overrides);
    for (const key of GROUPS) {
      if (key in overrides) {
        merged[key] = { ...merged[key], ...overrides[key] };
      }
    }
    return merged;
  }

  function normalizeOptions({ api_key: apiKey, api_host: apiHost, templates, phrases, ...options } = {}) {
    return trimObj({
      apiKey,
      apiHost,
      templates: templateAsFunction(templates),
      phrases,
      ...options,
    });
  }

  /**
   * Get parameters from script src attribute.
   * - 'q' is ignored.
   */
  function readFromScriptSrc() {
    if (!currentScript || !currentScript.src) {
      return {};
    }
    const anchor = document.createElement('a');
    anchor.href = currentScript.src;

    const params = {};
    for (const [key, value] of new URLSearchParams(anchor.search)) {
      if (key === 'q') {
        continue;
      }
      params[key] = coerceValue(value);
    }
    return params;
  }

  /**
   * Get parameters from page URL with `miso_` prefix.
   * - 'q' is not prefixed.
   * - 'miso_api_key' is ignored.
   */
  function readFromPageUrl() {
    const params = {};
    for (const [key, value] of new URLSearchParams(window.location.search)) {
      if (key.startsWith('miso_') && key.length > 5 && key !== 'miso_api_key') {
        params[key.substring(5)] = coerceValue(value);
      } else if (key === 'q') {
        params.q = value;
      }
    }
    return params;
  }

  function coerceValue(value) {
    return value === '' ? true : value === 'false' ? false : value;
  }

  function templateAsFunction(value) {
    if (value === undefined || value === null) {
      return value;
    }
    switch (typeof value) {
      case 'function':
        return value;
      case 'string':
      case 'number':
        return () => value;
      case 'object':
        return Array.isArray(value) ? value.map(templateAsFunction) : mappingObjectValues(value, templateAsFunction);
      default:
        throw new Error(`Unsupported template type: ${value}`);
    }
  }

  function mappingObjectValues(obj, fn) {
    const mapped = {};
    for (const [key, value] of Object.entries(obj)) {
      mapped[key] = fn(value);
    }
    return mapped;
  }

  class AskComboElements {

    constructor(root, { classPrefix = constants$1.CLASS_PREFIX } = {}) {
      if (!root) {
        throw new Error('Root element is required');
      }
      defineValues(this, {
        root,
        followUpsSection: root.querySelector(`.${classPrefix}__follow-ups`),
        relatedResourcesSection: root.querySelector(`.${classPrefix}__related-resources`),
        relatedResourcesContainer: root.querySelector(`.${classPrefix}__related-resources miso-ask`),
      });
    }

  }

  class AskCombo extends Combo$1 {

    constructor(plugin, MisoClient) {
      super({
        name: 'ask-combo',
        plugin,
        MisoClient,
      });
      // TODO: extract options to super class
      this._options = new AskComboOptions();
      this._localOptions = {};
    }

    config(options = {}) {
      options = mergeOptions(this._localOptions, options);
      const resolvedOptions = this._options.resolve(options);

      // verify
      // TODO

      this._localOptions = options;
      this._resolvedOptions = resolvedOptions;
      return this;
    }

    get resolvedOptions() {
      return this._resolvedOptions || (this._resolvedOptions = this._options.resolve(this._localOptions));
    }

    get client() {
      return this._client;
    }

    get elements() {
      return this._elements;
    }

    autoStart() {
      this.resolvedOptions.autostart && this.start();
    }

    async _start() {
      await waitForDomContentLoaded();
      await this.waitForElement();

      // setup MisoClient
      await this._setupMisoClient();
      
      // render elements for root question
      this._renderRootContent();

      // create client instance
      this._createClientInstance();

      // setup workflows
      this._setupWorkflows();
    }

    async _setupMisoClient() {
      const { MisoClient, resolvedOptions: options } = this;
      const { version } = MisoClient;

      defineValues(MisoClient, {
        name: 'miso-ask-combo',
      });

      // debug
      const debug = version === 'dev' || version.indexOf('beta') > 0 || options.debug;
      if (debug) {
        MisoClient.plugins.use('std:debug');
      }

      // dry run
      if (options.dry_run) {
        MisoClient.plugins.use('std:dry-run');
      }

      // lorem
      if (options.lorem) {
        await MisoClient.plugins.install('std:lorem');
      }
    }

    _renderRootContent() {
      const { element, resolvedOptions: options } = this;
      const { templates = {} } = options;
      element.innerHTML = templates.root(options);
      this._elements = new AskComboElements(element, options);
    }

    async _createClientInstance() {
      this._client = new MisoClient(this.resolvedOptions);
    }

    async _setupWorkflows() {
      const { MisoClient, client, elements, resolvedOptions: options } = this;
      const { wireFollowUps, wireRelatedResources } = MisoClient.ui.defaults.ask;
      const { templates = {}, features = {}, api } = options;

      const context = client.ui.asks;
      const rootWorkflow = client.ui.ask;

      if (api) {
        context.useApi(api);
      }

      // TODO: set placeholder if present in options

      if (features.followUpQuestions !== false) {
        wireFollowUps(client, elements.followUpsSection, { ...options, template: templates.followUp });
      }
      if (features.relatedResources !== false && features.followUpQuestions !== false) {
        wireRelatedResources(client, elements.relatedResourcesSection);
      }

      // start query if specified in URL
      rootWorkflow.autoQuery();
    }

  }

  class Layouts extends Registry {

    constructor(plugin) {
      super('layouts', plugin, {
        libName: 'layout',
        keyName: lib => lib.type,
      });
      this._plugin = plugin;
    }

    // TODO: API to override default options per layout

    get(name) {
      return this._libraries[name];
    }

    create(name, options) {
      if (name === false) {
        return undefined;
      }
      switch (typeof name) {
        case 'function':
          return { render: name };
        case 'string':
          const LayoutClass = this.get(name);
          if (!LayoutClass) {
            throw new Error(`Layout of name '${name}' not found.`);
          }
          return new LayoutClass(options);
        default:
          throw new Error(`Expect a string, a render function, or boolean value false: ${name}`);
      }
    }

  }

  let MisoClientPromise, clientPromise, client;

  async function getClient(ElementClass) {
    const MisoClient = await getMisoClient(ElementClass);
    clientPromise = clientPromise || MisoClient.any();
    client = client || await clientPromise;
    if (!client.ui) {
      await timeout(0);
    }
    return client;
  }

  async function getMisoClient(ElementClass) {
    // TODO: ElementClass.MisoClient should be enough
    return ElementClass.MisoClient || window.MisoClient || MisoClientPromise || (MisoClientPromise = waitForMisoClient());
  }

  async function waitForMisoClient() {
    return new Promise((resolve) => {
      const misocmd = window.misocmd || (window.misocmd = []);
      misocmd.push(() => resolve(window.MisoClient));
    });
  }

  function getContainer(element) {
    for (let node = element; node; node = node.parentNode) {
      if (node.isContainer) {
        return node;
      }
    }
    throw new Error(`${element.tagName} needs to be placed under a workflow container element.`);
  }

  function timeout(duration) {
    return new Promise(resolve => setTimeout(resolve, duration));
  }

  const ATTR_LOGO = 'logo';
  const DEFAULT_LOGO_VALUE = 'auto';
  const OBSERVED_ATTRIBUTES$3 = Object.freeze([ATTR_LOGO]);

  function logoAttrToProp(value) {
    if (!value) {
      return DEFAULT_LOGO_VALUE;
    }
    switch (value) {
      case 'true':
        return true;
      case 'false':
        return false;
      default:
        throw new Error(`Invalid logo attribute value: ${value}.`);
    }
  }

  function logoPropToAttr(value) {
    switch (value) {
      case DEFAULT_LOGO_VALUE:
        return undefined;
      case true:
        return 'true';
      case false:
        return 'false';
      default:
        throw new Error(`Invalid logo property value: ${value}.`);
    }
  }

  class MisoContainerElement extends HTMLElement {

    static get observedAttributes() {
      return OBSERVED_ATTRIBUTES$3;
    }

    constructor() {
      super();
      this._workflow = undefined;
      this._components = new Set();
    }

    // properties //
    get isContainer() {
      return true;
    }

    get workflow() {
      return this._workflow;
    }

    set workflow(workflow) {
      this._setWorkflow(workflow);
    }

    get logo() {
      return logoAttrToProp(this.getAttribute(ATTR_LOGO));
    }

    set logo(value) {
      if (this.logo === value) {
        return;
      }
      const attrValue = logoPropToAttr(value);
      if (attrValue) {
        this.setAttribute(ATTR_LOGO, attrValue);
      } else {
        this.removeAttribute(ATTR_LOGO);
      }
    }

    // lifecycle //
    async connectedCallback() {
      const client = this._client = await getClient(MisoContainerElement);
      if (document.body.contains(this)) { // in case already disconnected
        this._setWorkflow(this._getWorkflow(client));
      }
    }

    disconnectedCallback() {
      this._setWorkflow(undefined);
    }

    _getWorkflow(client) {
      throw new Error('Unimplemented');
    }

    _setWorkflow(workflow) {
      if (this._workflow === workflow) {
        return;
      }
      if (this._workflow) {
        this._workflow._views.removeContainer(this);
      }
      if (workflow) {
        workflow._views.addContainer(this);
      }
      this._workflow = workflow;
    }

    attributeChangedCallback(attr, oldValue, newValue) {
      switch (attr) {
        case ATTR_LOGO:
          this._handleLogoUpdate(oldValue, newValue);
          break;
      }
    }

    _handleLogoUpdate(oldAttrValue, newAttrValue) {
      const oldPropValue = logoAttrToProp(oldAttrValue);
      const newPropValue = logoAttrToProp(newAttrValue);
      if (oldPropValue === newPropValue || !this._workflow) {
        return;
      }
      this._workflow._views.refreshElement(this);
    }

    // components //
    get components() {
      return [...this._components];
    }

    _addComponent(element) {
      if (this._components.has(element)) {
        return;
      }
      this._components.add(element);
      this._workflow && this._workflow._views.addComponent(element);
    }

    _removeComponent(element) {
      if (!this._components.has(element)) {
        return;
      }
      this._workflow && this._workflow._views.removeComponent(element);
      this._components.delete(element);
    }

    _updateComponentRole(element, oldRole, newRole) {
      this._workflow && this._workflow._views.updateComponentRole(element, oldRole, newRole);
    }

  }

  const TAG_NAME$6 = 'miso-ask';

  const ATTR_PARENT_QUESTION_ID = 'parent-question-id';
  const OBSERVED_ATTRIBUTES$2 = Object.freeze([
    ...MisoContainerElement.observedAttributes,
    ATTR_PARENT_QUESTION_ID,
  ]);

  class MisoAskElement extends MisoContainerElement {

    static get tagName() {
      return TAG_NAME$6;
    }

    static get observedAttributes() {
      return OBSERVED_ATTRIBUTES$2;
    }

    _getWorkflow(client) {
      return this._getWorkflowByParentQuestionId(client, this.parentQuestionId);
    }

    _getWorkflowByParentQuestionId(client, id) {
      return client.ui.asks.getByParentQuestionId(id, { autoCreate: true });
    }

    // properties //
    get parentQuestionId() {
      return this.getAttribute(ATTR_PARENT_QUESTION_ID) || undefined;
    }

    set parentQuestionId(value) {
      value = value !== undefined ? `${value}` : undefined;
      if (value === this.parentQuestionId) {
        return;
      }
      if (value) {
        this.setAttribute(ATTR_PARENT_QUESTION_ID, value);
      } else {
        this.removeAttribute(ATTR_PARENT_QUESTION_ID);
      }
    }

    get workflow() {
      return this._workflow;
    }

    set workflow(workflow) {
      this._setWorkflow(workflow);
      this.parentQuestionId = workflow && workflow.parentQuestionId;
    }

    // lifecycle //
    attributeChangedCallback(attr, oldValue, newValue) {
      switch (attr) {
        case ATTR_PARENT_QUESTION_ID:
          this._handleParentQuestionIdUpdate(oldValue, newValue);
          break;
        default:
          super.attributeChangedCallback(attr, oldValue, newValue);
      }
    }

    _handleParentQuestionIdUpdate(oldId, newId) {
      oldId = oldId || undefined; // null -> undefined
      newId = newId || undefined;
      if (oldId === newId || !this._client) {
        return;
      }
      this._setWorkflow(this._getWorkflowByParentQuestionId(this._client, newId));
    }

  }

  const TAG_NAME$5 = 'miso-explore';

  class MisoExploreElement extends MisoContainerElement {

    static get observedAttributes() {
      return MisoContainerElement.observedAttributes;
    }

    static get tagName() {
      return TAG_NAME$5;
    }

    _getWorkflow(client) {
      return client.ui.explore;
    }

  }

  const TAG_NAME$4 = 'miso-hybrid-search';

  class MisoHybridSearchElement extends MisoContainerElement {

    static get observedAttributes() {
      return MisoContainerElement.observedAttributes;
    }

    static get tagName() {
      return TAG_NAME$4;
    }

    _getWorkflow(client) {
      return client.ui.hybridSearch;
    }

  }

  const TAG_NAME$3 = 'miso-search';

  class MisoSearchElement extends MisoContainerElement {

    static get observedAttributes() {
      return MisoContainerElement.observedAttributes;
    }

    static get tagName() {
      return TAG_NAME$3;
    }

    _getWorkflow(client) {
      return client.ui.search;
    }

  }

  const TAG_NAME$2 = 'miso-recommendation';

  const ATTR_UNIT_ID = 'unit-id';
  const OBSERVED_ATTRIBUTES$1 = Object.freeze([
    ...MisoContainerElement.observedAttributes,
    ATTR_UNIT_ID,
  ]);

  class MisoRecommendationElement extends MisoContainerElement {

    static get tagName() {
      return TAG_NAME$2;
    }

    static get observedAttributes() {
      return OBSERVED_ATTRIBUTES$1;
    }

    _getWorkflow(client) {
      return this._getWorkflowByUnitId(client, this.unitId);
    }

    _getWorkflowByUnitId(client, unitId) {
      return client.ui.recommendations.get(unitId);
    }

    // properties //
    get unitId() {
      return this.getAttribute(ATTR_UNIT_ID) || undefined;
    }

    set unitId(value) {
      value = value && `${value}`;
      if (value) {
        this.setAttribute(ATTR_UNIT_ID, value);
      } else {
        this.removeAttribute(ATTR_UNIT_ID);
      }
    }

    // lifecycle //
    attributeChangedCallback(attr, oldValue, newValue) {
      switch (attr) {
        case ATTR_UNIT_ID:
          this._handleUnitIdUpdate(oldValue, newValue);
          break;
        default:
          super.attributeChangedCallback(attr, oldValue, newValue);
      }
    }

    _handleUnitIdUpdate(oldUnitId, newUnitId) {
      if (oldUnitId === newUnitId || !this._client) {
        return;
      }
      this._setWorkflow(this._getWorkflowByUnitId(this._client, newUnitId));
    }

  }

  var index$3 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    MisoAskElement: MisoAskElement,
    MisoExploreElement: MisoExploreElement,
    MisoHybridSearchElement: MisoHybridSearchElement,
    MisoRecommendationElement: MisoRecommendationElement,
    MisoSearchElement: MisoSearchElement
  });

  const TAG_NAME$1 = 'miso-component';

  const ATTR_ROLE = 'role';

  const OBSERVED_ATTRIBUTES = Object.freeze([ATTR_ROLE]);

  class MisoComponentElement extends HTMLElement {

    static get tagName() {
      return TAG_NAME$1;
    }

    static get observedAttributes() {
      return OBSERVED_ATTRIBUTES;
    }

    constructor({
      role,
    } = {}) {
      super();
      if (role) {
        Object.defineProperty(this, '_role', {
          value: role,
          writable: false, // predefined role is immutable
        });
      }
    }

    get role() {
      return this._role;
    }

    // lifecycle //
    connectedCallback() {
      const container = getContainer(this);
      if (this._container && this._container !== container) {
        // clean up, just in case
        this._container._removeComponent(this);
      }
      this._syncRole();
      container._addComponent(this);
      this._container = container;
      this._containerResolution && this._containerResolution.resolve(container);
    }

    _syncRole() {
      const roleAttr = this.getAttribute(ATTR_ROLE);
      if (!roleAttr) {
        if (!this._role) {
          // no predefined role, no role attribute
          throw new Error(`An attribute '${ATTR_ROLE}' is required for element <${this.tagName}>`);
        }
        return; // has predefined role, no role attribute: we're all good
      } else {
        if (this._role) {
          // both predefined role and role attribute, ignore the latter and give a warning
          console.warn(`Element <${this.tagName}>' already has a predefined role '${this._role}', so attribute '${ATTR_ROLE}="${roleAttr}"' is ignored.`);
        } else {
          // no predefined role, has role attribute: assign the role
          this._role = roleAttr;
        }
      } 
    }

    disconnectedCallback() {
      if (!this._container) {
        return;
      }
      this._container._removeComponent(this);
      this._container = undefined;
      this._containerResolution = undefined;
    }

    attributeChangedCallback(attr, oldValue, newValue) {
      if (oldValue === newValue) {
        return;
      }
      if (attr === ATTR_ROLE) {
        this._container && this._container._updateComponentRole(this, oldValue, newValue);
      }
    }

  }

  class MisoQueryElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.QUERY,
      });
    }

    static get tagName() {
      return 'miso-query';
    }

  }

  class MisoQuerySuggestionsElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.QUERY_SUGGESTIONS,
      });
    }

    static get tagName() {
      return 'miso-query-suggestions';
    }

  }

  class MisoFeedbackElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.FEEDBACK,
      });
    }

    static get tagName() {
      return 'miso-feedback';
    }

  }

  class MisoResultsElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.PRODUCTS,
      });
    }

    connectedCallback() {
      console.warn('Element <miso-results> is deprecated. Please use <miso-products> instead.');
      super.connectedCallback();
    }

    static get tagName() {
      return 'miso-results';
    }

  }

  class MisoProductsElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.PRODUCTS,
      });
    }

    static get tagName() {
      return 'miso-products';
    }

  }

  class MisoQuestionElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.QUESTION,
      });
    }

    static get tagName() {
      return 'miso-question';
    }

  }

  class MisoAnswerElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.ANSWER,
      });
    }

    static get tagName() {
      return 'miso-answer';
    }

  }

  class MisoSourcesElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.SOURCES,
      });
    }

    static get tagName() {
      return 'miso-sources';
    }

  }

  class MisoImagesElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.IMAGES,
      });
    }

    static get tagName() {
      return 'miso-images';
    }

  }

  class MisoRelatedResourcesElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.RELATED_RESOURCES,
      });
    }

    static get tagName() {
      return 'miso-related-resources';
    }

  }

  class MisoRelatedQuestionsElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.RELATED_QUESTIONS,
      });
    }

    static get tagName() {
      return 'miso-related-questions';
    }

  }

  class MisoAffiliationElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.AFFILIATION,
      });
    }

    static get tagName() {
      return 'miso-affiliation';
    }

  }

  class MisoKeywordsElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.KEYWORDS,
      });
    }

    static get tagName() {
      return 'miso-keywords';
    }

  }

  class MisoTotalElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.TOTAL,
      });
    }

    static get tagName() {
      return 'miso-total';
    }

  }

  class MisoFacetsElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.FACETS,
      });
    }

    static get tagName() {
      return 'miso-facets';
    }

  }

  class MisoMoreElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.MORE,
      });
    }

    static get tagName() {
      return 'miso-more';
    }

  }

  class MisoSortElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.SORT,
      });
    }

    static get tagName() {
      return 'miso-sort';
    }

  }

  class MisoErrorElement extends MisoComponentElement {

    constructor() {
      super({
        role: ROLE.ERROR,
      });
    }

    static get tagName() {
      return 'miso-error';
    }

  }

  var index$2 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    MisoAnswerElement: MisoAnswerElement,
    MisoComponentElement: MisoComponentElement,
    MisoErrorElement: MisoErrorElement,
    MisoFacetsElement: MisoFacetsElement,
    MisoFeedbackElement: MisoFeedbackElement,
    MisoImagesElement: MisoImagesElement,
    MisoKeywordsElement: MisoKeywordsElement,
    MisoMoreElement: MisoMoreElement,
    MisoProductsElement: MisoProductsElement,
    MisoQueryElement: MisoQueryElement,
    MisoQuerySuggestionsElement: MisoQuerySuggestionsElement,
    MisoQuestionElement: MisoQuestionElement,
    MisoRelatedQuestionsElement: MisoRelatedQuestionsElement,
    MisoRelatedResourcesElement: MisoRelatedResourcesElement,
    MisoResultsElement: MisoResultsElement,
    MisoSortElement: MisoSortElement,
    MisoSourcesElement: MisoSourcesElement,
    MisoSovrnAffiliationElement: MisoAffiliationElement,
    MisoTotalElement: MisoTotalElement
  });

  class MisoComboElement extends HTMLElement {

    constructor() {
      super();
    }

    // TODO: events

    // lifecycle //
    async connectedCallback() {
      if (document.body.contains(this)) { // in case already disconnected
        this._setCombo(this._getCombo(MisoComboElement.MisoClient));
      }
    }

    disconnectedCallback() {
    }

    _getCombo(MisoClient) {
      throw new Error('Unimplemented');
    }

    _setCombo(combo) {
      if (this._combo === combo) {
        return;
      }
      this._combo = combo;
      combo.element = this;
      combo.autoStart();
    }

  }

  const TAG_NAME = 'miso-ask-combo';

  class MisoAskComboElement extends MisoComboElement {

    static get tagName() {
      return TAG_NAME;
    }

    constructor() {
      super();
    }

    _getCombo(MisoClient) {
      return MisoClient.ui.combo.ask;
    }

  }

  var index$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    MisoAskComboElement: MisoAskComboElement
  });

  var elements = /*#__PURE__*/Object.freeze({
    __proto__: null,
    MisoBannerElement: MisoBannerElement,
    combos: index$1,
    containers: index$3,
    roles: index$2
  });

  const CLASS_PREFIX = 'miso-hybrid-search-combo';
  const CONAINER_TAG = 'miso-hybrid-search';

  var _constants = /*#__PURE__*/Object.freeze({
    __proto__: null,
    CLASS_PREFIX: CLASS_PREFIX,
    CONAINER_TAG: CONAINER_TAG
  });

  /**
   * The phrase to display <miso-question>
   */
  const question = 'You asked “${value}”';

  /**
   * The phrase displayed right before <miso-sources>
   */
  const sources = 'Sources';

  /**
   * The phrase to display <miso-keywords>
   */
  const keywords = 'You searched for “${value}”';

  /**
   * The phrase to display <miso-total>
   */
  const total = '${value} Results';

  const showMore = 'Show more';
  const showLess = 'Show less';

  var _phrases = /*#__PURE__*/Object.freeze({
    __proto__: null,
    keywords: keywords,
    question: question,
    showLess: showLess,
    showMore: showMore,
    sources: sources,
    total: total
  });

  class Sections extends Sections$2 {

    constructor() {
      super({ helpers });
    }

    answer(options) {
      const { container } = this._helpers;
      return container(options, { name: 'answer', visibleWhen: 'ready !unanswerable' }, [
        ...this.question(options),
        '<miso-answer></miso-answer>',
        '<miso-feedback></miso-feedback>',
      ]);
    }

    answerBox(options) {
      const { element } = this._helpers;
      const { classPrefix } = options;
      return element('div', { classes: [`${classPrefix}__answer-box`] }, [
        element('div', { classes: [`${classPrefix}__answer-box-inner`] }, this.answerGroup(options)),
        this.answerBoxToggle(options),
      ]);
    }

    question(options) {
      const { phrase } = this._helpers;
      return phrase(options, { name: 'question', tag: 'div' }).replaceAll('${value}', '<miso-question></miso-question>');
    }

    answerBoxToggle(options) {
      const { element } = this._helpers;
      const { classPrefix } = options;
      return element('div', { classes: [`${classPrefix}__answer-box-toggle-container`] }, [
        element('div', { classes: [`${classPrefix}__answer-box-toggle`], 'data-role': 'answer-box-toggle' }),
      ]);
    }

    searchResultsGroup(options) {
      const { container } = this._helpers;
      return container(options, { name: 'search-results', visibleWhen: 'loading ready' }, [
        this.searchResultsInfoGroup(options),
        this.searchResultsFilters(options),
        '<miso-products></miso-products>',
        this.more(options),
      ]);
    }

    searchResultsInfoGroup(options) {
      const { element } = this._helpers;
      const { classPrefix } = options;
      return element('div', { classes: [`${classPrefix}__search-results-info`] }, [
        this.keywords(options),
        this.total(options),
      ]);
    }

    searchResultsFilters(options) {
      const { element } = this._helpers;
      const { classPrefix } = options;
      return element('div', { classes: [`${classPrefix}__search-results-filters`] }, [
        '<miso-facets></miso-facets>',
      ]);
    }

    keywords(options) {
      const { phrase } = this._helpers;
      return phrase(options, { name: 'keywords', tag: 'div', inline: true }).replaceAll('${value}', '<miso-keywords></miso-keywords>');
    }

    total(options) {
      const { phrase } = this._helpers;
      return phrase(options, { name: 'total', tag: 'div', inline: true }).replaceAll('${value}', '<miso-total></miso-total>');
    }

    more(options) {
      if (!options.moreButton) {
        return '';
      }
      const { element } = this._helpers;
      const { classPrefix } = options;
      return element('div', { classes: [`${classPrefix}__search-results-more-container`] }, [
        '<miso-more></miso-more>',
      ]);
    }

  }

  const helpers = externalize(new Helpers({ ..._constants, DEFAULT_PHRASES: _phrases }));
  const sections = externalize(new Sections({ helpers }));

  function root(options = {}) {
    const { normalizeOptions, section, container } = helpers;
    options = normalizeOptions(options);
    const { answerBox, answerGroup, searchResultsGroup } = sections;
    const { answerBox: answerBoxOptions = true } = options;
    return [
      section(options, { name: 'question' }, [
        container(options, { name: 'query' }, '<miso-query></miso-query>'),
      ]),
      section(options, { name: 'answer' }, answerBoxOptions ? [ answerBox(options) ] : answerGroup(options)),
      section(options, { name: 'search-results' }, searchResultsGroup(options)),
    ].join('');
  }

  var _templates = /*#__PURE__*/Object.freeze({
    __proto__: null,
    helpers: helpers,
    root: root,
    sections: sections
  });

  const CLASS_OPEN = 'answer-box-open';
  const CLASS_SHOWN = 'answer-box-shown';
  const TOGGLE_BUTTON_SELECTOR = '[data-role="answer-box-toggle"]';

  class AnswerBox {

    constructor(client, element, { classPrefix = CLASS_PREFIX, phrases = {}, hideWhenUnanswerable = true } = {}) {
      this._client = client;
      this._workflow = client.ui.hybridSearch;
      this._element = element;
      this._classPrefix = classPrefix;
      this._phrases = phrases;
      this._hideWhenUnanswerable = hideWhenUnanswerable;
      this._init();
    }

    _init() {
      const element = this._element;
      const workflow = this._workflow;

      // expose widget API
      workflow.answerBox = this;
      workflow._unsubscribes.push(() => {
        if (workflow.answerBox === this) {
          this.destroy();
          workflow.answerBox = undefined;
        }
      });

      // handle toggle button clicks
      const callback = event => this._handleClick(event);
      element.addEventListener('click', callback);

      // sync state
      this._syncWofkflowStatus();
      this._syncButtonText();

      this._unsubscribes = [
        () => element.removeEventListener('click', callback),
        // cling to data rather than view, as we may miss view event when tab is inactive due to raf
        workflow._answer._hub.on(data(), () => this._syncWofkflowStatus()),
      ];
    }

    _handleClick({ target, button }) {
      // only left click
      if (button !== 0) {
        return;
      }
      if (target.closest(TOGGLE_BUTTON_SELECTOR)) {
        this.toggleOpen();
      }
    }

    _syncWofkflowStatus() {
      const { status } = this._workflow._answer;
      const { meta: { unanswerable = false } = {} } = this._workflow._answer._hub.states[data()];

      switch (status) {
        case STATUS.ERRONEOUS:
        case STATUS.READY:
          if (unanswerable && this._hideWhenUnanswerable) {
            this.hide();
          } else {
            this.show();
          }
          break;
        default:
          this.hide();
      }
    }

    _updateBoxStatus(method, className) {
      this._element.classList[method](`${this._classPrefix}__${className}`);
    }

    _syncButtonText() {
      const phrase = this.isOpen ? this._phrases.showLess || showLess : this._phrases.showMore || showMore;
      for (const button of this._element.querySelectorAll(TOGGLE_BUTTON_SELECTOR)) {
        button.textContent = phrase;
      }
    }

    _syncScroll() {
      if (!this.isOpen) {
        this._element.scrollIntoView({ behavior: 'smooth' });
      }
    }

    destroy() {
      for (const unsubscribe of this._unsubscribes) {
        unsubscribe();
      }
      const workflow = this._workflow;
      if (workflow && workflow.answerBox === this) {
        delete workflow.answerBox;
      }
    }

  }

  const GETTERS = {
    isOpen: CLASS_OPEN,
    shown: CLASS_SHOWN,
  };

  const METHODS = {
    toggleOpen: ['toggle', CLASS_OPEN],
    open: ['open', CLASS_OPEN],
    close: ['remove', CLASS_OPEN],
    toggleHidden: ['toggle', CLASS_SHOWN],
    show: ['add', CLASS_SHOWN],
    hide: ['remove', CLASS_SHOWN],
  };

  for (const [prop, className] of Object.entries(GETTERS)) {
    Object.defineProperty(AnswerBox.prototype, prop, {
      get() {
        return this._element.classList.contains(`${this._classPrefix}__${className}`);
      },
    });
  }

  for (const [method, [action, className]] of Object.entries(METHODS)) {
    AnswerBox.prototype[method] = function() {
      this._updateBoxStatus(action, className);
      if (className === CLASS_OPEN) {
        this._syncButtonText();
        this._syncScroll();
      }
    };
  }

  function wireAnswerBox(client, element, options = {}) {
    if (!client) {
      throw new Error('client is required');
    }
    if (!element) {
      return;
    }
    new AnswerBox(client, element, options);
  }

  const constants = Object.freeze(_constants);
  const phrases = Object.freeze(_phrases);
  const templates = Object.freeze(_templates);

  var _hybridSearch = /*#__PURE__*/Object.freeze({
    __proto__: null,
    constants: constants,
    phrases: phrases,
    templates: templates,
    wireAnswerBox: wireAnswerBox
  });

  const ask = Object.freeze(_ask);
  const hybridSearch = Object.freeze(_hybridSearch);

  var defaults = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ask: ask,
    hybridSearch: hybridSearch
  });

  const NAME = 'ui';

  let cssUrl;
  let stylesLoaded;

  async function loadStylesIfNecessary() {
    return stylesLoaded || (stylesLoaded = loadStyles$1(getCssUrl()));
  }

  // helpers //
  function getCssUrl() {
    return cssUrl || (cssUrl = resolveCssUrl(NAME));
  }

  const PLUGIN_ID = 'std:ui';

  class UiPlugin extends Component {

    static get id() {
      return PLUGIN_ID;
    }

    constructor() {
      super('ui');
      this.layouts = new Layouts(this);
      this._recommendations = new WeakMap();
      this._asks = new WeakMap();
      this._extensions = new WeakMap();
      this._ready = new Resolution();
    }

    async install(MisoClient, context) {
      context.addSubtree(this);
      MisoClient.on('create', this._injectClient.bind(this));

      const ui = { defaults };
      delegateGetters(ui, this, ['layouts', 'combo', 'ready']);
      defineValues(this, { MisoClient });
      defineValues(MisoClient, { ui });

      // combo
      this.combo = new Combo(this, MisoClient);

      // layouts
      const LayoutClasses = Object.values(layouts).filter(LayoutClass => LayoutClass.type);
      for (const LayoutClass of LayoutClasses) {
        LayoutClass.MisoClient = MisoClient; // TODO: find better way
      }
      for (const LayoutClass of LayoutClasses) {
        this.layouts.register(LayoutClass);
      }

      // custom elements
      const { containers, roles, combos, ...others } = elements;
      // containers must go first, so their APIs will be ready before children are defined
      const ElementClasses = [
        ...Object.values(combos),
        ...Object.values(containers),
        ...Object.values(roles),
        ...Object.values(others),
      ];
      MisoContainerElement.MisoClient = MisoClient;
      MisoComboElement.MisoClient = MisoClient;
      for (const ElementClass of ElementClasses) {
        ElementClass.MisoClient = MisoClient; // TODO: find better way
      }

      // load styles
      await loadStylesIfNecessary();

      // define custom elements
      for (const ElementClass of ElementClasses) {
        defineAndUpgrade(ElementClass);
      }

      this._ready.resolve();
    }

    async requireExtension(name) {
      switch (name) {
        case 'markdown':
          return await this.MisoClient.plugins.install('std:ui-markdown');
        default:
          throw new Error(`Unknown extension: ${name}`);
      }
    }

    get ready() {
      return Promise.all([
        this._ready.promise,
        MisoClient.any(), // TODO: we need to wait for element connection
      ]).then(() => {});
    }

    _injectClient(client) {
      defineValues(client, {
        ui: new Ui(this, client),
      });
    }

    _getExtensions(client) {
      if (this._extensions.has(client)) {
        return this._extensions.get(client);
      }
      const extensions = new Extensions(this, client);
      this._extensions.set(client, extensions);
      return extensions;
    }

    _getRecommendations(client) {
      let recommendations = this._recommendations.get(client);
      if (!recommendations) {
        this._recommendations.set(client, recommendations = new Recommendations(this, client));
      }
      return recommendations;
    }

    _getAsks(client) {
      let asks = this._asks.get(client);
      if (!asks) {
        this._asks.set(client, asks = new Asks(this, client));
      }
      return asks;
    }

  }

  class Extensions {

    constructor(plugin, client) {
      this._plugin = plugin;
      this._client = client;
      this._contexts = {};
    }

    async require(name) {
      if (this._contexts[name]) {
        return this._contexts[name];
      }
      const plugin = await this._plugin.requireExtension(name);
      const context = this._contexts[name] = plugin.getContext(this._client);
      return context;
    }

  }

  class Ui {

    constructor(plugin, client) {
      this._plugin = plugin;
      this._client = client;

      defineValues(this, {
        sources: {
          api: api(client),
        },
      });
    }

    get recommendations() {
      return this._recommendations || (this._recommendations = this._plugin._getRecommendations(this._client));
    }

    get recommendation() {
      return this.recommendations.get(); // get default recommendation unit
    }

    get search() {
      return this._search || (this._search = new Search(this._plugin, this._client));
    }

    get asks() {
      return this._asks || (this._asks = this._plugin._getAsks(this._client));
    }

    get ask() {
      return this.asks.root;
    }

    get hybridSearch() {
      return this._hybridSearch || (this._hybridSearch = new HybridSearch(this._plugin, this._client));
    }

    get explore() {
      return this._explore || (this._explore = new Explore(this._plugin, this._client));
    }

    get ready() {
      return this._plugin._ready.promise;
    }

  }

  class Combo {

    constructor(plugin, MisoClient) {
      this._plugin = plugin;
      this._MisoClient = MisoClient;
    }

    get ask() {
      return this._ask || (this._ask = new AskCombo(this._plugin, this._MisoClient));
    }

  }

  MisoClient$2.plugins.use(UiPlugin);

  function cmd(callback) {
    // kick off misodev execution
    cmd$1('misodev');

    // do misocmd with setTimeout, so they will be executed after plugins are installed.
    setTimeout(() => {
      cmd$1('misocmd');
      callback && callback();
    });
  }

  MisoClient$2.attach();

  cmd(setCmdDone);

  return MisoClient$2;

}));
