(function (factory) {
  typeof define === 'function' && define.amd ? define(factory) :
  factory();
})((function () { 'use strict';

  class LocalStorageProperty {
    constructor({
      key,
      createDefaultValue
    }) {
      this._key = key;
      this._createDefaultValue = createDefaultValue;
      this._callbacks = [];
      try {
        const str = window.localStorage.getItem(key);
        if (str) {
          this._value = JSON.parse(str);
        } else {
          this.init();
        }
      } catch (e) {
        console.error(e);
        this.init();
      }
    }
    init() {
      this._setValue(this._createDefaultValue());
    }
    reset() {
      this.value = this._createDefaultValue();
    }
    get value() {
      return this._value;
    }
    set value(v) {
      this._setValue(v);
    }
    _setValue(newValue, init = false) {
      try {
        const str = JSON.stringify(newValue);
        const oldValue = this._value;
        this._value = newValue;
        window.localStorage.setItem(this._key, str);
        if (!init) {
          for (const callback of this._callbacks) {
            callback(newValue, oldValue);
          }
        }
      } catch (e) {
        console.error(e);
      }
    }
    onUpdate(callback) {
      this._callbacks.push((...args) => {
        try {
          callback(...args);
        } catch (e) {
          console.error(e);
        }
      });
    }
  }

  function toElement(html) {
    return _toNode(html, true);
  }
  function toNodes(html) {
    return _toNodes(html, false);
  }
  function _toNodes(html, elementOnly) {
    const template = document.createElement('template');
    template.innerHTML = html;
    return elementOnly ? template.content.children : template.content.childNodes;
  }
  function _toNode(html, elementOnly) {
    const nodes = _toNodes(html, elementOnly);
    if (nodes.length !== 1) {
      throw new Error(`Expect exactly 1 ${elementOnly ? 'element' : 'node'} from html string: ${html}`);
    }
    return nodes[0];
  }
  let mainElement;
  function main() {
    return mainElement || (mainElement = document.getElementsByTagName('main')[0]);
  }

  let bootstrapPromise;
  async function bootstrap() {
    return window.bootstrap || bootstrapPromise || (bootstrapPromise = createBootstrapPromise());
  }
  function createBootstrapPromise() {
    return new Promise(resolve => {
      let resolved = false;
      let _bootstrap;
      Object.defineProperty(window, 'bootstrap', {
        get: () => _bootstrap,
        set: bootstrap => {
          _bootstrap = bootstrap;
          if (!resolved) {
            resolved = true;
            resolve(bootstrap);
          }
        }
      });
    });
  }

  async function alert(message, options) {
    if (typeof message === 'string') {
      message = {
        body: message
      };
    }
    const toastElement = toElement(renderToast(message, options));
    getToastContainer().appendChild(toastElement);
    const bootstrap$1 = await bootstrap();
    const toast = new bootstrap$1.Toast(toastElement, options);
    toast.show();
    return toast;
  }
  let toastContainer;
  function getToastContainer() {
    if (!toastContainer) {
      toastContainer = document.getElementById('toast-container');
    }
    if (!toastContainer) {
      toastContainer = toElement(`<div id="toast-container" class="toast-container position-fixed p-3 top-0 end-0"></div>`);
      main().appendChild(toastContainer);
    }
    return toastContainer;
  }
  function renderToast({
    body
  }, {
    color = 'primary'
  } = {}) {
    return `
<div class="toast text-white bg-${color}" role="alert" aria-live="assertive" aria-atomic="true">
  <div class="d-flex">
    <div class="toast-body">${body}</div>
    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
  </div>
</div>
`;
  }

  var index = /*#__PURE__*/Object.freeze({
    __proto__: null,
    alert: alert,
    main: main,
    toElement: toElement,
    toNodes: toNodes
  });

  function shimType(type) {
    switch (type) {
      case 'viewable_impression':
        return 'viewable';
      default:
        return type;
    }
  }
  function getColor(type) {
    switch (type) {
      case 'impression':
        return 'primary';
      case 'viewable':
      case 'feedback':
        return 'success';
      case 'click':
        return 'danger';
      default:
        return 'secondary';
    }
  }
  function monitorEvents(workflow) {
    workflow.on('interaction', payload => {
      let {
        type,
        product_ids
      } = payload;
      type = shimType(type);
      const color = getColor(type);
      alert(`[${type}] ${product_ids.join(', ')}`, {
        color
      });
    });
  }

  var unit = /*#__PURE__*/Object.freeze({
    __proto__: null,
    monitorEvents: monitorEvents
  });

  const interceptors = {
    request: [],
    response: []
  };
  function intercept({
    request,
    response
  } = {}) {
    if (request !== undefined && typeof request !== 'function') {
      throw new TypeError('request must be a function');
    }
    if (response !== undefined && typeof response !== 'function') {
      throw new TypeError('response must be a function');
    }
    if (request || response) {
      injectFetchInNecessary();
    }
    request && interceptors.request.push(request);
    response && interceptors.response.push(response);
  }
  let _fetch;
  async function fetch(...args) {
    let request = new Request(...args);
    for (const fn of interceptors.request) {
      request = fn(request) || request;
    }
    let response = await _fetch(request);
    for (const fn of interceptors.response) {
      response = (await fn(response, request)) || response;
    }
    return response;
  }
  function injectFetchInNecessary() {
    if (window.fetch === fetch) {
      return;
    }
    _fetch = window.fetch;
    window.fetch = fetch;
  }

  var fetch$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    intercept: intercept
  });

  function config({
    answer = {},
    speedRate
  } = {}) {
    const answerLanguages = Array.isArray(answer.languages) ? answer.languages : answer.languages ? [answer.languages] : [];
    window.helpers.fetch.intercept({
      request: request => {
        if (request.method.toLowerCase() === 'post' && request.url.indexOf('/api/ask/questions') > -1) {
          if (answerLanguages.length > 0) ;
          request.headers.append('x-answer-languages', answerLanguages.join(','));
        }
        if (typeof answer.format === 'string') {
          request.headers.append('x-answer-format', answer.format);
        }
        if (typeof answer.sampling === 'number') {
          request.headers.append('x-answer-sampling', `${answer.sampling}`);
        }
        if (typeof speedRate === 'number') {
          request.headers.append('x-speed-rate', `${speedRate}`);
        }
        return request;
      }
    });
  }

  var doggo = /*#__PURE__*/Object.freeze({
    __proto__: null,
    config: config
  });

  var helpers = /*#__PURE__*/Object.freeze({
    __proto__: null,
    doggo: doggo,
    fetch: fetch$1,
    ui: index,
    unit: unit
  });

  // inject with .env or process.env
  const DEFAULT_API_KEY = "CxRbpUPDsBVOYLufXDOkj87Au2MyCi4uKPhWlqcA";
  const DEFAULT_ASK_API_KEY = "NanxRwMTmcZGVKJOpxcguWBXFMnEQwQNK2OGwEo1";
  //const DEFAULT_USER_ID = undefined;
  const ID = 'demo';
  class DemoPlugin {
    static get id() {
      return ID;
    }
    constructor() {
      /*
      this._settings = new LocalStorageProperty({
        key: 'miso-sdk-demo::apps-settings',
        createDefaultValue: () => ({}),
      });
      */
      this._selection = new LocalStorageProperty({
        key: 'miso-sdk-demo::apps-selection',
        createDefaultValue: () => ({
          //apiKey: DEFAULT_API_KEY,
          //userId: DEFAULT_USER_ID,
        })
      });
    }
    get selection() {
      return this._selection.value;
    }
    reset() {
      this._selection.reset();
    }
    install(MisoClient) {
      window.helpers = helpers;
      const selection = this._selection;

      // inject client options
      const _normalizeOptions = MisoClient.prototype._normalizeOptions;
      MisoClient.prototype._normalizeOptions = function (options) {
        if (typeof options === 'string' && options !== '...') {
          options = {
            apiKey: options
          };
        }
        return _normalizeOptions.call(this, {
          apiKey: options && options.type !== 'ask' ? DEFAULT_API_KEY : DEFAULT_ASK_API_KEY,
          //apiKey: selection.value.apiKey,
          ...options
        });
      };

      // set user id and user hash on create
      MisoClient.on('create', client => {
        const {
          userId,
          userHash
        } = selection.value;
        if (userId) {
          client.context.user_id = userId;
          client.context.user_hash = userHash;
        }
      });

      // react on update
      selection.onUpdate((newValue = {}, oldValue = {}) => {
        const {
          apiKey: newApiKey,
          userId: newUserId,
          userHash: newUserHash
        } = newValue;
        const {
          apiKey: oldApiKey,
          userId: oldUserId,
          userHash: oldUserHash
        } = oldValue;
        if (newApiKey !== oldApiKey) {
          window.location.reload();
          return;
        }
        if (newUserId !== oldUserId || newUserHash !== oldUserHash) {
          for (const client of MisoClient.instances) {
            client.context.user_id = newUserId;
            client.context.user_hash = newUserHash;
          }
        }
      });
    }
  }

  const misocmd = window.misocmd || (window.misocmd = []);
  misocmd.push(() => {
    MisoClient.plugins.use(DemoPlugin);
  });

}));
